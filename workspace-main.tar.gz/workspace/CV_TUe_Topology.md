# Wei Zhu

caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/ | github.com/caplight

## Research Profile

I am a systems engineer with a distinction-level MSc in Advanced Computer Science from Newcastle University, specializing in the design and automated synthesis of complex distributed system topologies. At Carrier R&D, I design real-time data orchestration pipelines for industrial HVAC equipment and build predictive health models that reason about how interconnected subsystems evolve under different configurations. My research interest lies in advancing automated computational design synthesis for system topologies, and I am drawn to the TU/e PhD because it directly addresses how we can automate the generation of better topologies for complex multi-domain systems.

## Education

**Newcastle University (UK), MSc Advanced Computer Science** | Sep 2021 – Nov 2022

Grade: 72/100 (Distinction / First Class Honours)

Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware, Information Security, System Security

Thesis: The Data Flow Orchestration Platform (12,000 words, Distinguished Grade / Top 5%)

**Guangzhou University Sontan College, BEng Software Engineering** | Sep 2017 – May 2021

Grade: 84/100 (Top 1% of graduating class)

Honors: Outstanding Graduate, Ranked #1 GPA in Grade (2019–2020)

## Research Experience

**The Data Flow Orchestration Platform** | Newcastle University, 2022

12,000-word dissertation | Distinguished Grade (Top 5%)

Research Objective: Designed and implemented a data flow orchestration platform for IoT edge-cloud environments. The central challenge was how to structure the interconnections between edge devices, message brokers, and cloud services to achieve low-latency, resilient data movement across heterogeneous formats including JSON, binary, stream, and batch data in real time.

Key Contributions and Innovations:
- Built a Go-based orchestration platform using a publish-subscribe model with RabbitMQ and Redis for real-time device coordination across edge and cloud tiers
- Designed a dynamic routing table managed through Redis to support automated reconfiguration of data flow paths as edge devices join or leave the network
- Deployed the platform on Kubernetes with Prometheus monitoring and InfluxDB for time-series metrics

Validation and Performance:
- Achieved throughput exceeding 10,000 messages per second with low and consistent latency across five deployment scenarios
- Evaluated system behavior under stress conditions including device churn and high-volume data bursts

## Professional Experience

**Carrier Research and Development Center (Shanghai) Co., Ltd.** | Jul 2023 – Present

Engineer Leadership Program (R&D Trainee), MASC and DI — Shanghai

**RLC Real-Time Analytics Platform** | AI Architect / Engineer

Designed a real-time analytics orchestration pipeline on AWS EKS where edge terminals feed data through Kafka and Flink into ClickHouse, with results surfaced through Argo Workflows and a LangGraph-based agentic inference layer. Built a Python and LangGraph agent that reads time-windowed sensor features from ClickHouse, executes multi-model inference combining a large language model with regression models, and writes diagnostic results back to the data store. The pipeline handles approximately 100,000 events per minute in real business scenarios across commercial HVAC equipment deployed at customer sites.

**Intelligent Diagnosis Service — RAG and Knowledge Graph** | AI / Data Engineer

Led the design and implementation of the company's first enterprise-wide Retrieval-Augmented Generation architecture using Python, Hugging Face, LangChain, and Neo4j knowledge graphs. Optimized chunking strategies, deduplication, and token window settings on open-source large language models, achieving more than 92% accuracy in domain-specific question answering across HVAC engineering knowledge. Applied LoRA fine-tuning to improve domain-specific model performance, achieving 150% faster training with CUDA acceleration. Built automated pipelines that structured 80,000 or more rows of after-sales service data into clean, normalized knowledge representations.

**Predictive Health Modeling — Agent, Optimization, and Dynamic Simulation** | AI / Data Engineer

Contributed to a predictive health management workflow for HVAC testing equipment that combines three components. An AI agent elicits and incorporates human engineering expertise to generate diagnostic judgments. An optimization algorithm uses those judgments to reason about future health trajectories under different operating conditions and subsystem configurations. A dynamic simulation model validates the predicted trajectories against physical behavior. Developed partial dependence analysis to understand relationships between operational variables such as refrigerant charge levels, condenser subcooling, and expansion valve settings, supporting the identification of operating regimes where equipment degradation is most likely to occur. This work is directly about understanding how system configurations and operating conditions affect future performance, which maps closely to the challenge of automated topology design synthesis.

**ECAT Project** | Frontend Developer and Scrum Master

Served as acting Scrum Master coordinating 20 or more JIRA items across a team of nine engineers. Reduced AWS resource usage for a single module by 70%, resulting in 5 to 10% overall cloud cost reduction. Delivered frontend features for Cathay Pacific's Vera Chatbot using Angular.js, TypeScript, and Node.js.

**Accenture (China) Co., Ltd.** | Jan 2023 – Jul 2023

Frontend Developer — Guangzhou

Delivered features for the Cathay Pacific Vera Chatbot using Angular.js, TypeScript, and Node.js. Optimized the price search API flow, achieving a 30% reduction in response latency.

## Skills

**Programming Languages:** Python (primary), Go, Java, TypeScript

**Distributed Systems and Cloud:** Apache Kafka, Apache Flink, Kubernetes (AWS EKS), Redis, RabbitMQ, AWS (EC2, S3, EKS), ClickHouse

**AI and Machine Learning:** RAG, LangChain, Agentic Systems, LangGraph, Hugging Face, CUDA, LoRA and Adapter Fine-Tuning, Knowledge Graphs (Neo4j), Anomaly Detection (DBSCAN), LLM Integration

**Data and Analytics:** Time-Series Analysis, Partial Dependence Analysis, Predictive Modeling, Digital Twins, Physical Model Calibration

**Databases and Storage:** MySQL, Neo4j, Elasticsearch, ClickHouse, AWS S3, Pinecone, Snowflake

**Other Tools:** Git, JIRA, Agile and Scrum, CI/CD, Prometheus, InfluxDB

## References

Prof. Ranjan (MSc Thesis Supervisor) — Email: Raj.ranjan@newcastle.ac.uk

Liangjiang Yang (Line Manager, Carrier R&D) — Email: Liangjiang.Yang@Carrier.com
