#!/usr/bin/env python3
import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright

SESSION_FILE = Path('/home/cap/script/jobTracker/linkedin_session.json')
PROXY = {'server': 'http://192.168.23.1:7890'}

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, proxy=PROXY)
    context = browser.new_context(
        locale='en-US',
        proxy=PROXY,
        user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    )
    state = json.loads(SESSION_FILE.read_text())
    context.add_cookies(state['cookies'])
    page = context.new_page()

    page.goto('https://www.linkedin.com/jobs/search/?keywords=AI+engineer&location=Netherlands&f_TPR=r86400', timeout=30000)
    time.sleep(5)
    page.keyboard.press('Escape')
    time.sleep(1)

    job_links = page.locator('a[href*="/jobs/view/"]')
    first_href = job_links.first.get_attribute('href')
    print('First job:', first_href[40:80])
    job_links.first.click()
    time.sleep(5)
    print('Detail URL:', page.url)

    try:
        desc_el = page.locator('.description__text--rich').first
        desc = desc_el.inner_text(timeout=5000)
        print('Description length:', len(desc))
        print('First 300 chars:')
        print(desc[:300])
    except Exception as e:
        print('Error:', str(e)[:100])

    browser.close()
