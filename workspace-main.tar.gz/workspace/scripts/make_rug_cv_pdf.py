from weasyprint import HTML
HTML(filename="/tmp/CV_RUG_AgenticAI.html").write_pdf("/tmp/CV_RUG_AgenticAI.pdf")
