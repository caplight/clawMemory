# USER.md - About Your Human

- **Name:** 爸爸猫 (Wei Zhu)
- **What to call them:** 爸爸猫
- **Timezone:** Asia/Shanghai
- **Contact:** 飞书
- **Email:** caplight98@gmail.com
- **Phone:** +8618122397704
- **LinkedIn:** linkedin.com/in/wadezhu/

## 教育背景
- **MSc** Advanced Computer Science (Distinction, 72/100) — Newcastle University, UK (Sep 2021 - Nov 2022)
- **BEng** Software Engineering (84/100, Top 1%) — Guangzhou University Sontan College (Sep 2017 - May 2021)

## 工作经验（Carrier R&D中心）
- **Engineer Leadership Program** (AI / Data / Systems Engineering Track) — Jul 2023 - Present
- **项目：**
  1. **RLC Real-Time Analytics Platform**（AI Architect/Engineer）：AWS EKS + Kafka + Flink + ClickHouse + Argo LangGraph，实时分析编排
  2. **Intelligent Diagnosis & Solution Recommendation**（AI/Data Engineer）：RAG架构（LangChain/Pinecone/Ollama），知识图谱（Neo4j），LoRA微调，92%+ QA准确率
  3. **ECAT Project**（Front-End Engineer & Scrum Master）：JIRA 20+任务管理，云资源迁移降低70%用量

## 前工作
- **Accenture (China)** — Front-End Developer (Jan 2023 - Jul 2023)：AngularJS/TypeScript/Node.js，价格搜索优化响应时间降低30%

## 研究兴趣
- 自组织边缘基础设施
- 边缘-云资源编排
- IoT协调与协议标准化
- ML/AI监控与故障检测
- 知识图谱与语义标注
- 数字孪生
- **AI故障检测、预测性维护、工业数据分析**

## 技术栈
- **语言：** Python, Go, Java
- **框架/工具：** Kubernetes, Kafka, Flink, Redis, RabbitMQ, FastAPI, LangChain/LangGraph, HuggingFace, CUDA
- **数据库：** MySQL, ClickHouse, Neo4j, Elasticsearch, AWS S3, Snowflake, Pinecone

## 项目状态
- ✅ PhD爬虫已部署（18个大学）
- ✅ Ranker已配置（个性化提示词v2）
- ✅ Notion同步正常
- ✅ JobTracker多源抓取（LinkedIn + Indeed + Decodo proxy）
- ⏳ 持续运行中（每天17:00+21:30 cron）
