# Resume Customize — Prompt

## Task

Tailor the user's resume for a specific job position. Analyze the job description, identify keyword gaps, and produce a customized resume that maximizes relevance.

---

## INPUT

- **Job Description / Target Role**: `{{job_description}}`
- **Language**: `{{language}}` (default: `en`)

> **NOTE ON BASE CONTEXT:** Before tailoring, the user's Master Resume Library is loaded automatically from:
> `/root/.openclaw/workspace/skills/resume-assistant/data/master_resume_library.md`
>
> This library contains all of the user's background (education, work experience, skills, projects, references). Use it as the **authoritative source** — do NOT ask the user to re-enter their background. If you need to confirm a detail, check the library first.

---

## Step 0 — Load Master Resume Library

At the start of every customize call, read the file:
```
/root/.openclaw/workspace/skills/resume-assistant/data/master_resume_library.md
```

Extract the following from the library:
- Contact information
- Education (degrees, thesis details, grades, coursework)
- All work experience projects (4 at Carrier + Accenture)
- Skills (categorized)
- References (names + emails)
- Specialized module flags (A–I) relevant to this application

The library uses these module flags to quickly identify which project bullets to emphasize:
| Flag | Topic |
|------|-------|
| [A] | IoT / Edge Computing |
| [B] | AI / ML / RAG |
| [C] | Distributed Systems / Performance |
| [D] | Security |
| [E] | Cloud / DevOps / Cost Optimization |
| [F] | HCI / Developer Tooling |
| [G] | Predictive Maintenance / Digital Twins |
| [H] | NLP / Question Answering |
| [I] | Scrum / Leadership |

---

## WRITING RULES (MANDATORY)

These rules override all other style guidance. Write like a real person, not a template.

1. **NO em dashes** — use commas, semicolons, or split into separate sentences instead
   - BAD: "Designed a scalable framework — achieving 99.5% uptime"
   - GOOD: "Designed a scalable framework, achieving 99.5% uptime" or "Designed a scalable framework. The system achieved 99.5% uptime."

2. **Write complete, natural sentences** — avoid bullet-point fragments that feel mechanical
   - BAD: "Built Kafka pipeline. 100K events/min. Reduced latency by 40%"
   - GOOD: "Built a Kafka pipeline that processes 100K events per minute, reducing end-to-end latency by 40%"

3. **Active, specific verbs** — each bullet should start with a strong action verb in context
   - Good: "Designed and implemented", "Led the development of", "Improved X by achieving Y"
   - Avoid: generic "Worked on", "Involved in", "Responsible for"

4. **Quantify results** — numbers, percentages, and timeframes strengthen every claim
   - BAD: "Improved system performance significantly"
   - GOOD: "Improved system throughput by 3x, reaching 10,000 messages per second"

5. **Match the job description's language** — use the same terminology and phrasing they use
   - If JD says "fault detection" say "fault detection", not "error identification"
   - If JD says "observability" use that word

6. **No emoji, no icons, no decorative symbols** — pure text only

7. **Sentence length variation** — mix short punchy sentences with longer descriptive ones. Reads like a person, not a robot.

---

## Step 1 — Job Description Analysis

Extract and organize:

1. **Required Skills** — Must-have technical and soft skills
2. **Preferred Skills** — Nice-to-have qualifications
3. **Key Responsibilities** — Core duties of the role
4. **Industry Keywords** — ATS-critical terms and phrases
5. **Experience Level** — Years and seniority expected
6. **Culture Signals** — Values, tone, and team dynamics clues
7. **Research Fit Signals** — Does this look like a research/PhD role? Note if publication, academic, or open-ended research direction is expected

---

## Step 2 — Module Flag Selection + Gap Analysis

From the job description, identify which module flags (A–I) are most relevant.
Map every requirement to the user's background from the library:

| # | Requirement | Relevant Module | Status | Evidence from Library |
|---|-------------|----------------|--------|----------------------|
| 1 | [skill/qualification] | [A-I or N/A] | Strong Match / Partial / Gap | [specific bullet from library] |

Calculate initial match score: `matched / total requirements × 100`

---

## Step 3 — Customization Actions

### 3a. Research Profile / Professional Summary Rewrite

- Mirror the job description's language and keywords
- Lead with the 2-3 most relevant qualifications (driven by module flag selection)
- Address the role directly
- For PhD/research roles: write a "Research Profile" paragraph instead of a professional summary
- For industry roles: write a focused professional summary

### 3b. Experience Optimization

- **Select project bullets by module flag** — only include bullets relevant to the target JD
- **Reorder** bullets within each role to put the most relevant first
- **Strengthen** bullets that match key responsibilities (add context from the library if missing)
- **Add keywords** naturally into existing achievement descriptions
- **De-emphasize** irrelevant experience (fewer bullets, less detail — never delete honest history)
- **Apply Writing Rules above** — rewrite bullets to sound natural, not templated

### 3c. Skills Alignment

- **Reorder** skills by relevance to the target role
- **Surface** skills the candidate has but didn't explicitly list (from the library's full skills list)
- **Match terminology** to the job description
- **Group** by relevance: "Core Skills" then "Additional Skills"

### 3d. Additional Sections

- Suggest adding relevant certifications, courses, or projects
- For research/PhD roles: emphasize thesis details, research methods, references
- For career transitions: highlight transferable skills prominently

---

## Step 4 — Keyword Optimization Report

| Metric | Value |
|--------|-------|
| **Keywords Matched** | X / Y (list them) |
| **Keywords Added** | X (list where they were added) |
| **Keywords Still Missing** | X (with suggestions to address) |
| **Overall Keyword Coverage** | X% |

---

## OUTPUT FORMAT

```
## Job Analysis

**Target**: [Job Title] at [Company/Institution]
**Level**: [Junior / Mid / Senior / Lead / Executive / PhD]
**Key Requirements**: [top 5 bullet points]
**Relevant Module Flags**: [A, B, C... etc]

---

## Gap Analysis

| # | Requirement | Module | Status | Evidence |
|---|-------------|--------|--------|----------|

**Initial Match Score**: X%

---

## Customized Resume

[Complete tailored resume in Markdown format — follow Writing Rules above]

---

## Keyword Report

### Matched
- ...

### Added
- ...

### Missing (with recommendations)
- ...

### Coverage: X%

---

## Quality Checklist

- [ ] Writing Rules followed (no em dashes, natural sentences)
- [ ] All claims backed by evidence in the master resume library
- [ ] No fabricated achievements or skills
- [ ] Quantified results wherever available
- [ ] Research interests / profile tailored to job description
- [ ] ATS keywords from JD naturally integrated
- [ ] References section included
