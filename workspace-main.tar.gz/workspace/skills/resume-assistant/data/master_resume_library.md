# Wei Zhu — Master Resume Library
# Universal background素材库 (used by /resume customize — auto-loaded as base context)

---

## CONTACT

- Name: Wei Zhu (朱玮)
- Email: caplight98@gmail.com
- Phone: +86 181 2239 7704
- LinkedIn: linkedin.com/in/wadezhu/
- GitHub: github.com/caplight
- Location: Shanghai, China

---

## EDUCATION

### MSc Advanced Computer Science
- Institution: Newcastle University, UK
- Period: Sep 2021 - Nov 2022
- Grade: 72/100 (Distinction / First Class Honours)
- Thesis: "The Data Flow Orchestration Platform" (12,000 words, Distinguished Grade / Top 5%)

  The thesis was about designing and implementing a data flow orchestration platform for IoT edge-cloud environments. The core challenge was managing data transfer latency, automating configuration across heterogeneous distributed systems, and handling diverse data formats (JSON, binary, stream, batch) in real time.

  Key technical work:
  - Built a Go-based orchestration platform using a publish-subscribe model with RabbitMQ and Redis
  - Designed a dynamic routing table managed through Redis for real-time device coordination
  - Deployed the platform on Kubernetes with Prometheus monitoring and InfluxDB for time-series metrics
  - Conducted comprehensive benchmarking: the system achieved over 10,000 messages per second with low latency, and demonstrated resilience under DDoS-like stress testing across five simulated scenarios

  The thesis gave me deep hands-on experience in distributed systems design, computer networking, message-oriented middleware, and performance evaluation methodology.

- Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware, Information Security, System Security

### BEng Software Engineering
- Institution: Guangzhou University Sontan College, China
- Period: Sep 2017 - May 2021
- Grade: 84/100 (Top 1% of graduating class)
- Honours: Outstanding Graduate; Ranked #1 GPA in Grade (2019-2020)

---

## WORK EXPERIENCE

### Carrier R&D Center (Shanghai) — Engineer Leadership Program
**Period:** Jul 2023 - Present

#### Project 1: RLC Real-Time Analytics Platform (AI Architect / Engineer)
- Designed a real-time analytics orchestration on AWS EKS: edge terminals feed data through Kafka and Flink into ClickHouse, with results surfaced through Argo Workflows and LangGraph-based agentic inference
- Built a Python and LangGraph agent that reads time-windowed sensor features from ClickHouse, executes multi-model inference (LLM plus regression models), and writes diagnostic results back to the data store
- Scope included refrigerant leakage detection and coil blockage identification for commercial HVAC equipment

#### Project 2: Intelligent Diagnosis Service — RAG + Knowledge Graph (AI / Data Engineer)
- Led the design and implementation of the company's first enterprise-wide RAG architecture: Python, Hugging Face, LangChain, Neo4j knowledge graphs
- Optimized chunking strategies, deduplication, and token window settings on open-source LLMs, achieving more than 92% accuracy in domain-specific question answering
- Applied LoRA fine-tuning to improve domain-specific model performance, achieving 150% faster training with CUDA acceleration
- Built automated pipelines that structured 80,000-plus rows of after-sales service data into clean, normalized knowledge representations
- Applied DBSCAN clustering to operational sensor data for anomaly detection, validated with quantitative metrics and reviewed by domain experts

#### Project 3: CTD Project — Predictive Health Modeling with Agent + Optimization + Dynamic Simulation (AI / Data Engineer)
- Contributed to a predictive health management workflow for HVAC testing equipment, combining three components: an AI agent that elicits and incorporates human engineering expertise to generate diagnostic judgments, an optimization algorithm that uses those judgments to reason about future health trajectories under different operating conditions, and a dynamic simulation model that validates the predicted trajectories against physical behavior
- The agent bridges human domain knowledge with quantitative prediction: engineers provide experience-based heuristics and constraint parameters, the optimization layer propagates these forward in time, and the dynamic model confirms whether the predicted health degradation matches expected physical system responses
- Developed partial dependence analysis to understand relationships between operational variables such as refrigerant charge levels, condenser subcooling, and expansion valve settings
- Collaborated with the modeling team to identify operating regimes where equipment degradation is most likely to occur

#### Project 4: ECAT Project (Frontend Developer & Scrum Master)
- Served as acting Scrum Master, coordinating 20-plus JIRA items across a team of nine engineers
- Reduced AWS resource usage for a single module by 70%, resulting in 5 to 10% overall cloud cost reduction
- Delivered frontend features for Cathay Pacific's Vera Chatbot using Angular.js, TypeScript, and Node.js

### Accenture (China)
**Period:** Jan 2023 - Jul 2023
- Worked on the Cathay Pacific Vera Chatbot project: Angular.js, TypeScript, Node.js
- Optimized API response times for the price search flow, achieving a 30% reduction in latency

---

## SKILLS

### Programming Languages
Python, Go, Java, TypeScript

### Distributed Systems and Cloud
Apache Kafka, Apache Flink, Kubernetes (AWS EKS), Redis, RabbitMQ, AWS (EC2, S3, EKS), ClickHouse

### AI and Machine Learning
RAG, LangChain, Agentic Systems, Hugging Face, CUDA, LoRA/Adapter Fine-Tuning, Knowledge Graphs (Neo4j), Anomaly Detection (DBSCAN), LLM Integration

### Data and Analytics
Time-Series Analysis, Partial Dependence Analysis, Predictive Modeling, Digital Twins, Physical Model Calibration

### Databases and Storage
MySQL, Neo4j, Elasticsearch, ClickHouse, AWS S3, Pinecone, Snowflake

### Other Tools
Git, JIRA, Miro, Agile/Scrum, CI/CD, Prometheus, InfluxDB

---

## REFERENCES

1. Prof. Ranjan (MSc Thesis Supervisor) — Raj.ranjan@newcastle.ac.uk
2. Liangjiang Yang (Line Manager, Carrier R&D) — Liangjiang.Yang@Carrier.com

---

## SPECIALIZED MODULE FLAGS

[A] IOT_EDGE: Redis dynamic routing table, RabbitMQ/Kafka pub-sub, edge-cloud orchestration, Kubernetes deployment, 10K+ msg/sec throughput, DDoS resilience, performance benchmarking across 5 scenarios

[B] AI_ML_RAG: Enterprise RAG (LangChain+HuggingFace), >92% QA accuracy, LoRA 150% CUDA speed, Neo4j KG, DBSCAN anomaly detection

[C] DISTRIBUTED_SYSTEMS: Go-based Orchestrator, Kubernetes automated deployment, message-oriented middleware (RabbitMQ/Redis), distributed systems performance evaluation

[D] SECURITY: Security and Resilience research project at Newcastle, thread-safe cryptographic implementations, MITM attack resilience

[E] CLOUD_DEVOPS: AWS EKS architecture, 70% resource reduction leading to 5-10% cost saving, CI/CD practices

[F] PREDICTIVE_HEALTH: Agent + Optimization Algorithm + Dynamic Modeling for predictive maintenance, partial dependence analysis, digital twin calibration, physical model validation

[G] NLP_QA: RAG-based QA pipeline (>92% accuracy), domain-specific fine-tuning, 80K-row data processing pipeline

[H] LEADERSHIP: Scrum Master role, managed 20-plus JIRA items across a team of 9 engineers, global team collaboration
