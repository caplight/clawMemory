# mike johnson

mikej1995@hotmail.com
phone: 5551234567

## about me

I am a very hard working and passionate developer who loves coding. I am a quick learner
and team player. Looking for a challenging position where I can grow my skills.

## work

software developer, some tech company
2020 - now

<!-- Weak: generic responsibility with no scope, tools, ownership, or outcome. -->
- Responsible for writing code
<!-- Weak: too broad to say what systems, technologies, or impact were involved. -->
- Worked on the backend
<!-- Weak: vague support statement without quality metrics or specific contribution. -->
- Helped with testing
<!-- Weak: describes routine participation rather than a meaningful accomplishment. -->
- Attended meetings
<!-- Weak: lists a basic tool with no context, scale, or result. -->
- Used git for version control

intern, another company
Summer 2019

<!-- Weak: completely non-specific and gives no evidence of skills or results. -->
- Did various tasks assigned by my manager
<!-- Weak: focuses on personal learning instead of concrete work delivered. -->
- Learned a lot about software development

## school

computer science, State University, 2020
GPA: 3.1

## skills

Python, java, javascript, SQL, html, CSS, react, node, git, agile, microsoft office, 
communication, teamwork, problem solving, time management, leadership
