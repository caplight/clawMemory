#!/usr/bin/env python3
"""
End-to-end generation + Cursor review pipeline for resume and CL skills.

Usage:
    python3 generate_and_review.py resume --user-background "<text>" --target-role "<role>" [--language en]
    python3 generate_and_review.py cl --user-background "<text>" --job-title "<title>" --institution "<inst>" [--job-description "<desc>"] [--language en]

Output:
    Generates draft → Cursor reviews → outputs final reviewed version
    Also outputs: issues_found.json (analysis), final.<ext>
"""

import json
import subprocess
import sys
import os
import tempfile

SKILLS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def build_resume_prompt(user_background: str, target_role: str, language: str) -> str:
    """Build the generation prompt from resume skill."""
    with open(f"{SKILLS_DIR}/resume-assistant/prompts/system.md") as f:
        system = f.read()
    with open(f"{SKILLS_DIR}/resume-assistant/prompts/generate.md") as f:
        generate = f.read()
    
    return f"""You are Resume Assistant. Generate a professional resume.

## User Background
{user_background}

## Target Role
{target_role}

## Language
{language}

## System Instructions
{system}

## Generation Instructions
{generate}

## Output
Generate BOTH versions:
1. A clean, submission-ready resume (no annotations)
2. A structured draft with section labels

Return as JSON:
{{"submission": "...", "draft": "..."}}
"""


def build_cl_prompt(user_background: str, job_title: str, institution: str, 
                     job_description: str, language: str) -> str:
    """Build the generation prompt from CL skill."""
    with open(f"{SKILLS_DIR}/cl-assistant/prompts/system.md") as f:
        system = f.read()
    with open(f"{SKILLS_DIR}/cl-assistant/prompts/generate.md") as f:
        generate = f.read()
    
    jd_section = f"## Job Description\n{job_description}" if job_description else ""
    
    return f"""You are Cover Letter Assistant. Generate a professional cover letter.

## User Background
{user_background}

## Target Position
{job_title} at {institution}

{jd_section}

## Language
{language}

## System Instructions
{system}

## Generation Instructions
{generate}

## Output
Generate BOTH versions:
1. A clean, submission-ready cover letter (no markdown headings, no emoji, no separators)
2. A structured draft with internal analysis notes

Return as JSON:
{{"submission": "...", "draft": "...", "internal_analysis": "..."}}
"""


def call_minimax(prompt: str, output_json: bool = True) -> str:
    """Call MiniMax API via curl."""
    import urllib.request, urllib.parse
    
    data = {
        "model": "MiniMax-M2.7",
        "messages": [{"role": "user", "content": prompt}],
        "stream": False
    }
    
    req = urllib.request.Request(
        "https://api.minimaxi.com/v1/chat/completions",
        data=json.dumps(data).encode(),
        headers={
            "Authorization": f"Bearer sk-cp-fQZxgx_WiWnu46I4AEHhprLAhHEVlr6_7s9vsTrX5Z-1rdhKPzo_8q-KrDdvlv_VhIgmMS3b7OK80MiM-4-f9Ni7PJx-p_98nqJUMRSaUrIpKge8rDTx-RE",
            "Content-Type": "application/json"
        },
        method="POST"
    )
    
    with urllib.request.urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read())
        return result["choices"][0]["message"]["content"]


def call_cursor_review(document: str, doc_type: str, context: str) -> dict:
    """Call Cursor to review and refine the document."""
    review_script = f"{SKILLS_DIR}/_shared/review_and_refine.py"
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, dir='/tmp') as f:
        f.write(document)
        doc_file = f.name
    
    cmd = [
        '/root/.local/bin/cursor',
        '--print', '--trust',
        '--workspace', '/tmp',
        '--model', 'gpt-5.4-medium',
        f'Review this {doc_type} carefully. Read the document at {doc_file}.\n\nContext:\n{context}\n\nReturn ONLY valid JSON with this exact format:\n{{"issues_found": ["issue 1", "issue 2"], "phd_fit_warning": true/false, "revised_document": "...full revised document..."}}\n\nIf no serious issues found, revised_document should be the same as the original with only minor polish.'
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180, cwd='/tmp')
        if result.returncode == 0 and result.stdout.strip():
            # Try to extract JSON from output
            output = result.stdout.strip()
            # Find JSON in output
            start = output.find('{')
            end = output.rfind('}') + 1
            if start >= 0 and end > start:
                return json.loads(output[start:end])
    except Exception as e:
        pass
    
    return {"issues_found": [], "phd_fit_warning": False, "revised_document": document}


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Generate and review resume or CL')
    parser.add_argument('doc_type', choices=['resume', 'cl'])
    parser.add_argument('--user-background', required=True)
    parser.add_argument('--target-role', help='For resume')
    parser.add_argument('--job-title', help='For CL')
    parser.add_argument('--institution', help='For CL')
    parser.add_argument('--job-description', default='')
    parser.add_argument('--language', default='en')
    parser.add_argument('--output-dir', default='/tmp')
    args = parser.parse_args()

    print(f"Generating {args.doc_type}...")
    
    # Step 1: Generate draft
    if args.doc_type == 'resume':
        prompt = build_resume_prompt(args.user_background, args.target_role or '', args.language)
        context = f"Target role: {args.target_role or 'general'}"
        ext = 'md'
    else:
        prompt = build_cl_prompt(
            args.user_background, 
            args.job_title or '',
            args.institution or '',
            args.job_description,
            args.language
        )
        context = f"Position: {args.job_title} at {args.institution}\nJob description: {args.job_description}"
        ext = 'md'

    print("Calling MiniMax to generate draft...")
    try:
        draft_response = call_minimax(prompt)
        draft_data = json.loads(draft_response)
        draft = draft_data.get('submission', draft_data.get('draft', draft_response))
    except Exception as e:
        print(f"Generation failed: {e}")
        draft = args.user_background  # fallback
    
    # Step 2: Cursor review
    print("Cursor reviewing the generated document...")
    review_result = call_cursor_review(draft, args.doc_type, context)
    
    # Step 3: Output
    final = review_result.get('revised_document', draft)
    issues = review_result.get('issues_found', [])
    warning = review_result.get('phd_fit_warning', False)
    
    output_base = f"{args.output_dir}/{args.doc_type}_final"
    with open(f"{output_base}.{ext}", 'w') as f:
        f.write(final)
    
    with open(f"{output_base}.issues.json", 'w') as f:
        json.dump({
            'issues_found': issues,
            'phd_fit_warning': warning,
            'doc_type': args.doc_type
        }, f, indent=2)
    
    print(f"\n✅ Final {args.doc_type} written to: {output_base}.{ext}")
    if issues:
        print(f"⚠️  {len(issues)} issues found - see {output_base}.issues.json")
    if warning:
        print("⚠️  PhD fit warning - review before submitting")
    
    print(f"\n--- FINAL DOCUMENT ---\n{final}\n--- END ---")


if __name__ == '__main__':
    main()
