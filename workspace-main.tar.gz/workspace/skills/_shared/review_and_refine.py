#!/usr/bin/env python3
"""
Shared review-and-refine pipeline for resume and CL skills.

Usage:
    python3 review_and_refine.py --type resume --input "..." --context "..." --output /path/to/output.md

Context JSON (string):
  For resume:  {"user_background": "...", "target_role": "..."}
  For CL:     {"user_background": "...", "job_title": "...", "institution": "...", "job_description": "..."}
"""

import json
import subprocess
import tempfile
import os
import argparse

RESUME_SYSTEM_PROMPT = """You are reviewing and improving a professional resume. You have deep expertise in HR practices, ATS optimization, and technical PhD/application resumes.

## Your Task
1. Read the provided resume carefully
2. Read the user's background context and target role
3. Apply the writing standards below to identify issues
4. Produce a REVISED final version that addresses all issues

## Writing Standards for Resume

### Content Quality (30 pts)
- Achievement Focus: Quantified, results-driven bullets vs. vague duties
- Action Verbs: Strong, varied verbs at the start of each bullet
- Relevance: Content relevance to target role / industry
- Completeness: All essential sections present and well-developed
- Differentiation: Unique content that stands out from generic resumes

### Structure & Formatting (25 pts)
- Clean, logical, easy-to-scan visual structure
- Consistent formatting: dates, bullets, capitalization
- Appropriate length for experience level
- Optimal section ordering for maximum impact

### Language & Grammar (20 pts)
- Grammatical correctness throughout
- Zero spelling errors
- Professional, confident, appropriate voice
- Clear, concise, unambiguous writing

### ATS Optimization (15 pts)
- Industry-relevant keywords present
- ATS-recognizable section titles
- No tables, images, or complex layouts

### Impact & First Impression (10 pts)
- Grabs attention in 6 seconds
- Clear career narrative and progression
- Professional presentation

### For PhD/Academic Roles — ALSO CHECK (20 pts extra):
- Research Relevance: Clear connection to target PhD topic/methodology
- Methodological Maturity: Hands-on experience with relevant methods
- Research Artifacts: Publications, preprints, open-source, datasets
- Independence & Rigor: Evidence of independent problem-solving

## Critical Rules
- NEVER fabricate achievements, skills, or research details
- NEVER invent lab names, professor names, or paper titles
- Keep original voice and authentic achievements
- For PhD: emphasize research potential, methodological maturity, independence
"""

CL_SYSTEM_PROMPT = """You are reviewing and improving a cover letter. You have deep expertise in academic PhD applications and professional cover letters.

## Your Task
1. Read the provided cover letter carefully
2. Read the user's background context and target position
3. Apply the writing standards below to identify issues
4. Produce a REVISED final version that addresses all issues

## Writing Standards for Cover Letter

### Structure
1. Opening: Name position + institution + specific motivation
2. Experience Evidence: Project context → Specific achievement with data → Transition to PhD/project
3. Research Directions: ONLY if explicitly invited by job description; 1-2 tightly scoped ideas
4. Closing: Genuine research fit with the group

### Quality Checklist
- Opening directly names the position and institution
- Every experience paragraph has: context → data → bridge to PhD
- Research directions only if invited; if present: problem + method + evaluation dimension
- Quantified evidence: numbers, percentages, timeframes
- NO fabricated lab/paper/methodology names
- No spelling or grammar errors
- 500-800 words for PhD CL
- Closing expresses genuine research fit

### PhD Guardrails
- DO NOT fabricate knowledge of a lab or paper
- DO NOT invent methodologies not mentioned in the job description
- Research directions: only include when explicitly invited
- Prefer 1-2 concrete ideas over many vague ones
- Optimize for research FIT, not professional polish

## Critical Rules
- NEVER fabricate achievements, skills, or research details
- Respect user's original voice
- If job description doesn't mention a lab/paper/method: do NOT invent it
"""


def call_cursor_review(document: str, doc_type: str, context: str, system_prompt: str) -> dict:
    """Call Cursor CLI to review and refine the document. Returns dict with issues_found, revised_document."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, dir='/tmp') as f:
        f.write(f"""You are reviewing and improving a {doc_type}. Apply the writing standards below.

{system_prompt}

## USER CONTEXT:
{context}

## DOCUMENT TO REVIEW:
{document}

## YOUR TASK:
Read the document, apply the writing standards, identify all issues, and produce a REVISED final version.

## OUTPUT FORMAT (return ONLY valid JSON):
{{"issues_found": ["issue 1", "issue 2", ...], "phd_fit_warning": true_or_false, "revised_document": "... full revised document ..."}}

If no serious issues found, revised_document should be the same as the original with only minor polish.
""")
        prompt_file = f.name

    cmd = [
        '/root/.local/bin/cursor',
        '--print', '--trust',
        '--workspace', '/tmp',
        '--model', 'gpt-5.4-medium',
    ]

    try:
        result = subprocess.run(
            cmd,
            input=f"Read {prompt_file} and return ONLY valid JSON.",  # stdin is actually ignored by cursor --print but gives context
            capture_output=True,
            text=True,
            timeout=180,
            cwd='/tmp'
        )
        
        # Try to get output another way - write to a response file
        os.unlink(prompt_file)
        
        # Use a different approach: write to /tmp/response.json via a temp script
        with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False, dir='/tmp') as sf:
            sf.write(f'''#!/bin/bash
cat << 'CURSOREOF' > /tmp/curresponse.json
{{"issues_found": [], "phd_fit_warning": false, "revised_document": "original"}}
CURSOREOF
echo "Read {prompt_file} and return ONLY valid JSON with issues_found, phd_fit_warning, revised_document." > /tmp/cursor_task.txt
/root/.local/bin/cursor --print --trust --workspace /tmp --model gpt-5.4-medium "$(cat /tmp/cursor_task.txt)" 2>/dev/null | grep -o '{{.*}}' | head -1 > /tmp/curresponse.json 2>/dev/null || true
''')
            sf.flush()
            script_file = sf.name

        # Direct approach: use subprocess with shell redirection
        r = subprocess.run(
            f"""exec 2>&1; /root/.local/bin/cursor --print --trust --workspace /tmp --model gpt-5.4-medium "$(cat << 'EOF' | python3 -c 'import sys,json; print(json.dumps(sys.stdin.read()))'
Read {prompt_file} and return ONLY valid JSON with fields: issues_found, phd_fit_warning, revised_document.
EOF
)" """,
            shell=True,
            capture_output=True,
            text=True,
            timeout=180
        )
        
        output = r.stdout.strip()
        # Try to extract JSON
        start = output.find('{')
        end = output.rfind('}') + 1
        if start >= 0 and end > start:
            return json.loads(output[start:end])
    except Exception as e:
        pass
    
    return {"issues_found": [], "phd_fit_warning": False, "revised_document": document}


def main():
    parser = argparse.ArgumentParser(description='Review and refine resume or CL')
    parser.add_argument('--type', required=True, choices=['resume', 'cl'])
    parser.add_argument('--input', required=True, help='Input document text')
    parser.add_argument('--context', required=True, help='JSON context string')
    parser.add_argument('--output', required=True, help='Output file path')
    args = parser.parse_args()

    system_prompt = RESUME_SYSTEM_PROMPT if args.type == 'resume' else CL_SYSTEM_PROMPT
    
    result = call_cursor_review(args.input, args.type, args.context, system_prompt)
    
    revised = result.get('revised_document', args.input)
    with open(args.output, 'w') as f:
        f.write(revised)
    
    issues = result.get('issues_found', [])
    warning = result.get('phd_fit_warning', False)
    
    analysis_output = args.output + '.analysis.json'
    with open(analysis_output, 'w') as f:
        json.dump({k: v for k, v in result.items() if k != 'revised_document'}, f, indent=2)
    
    print(f"Revised: {args.output}")
    if issues:
        print(f"Issues: {len(issues)} - see {analysis_output}")
    if warning:
        print("⚠️  PhD fit warning")


if __name__ == '__main__':
    main()
