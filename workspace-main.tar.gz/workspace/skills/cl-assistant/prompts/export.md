# CL Export — Prompt

## Task

Export a cover letter to a specific format.

## Input

- **Cover Letter**: `{{cover_letter}}` (Markdown)
- **Format**: `{{format}}` (pdf, markdown, html)
- **Template**: `{{template}}` (academic, professional, modern)

---

## Export Specifications

### Markdown
Return the cover letter as clean Markdown with proper heading structure.

### HTML
Return a self-contained HTML file with:
- Embedded CSS
- Professional typography (serif fonts for academic, sans-serif for modern)
- Print-optimized (@media print)
- Appropriate color theme:
  - Academic: Navy/charcoal, formal serif
  - Professional: Dark grey, clean sans-serif
  - Modern: Teal accents, contemporary layout

### PDF
Convert HTML to PDF using one of these methods (in order of preference):
1. `pandoc --pdf-engine=wkhtmltopdf` (if available)
2. `wkhtmltopdf` directly
3. `chromium --print-to-pdf`
4. Save as HTML and note print instructions for user

---

## Output

Return the converted file content (for HTML/Markdown) or the file path (for PDF).
