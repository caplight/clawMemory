# CL Customize — Prompt

## Task

Customize an existing cover letter for a new specific job/PhD position.

## Input

- **Existing Cover Letter**: `{{cover_letter}}`
- **Target Job Description**: `{{job_description}}`
- **Language**: `{{language}}`

---

## Step 1 — Gap Analysis

Compare the existing CL against the new job description:

| Aspect | Current CL | New Position | Action |
|--------|-----------|--------------|--------|
| Opening | What it says | What it needs | Rewrite? |
| Experience 1 | [topic] | [required skill/theme] | Strengthen / keep |
| Experience 2 | [topic] | [required skill/theme] | Strengthen / keep |
| Research Directions | [old directions] | [new themes] | Replace with new |
| Tone/Length | [current] | [expected] | Adjust |

---

## Step 2 — Opening Rewrite

Rewrite the opening to:
- Directly name the new position and institution
- Express genuine, specific motivation for this project
- Replace any project-specific references from the old CL

---

## Step 3 — Research Directions Update

Generate new research directions that:
- Align with the new project's themes and methodology
- Maintain the user's voice and genuine interests
- Show specific understanding of the new position's challenges
- Replace directions that no longer fit the new project

---

## Output Format

```
## 🔄 Gap Analysis

| Aspect | Current | New Position | Action |
|--------|---------|--------------|--------|
| ... | ... | ... | ... |

---

## ✨ Customized Cover Letter

[Complete customized cover letter following the standard CL structure]

---

## 📋 Changes Made

### Opening
[What changed and why]

### Experience Evidence
[What stayed, what was strengthened, what was de-emphasized]

### Research Directions
[Old → New mapping]

### Overall Adjustments
[Any tone, length, or style adjustments]
```
