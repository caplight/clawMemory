# CL Generate — Prompt

## Task

Generate a compelling cover letter from user background and target position.

## INPUT

- **User Background**: `{{user_background}}`
- **Job Title**: `{{job_title}}`
- **Institution**: `{{institution}}`
- **Job Description**: `{{job_description}}` (if provided)
- **Language**: `{{language}}`
- **Output Mode**: `{{output_mode}}` (default: `submission-ready`)

---

## WRITING RULES (MANDATORY)

These rules override all other style guidance. Write like a real person, not a template.

1. **NO em dashes** — use commas, semicolons, or split into separate sentences instead
   - BAD: "My thesis addressed latency sensitivity — a key challenge in IoT deployments"
   - GOOD: "My thesis addressed latency sensitivity, which is a key challenge in IoT deployments"

2. **NO bullet points, numbered lists, or section headers inside the letter body** — pure prose only

3. **Vary sentence rhythm** — mix short and long sentences. A paragraph with all long sentences reads like a wall. One short sentence can land like a punch.

4. **Be specific with evidence** — name the technology, give the number, cite the outcome
   - GOOD: "The orchestrator I built handled 10,000 messages per second with 99.5% uptime"
   - BAD: "The system performed well"

5. **Bridge explicitly between past work and this opportunity** — every experience paragraph should explain WHY it connects to this PhD/project, not just WHAT you did

6. **Match the JD language** — if they say "fault isolation" use that exact phrase; if they say "observability" use that word

7. **Genuine enthusiasm, not performative excitement** — "I am excited" reads hollow; show it through specific alignment instead

8. **No emoji, no bold, no italic inside the letter body** — plain text only

---

## OUTPUT MODES

Generate **both** versions every time:

### Mode 1: `submission-ready` (default)
- Clean final letter: NO markdown heading, NO emoji, NO separators, NO postal-address block
- First-person prose, appropriate for direct submission (PDF or email)
- No placeholders except `[Your Name]` at the bottom
- This is what the user should send

### Mode 2: `structured-draft`
- Annotated draft with section headers, internal notes, and structure visible
- Includes: research fit analysis, bridge logic explanation, optional checklist
- Useful for review, iteration, and learning

---

## Step 1 — Extract Key Information

From the job description (if provided), extract:
- **Core research theme** of the position
- **Key technical requirements** (methods, tools, domains)
- **Group/institution characteristics** (lab name, research focus, community)
- **Keywords** the committee cares about
- Whether the project **explicitly invites research directions** (check phrasing: "research plan", "future directions", "proposal")

If no job description provided, use general knowledge of the institution and field to frame the CL appropriately.

---

## Step 2 — Map Background to Position

Identify 2-3 strongest connections between the user's background and the position:
- Which projects/achievements are most relevant?
- What is the logical bridge between past work and the PhD/project?
- What data/metrics can be cited to support each claim?

---

## Step 3 — Research Directions Decision

- If the job description **explicitly invites** research directions: include 1-2 tightly scoped ideas (see Writing Rules)
- If the job description does NOT invite them: omit the numbered list entirely; embed any future direction into the closing paragraph in prose

---

## OUTPUT FORMAT

### Mode 1: submission-ready

```
[Date: Month Day, Year]

Dear [Recipient / Members of the Selection Committee],

[Opening paragraph: name the position and institution, express specific motivation, establish fit]

[Experience paragraph 1: what you did, specific achievement with data, bridge to the PhD topic]

[Experience paragraph 2: what you did, specific achievement, bridge to the PhD topic]

[Optional: 1-2 research directions only if explicitly invited, embedded in prose or a very short list]

[Closing paragraph: genuine fit with the group, thank you, invitation to discuss further]

Sincerely,
[Your Name]
```

### Mode 2: structured-draft

```
## Internal Analysis

**Research Fit:** [Why this project matches the user's background, 2-3 sentences]

**Bridge Logic:**
- Experience 1 to PhD project: [specific connection]
- Experience 2 to PhD project: [specific connection]

**Research Directions:** [Only if invited by the JD, 1-2 sentences]

---

## Draft Cover Letter: {{job_title}} at {{institution}}

[Annotated draft with section labels visible]

[Opening] [Why it works]
[Experience 1] [Bridge to PhD]
[Experience 2] [Bridge to PhD]
[Research Directions] [Only if invited]
[Closing] [Fit statement]
```

---

## Quality Checklist

Before outputting, verify:
- [ ] Writing Rules followed (no em dashes, natural prose, sentence rhythm)
- [ ] Opening directly names the position and institution
- [ ] Every experience paragraph has: context, specific data, bridge to PhD
- [ ] Research directions only included if explicitly invited
- [ ] No fabricated lab/paper/methodology names
- [ ] No spelling or grammar errors
- [ ] Length is appropriate: 400-700 words for PhD CL
- [ ] Closing expresses genuine research fit with the group
- [ ] submission-ready version has NO emoji, NO markdown, NO separators
