# CL Polish — Prompt

## Task

Polish and improve an existing cover letter.

## Input

- **Cover Letter**: `{{cover_letter}}`
- **Language**: `{{language}}`

---

## Step 1 — Checklist Review

Evaluate the CL across these categories:

### Structure (20 pts)
- [ ] Opens directly with position + institution
- [ ] Clear flow: opening → experience evidence → closing
- [ ] Logical paragraph transitions
- [ ] No unnecessary sections (e.g., no heavy research directions list unless invited)

### Evidence Quality (30 pts)
- [ ] Every claim backed by specific project/achievement
- [ ] Quantified data present (numbers, percentages, timeframes)
- [ ] Data is realistic and verifiable
- [ ] No vague generalities
- [ ] No fabricated lab/paper/methodology names

### Bridge Logic (25 pts)
- [ ] Each experience paragraph connects to PhD/project
- [ ] Logical bridges are explicit and clear
- [ ] No experience listed without purpose
- [ ] Unique background strengths are highlighted

### Research Directions (10 pts)
- [ ] Only included if explicitly invited by job description
- [ ] If included: 1-2 tightly scoped ideas (not 4-6 broad ones)
- [ ] Each direction has: problem + method + evaluation dimension
- [ ] Embedded in prose OR very short numbered list

### Language & Tone (15 pts)
- [ ] No spelling/grammar errors
- [ ] Professional but genuine tone
- [ ] Sounds like a future researcher, not a job applicant
- [ ] Appropriate length (500-800 words for PhD)
- [ ] Demonstrates research fit, not just professional polish

---

## Step 2 — PhD Guardrail Check ⚠️

Verify these before polishing:
- [ ] No invented lab names, professor papers, or dataset names
- [ ] No overstatement of familiarity with the group's work
- [ ] Closing emphasizes research fit, not just "I am motivated"
- [ ] If research directions are present: they have specific problem + method + evaluation

---

## Step 3 — Polished Version

Output the fully polished cover letter with:
- Stronger transitions
- Added quantified evidence where missing
- Clearer bridge logic
- Fixed grammar/structure issues
- Research directions trimmed to 1-2 if too many or too vague

---

## Output Format

```
## 📊 Polish Score: X/100

### Top Issues
1. [Most critical issue]
2. [Second issue]
3. [Third issue]

### Checklist Summary
- Structure: X/20
- Evidence Quality: X/30
- Bridge Logic: X/25
- Research Directions: X/10
- Language & Tone: X/15

### PhD Guardrail Check ⚠️
- [ ] No fabricated specifics
- [ ] Research fit emphasized
- [ ] Directions only if invited

---

## ✨ Polished Cover Letter

[paste polished version — submission-ready (no emoji, no markdown headings, no postal addresses)]

---

## 🔧 Specific Improvements Made

1. [Change made]
2. [Change made]
3. [Change made]
```
