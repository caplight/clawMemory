# 📄 Cover Letter Assistant / CL 生成助手

> AI驱动的 Cover Letter 生成、润色、定制工具，专为 PhD 申请和职位申请设计。
**版本：** 1.0.0 · **许可证：** MIT

---

## 功能概览

CL Assistant 遵循**已验证的写作模式**，帮助生成结构清晰、逻辑严密、有说服力的 Cover Letter：

- ✅ **Opening** — 身份 + 目标 + 为什么选这个项目
- ✅ **Experience Evidence** — 具体项目 + 数据 + 过渡到 PhD 的逻辑
- ✅ **Research Directions** — 编号列表，具体可执行
- ✅ **Closing** — 真诚的兴趣表达

---

## 使用方式

### 自然语言（推荐）

```
💬 "Generate a cover letter for a PhD position"
💬 "Polish my cover letter"
💬 "Customize my CL for this job description"
💬 "Export to PDF"
```

### 命令模式

```
/cl generate     — 从背景信息生成 CL
/cl customize    — 为特定职位定制已有 CL
/cl polish       — 润色改进现有 CL
/cl export       — 导出为 PDF/Markdown/HTML
```

---

## 推荐工作流

```
1. /cl generate   ← 从背景生成草稿
        ↓
2. /cl polish     ← 润色结构和语言
        ↓
3. /cl customize  ← 针对具体申请定制
        ↓
4. /cl export     ← 导出 PDF
```

---

## 项目结构

```
cl-assistant/
├── skill.json                    # 技能清单
├── SKILL.md                     # 技能文档
├── prompts/
│   ├── system.md                # 角色定义 & 写作原则
│   ├── generate.md              # 生成提示词
│   ├── customize.md             # 定制提示词
│   ├── polish.md               # 润色提示词
│   └── export.md               # 导出提示词
├── templates/
│   ├── academic.md             # 学术 PhD CL 模板
│   ├── professional.md          # 专业工作 CL 模板
│   └── modern.md                # 现代风格模板
└── examples/
    └── sample-cl-en.md          # 示例 CL
```

---

## CL 写作结构（核心原则）

### Opening 段落公式
> 身份 + 目标职位 + 为什么是这个项目（具体动机）

### Experience Evidence 段落公式
> [项目背景] → [具体成果+数据] → [过渡到 PhD 课题的逻辑]

**关键：不要只列举经历，要说明"这个经历如何应用到 PhD 课题"**

### Research Directions 列表
- 编号列表（3-6项）
- 每条 = 具体可执行的研究方向
- 展示对项目和学校的真实了解

### Closing 段落
- 强烈的兴趣表达
- 真诚地说明与该研究组的契合度
- 简洁专业的感谢

---

## 配置

| 参数 | 值 | 说明 |
|------|-----|------|
| `max_cl_length` | 8,000 字符 | 最大输入长度 |
| `supported_languages` | `en` | 仅支持英文 |
| `supported_export_formats` | pdf, markdown, html | 导出格式 |
