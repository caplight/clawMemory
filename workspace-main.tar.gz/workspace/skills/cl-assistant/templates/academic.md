# Academic PhD Cover Letter Template

```
[Your Name]
[Your Address]
[City, Postal Code]
[Phone] | [Email]

[Date: Month Day, Year]

[Recipient Name / Title]
[Department / Institution]
[Address]

Dear [Recipient Name / Members of the Selection Committee],

[OPENING — 1 paragraph, 80-100 words]
I am writing to apply for the [position title] position at [institution]. I hold [degree] from [university] and currently work as [role] at [company]. I am particularly excited about [specific aspect of the project] because [genuine motivation that shows you've researched the project].

---

[EXPERIENCE EVIDENCE — 1-2 paragraphs, 200-300 words]

Paragraph 1: MSc/academic experience
In my [academic project / MSc thesis], I [project context] — achieving [specific metric/result]. This directly applies to [aspect of PhD project] because [logical bridge]. The methodology also developed my skills in [relevant techniques].

Paragraph 2: Industry/work experience (if applicable)
In my current role at [company], I have been working on [project context] — resulting in [specific achievement with data]. This experience strengthened my ability to [relevant skill], which I see as essential for [aspect of PhD project].

---

[RESEARCH DIRECTIONS — 3-6 numbered items, 150-200 words]
My research directions for this position include:
1. [Specific direction — name the methodology and its application]
2. [Specific direction — show understanding of the project's challenges]
3. [Specific direction — leverage user's unique background]
4. [Optional: additional direction]
5. [Optional: extension using novel methods]

---

[CLOSING — 1 paragraph, 60-80 words]
I am highly motivated to pursue this research within [group/institution name], whose emphasis on [specific characteristic of the group] strongly resonates with my own goals. [Optional: name specific faculty member or paper that inspires you]. I would welcome the opportunity to discuss how my background could contribute to this project.

Thank you for your time and consideration.

Sincerely,
[Your Name]
```

## Word Count Guide
- Total: 500-800 words
- Opening: 80-100 words
- Experience: 200-300 words
- Research Directions: 150-200 words
- Closing: 60-80 words
