# Sample Cover Letters

> ⚠️ These examples use the updated format: research directions are embedded in prose or very short lists, with specific problem + method + evaluation dimensions. Only included when the project description invites them.

---

## Example 1: PhD Application (TU Delft — Self-Organizing Edge Infrastructure)

Dear Members of the Selection Committee,

I am writing to express my sincere interest in the PhD position "Self-Organizing Edge Infrastructure for the Next-Generation Internet." With a Distinction-level MSc in Advanced Computer Science from Newcastle University and practical experience in orchestration systems, data engineering, and applied AI, I am very motivated to contribute to the SPEAR Lab's work on building an intelligent, autonomous Internet infrastructure.

During my master's degree, I developed a full data-flow orchestration platform in Go to coordinate IoT devices across diverse environments. This project required me to design for latency sensitivity, hybrid data formats, and real-time device management—all challenges that also appear in large-scale edge systems. Through building a dynamic routing-table model using Redis, deploying the orchestrator through Kubernetes, and validating it across multiple real-world scenarios, I gained confidence in solving distributed-system problems in a structured and reliable way. These experiences naturally shape my motivation to continue researching smarter and more autonomous networked systems.

In my current role at Carrier's R&D center, I have been working on data and AI pipelines, including RAG architectures, knowledge graph construction, and predictive analysis for HVAC diagnostics. These projects strengthened my ability to work with large, complex datasets and design systems that integrate smoothly with real operational environments. They also taught me the importance of clarity, consistency, and reliability in data flows—principles that I believe are essential when designing the next generation of edge infrastructure.

I am highly motivated to pursue this research within the SPEAR Lab, whose emphasis on autonomous, self-organizing networked systems strongly resonates with my professional goals. My near-term interest lies in exploring how unit-profile standardization could enable more intelligent device coordination, building on the orchestration experience I developed during my MSc while incorporating the AI-driven predictive methods I now apply in industrial diagnostics. I would welcome the opportunity to discuss how my background could contribute to this project.

Thank you for your time and consideration.

Sincerely,
Wei Zhu

---

### Internal Analysis (for structured-draft reference)

**Research Fit:** SPEAR Lab's focus on autonomous edge infrastructure maps directly to my MSc work on distributed orchestration + current work on predictive AI systems for industrial IoT.

**Bridge Logic:**
- MSc orchestration platform (Go, Redis, Kubernetes) → distributed system coordination challenges in edge infrastructure
- Carrier AI/ML pipelines (RAG, KG, predictive diagnostics) → AI-driven monitoring and failure prediction for edge nodes

**Research Directions:** Not explicitly invited in the posting, so embedded in closing paragraph as a single tightly scoped idea rather than a numbered list.

---

## Example 2: PhD Application (VU Amsterdam — ML Accelerator Programming)

Dear Dr. De Matteis and Selection Committee,

I am writing to apply for the PhD position in ML Accelerator Programming for HPC and Scientific Computing at Vrije Universiteit Amsterdam. I hold an MSc in Advanced Computer Science (Distinction) from Newcastle University and currently work as an R&D engineer at Carrier Research & Development Center. I am strongly motivated by this project's objective of making emerging ML accelerators and spatial devices accessible, productive, and usable for the wider scientific community.

Through both academic and industrial experience, I have developed a solid foundation in systems building, quantitative evaluation, and developer tooling. My MSc dissertation focused on the design and experimental validation of a scalable architecture for heterogeneous edge–cloud systems, including workload characterization, performance benchmarking, and resilience evaluation under realistic and adversarial conditions. In industry, I have designed and deployed end-to-end AI systems, including Retrieval-Augmented Generation pipelines, real-time data processing workflows, and CUDA-accelerated model fine-tuning. Across these projects, system design decisions were guided by profiling, quantitative metrics, and experimental validation.

A key strength I bring to this PhD is experience in human-centered tooling for complex systems. I have conducted user interviews, led UI/UX design for engineering tools, and translated domain-specific functionality into accessible workflows for non-expert users. I see this as directly aligned with the challenge of enabling domain scientists to productively use ML accelerators without requiring deep hardware expertise.

My research directions for this position include:
1. Characterizing non-ML scientific workloads on spatial accelerators by profiling memory access patterns and data reuse distances, with evaluation against performance-per-watt and throughput relative to CPU baselines.
2. Iteratively prototyping domain-specific abstractions through user studies with computational scientists, measuring productivity gains and error rates against manual kernel coding.

I am highly motivated to pursue this research within the Massivizing Computer Systems group at VU Amsterdam, whose emphasis on experimental systems research, open artifacts, and community impact strongly resonates with my own goals. I would welcome the opportunity to discuss how my background and research direction could contribute to this project.

Thank you for your time and consideration.

Sincerely,
Wei Zhu

---

### Internal Analysis (for structured-draft reference)

**Research Fit:** VU Massivizing group's focus on performance engineering + developer tooling aligns with my MSc systems work and industry experience building tools for non-expert users.

**Bridge Logic:**
- MSc performance benchmarking + heterogeneous systems → quantitative evaluation methodology for accelerator profiling
- Carrier UX design for engineering tools → user-centered approach to accelerator abstraction design

**Research Directions:** Explicitly invited by the project description's focus on "programming models and tools." Included as 2 tightly scoped items (not 5+), each with problem + method + evaluation dimension.

---
