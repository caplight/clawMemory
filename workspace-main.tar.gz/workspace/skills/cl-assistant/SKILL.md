# 📄 Cover Letter Assistant

> AI-powered clawbot skill for generating, polishing, and customizing cover letters for PhD applications and job postings, following proven structural patterns.
**Version:** 1.1.0 · **License:** MIT

---

## Overview

Cover Letter Assistant helps job seekers and PhD applicants create compelling, structured cover letters. It follows a **proven writing pattern** distilled from successful real-world cover letters, emphasizing:

- **Specific project evidence** with quantified results
- **Logical bridges** between past experience and target research/project
- **Research fit over structure** (PhD committees screen for research potential, not just writing quality)
- **Professional academic tone** for PhD applications

⚠️ **PhD Guardrails:** This skill does NOT fabricate lab names, professor papers, or methodology details. Research directions are only included when explicitly invited by the job description.

---

## Writing Pattern (Proven Structure)

### 1. Opening (1 paragraph)
- Identity + degree/milestone
- Target position + institution
- Why this specific project (genuine motivation)

### 2. Experience Evidence (1-2 paragraphs)
- **Paragraph = Project context → Specific achievement (with data) → Transition to PhD topic**
- Never just list achievements — always connect them to the PhD/project
- Use quantified data: 80,000 rows, 92% accuracy, CUDA fine-tuning, etc.

### 3. Research Directions (optional, 1-2 items only if invited)
- **Only include when job description explicitly invites research directions**
- Each = concrete problem + method + evaluation dimension
- Prefer embedded prose over heavy numbered lists

### 4. Closing (1 paragraph)
- Strong research fit statement
- Genuine interest in the group
- Brief, professional thank you

---

## Output Modes

Every generate and polish output includes **two versions**:

### Mode 1: `submission-ready` (default)
- Clean final letter
- **NO** markdown heading, **NO** emoji, **NO** separators, **NO** postal addresses
- First-person prose, appropriate for direct submission (PDF/email)
- What the user should actually send

### Mode 2: `structured-draft`
- Annotated draft with internal notes
- Includes: research fit analysis, bridge logic, checklist
- Useful for review, iteration, and learning

---

## Commands

### `/cl generate`

Generate a cover letter from user background + target position.

| Name | Required | Default | Description |
|------|---------|---------|-------------|
| `user_background` | ✅ | — | User's experience, education, skills |
| `job_title` | ✅ | — | Target position title |
| `institution` | ✅ | — | Target university/institution |
| `job_description` | — | — | Full job posting (recommended) |
| `language` | — | `en` | `en` (English only) |

**Output:** Both `submission-ready` + `structured-draft` versions.

---

### `/cl customize`

Customize an existing cover letter for a new position.

| Name | Required | Default | Description |
|------|---------|---------|-------------|
| `cover_letter` | ✅ | — | Existing CL text |
| `job_description` | ✅ | — | Target job/PhD project description |
| `language` | — | `en` | `en` |

**Output:** Gap analysis + customized CL in both modes.

---

### `/cl polish`

Polish and improve an existing cover letter.

| Name | Required | Default | Description |
|------|---------|---------|-------------|
| `cover_letter` | ✅ | — | CL text to polish |
| `language` | — | `en` | `en` |

**Output:** Score breakdown + polished CL in both modes.

---

### `/cl export`

Export cover letter to PDF, Markdown, or HTML.

| Name | Required | Default | Description |
|------|---------|---------|-------------|
| `cover_letter` | ✅ | — | CL content (Markdown) |
| `format` | ✅ | — | `pdf` \| `markdown` \| `html` |
| `template` | — | `academic` | `academic` \| `professional` \| `modern` |

---

## Recommended Workflow

```
1. /cl generate   ← From scratch with your background
        ↓
2. /cl polish    ← Fix structure, flow, grammar, guardrails
        ↓
3. /cl customize ← Tailor for specific application
        ↓
4. /cl export    ← Generate PDF
```

---

## Project Structure

```
cl-assistant/
├── skill.json                    # Skill manifest
├── SKILL.md                     # This documentation
├── prompts/
│   ├── system.md                # Persona, principles, PhD guardrails
│   ├── generate.md              # Generation prompt (two output modes)
│   ├── customize.md             # Customization prompt
│   ├── polish.md                # Polish prompt
│   └── export.md               # Export prompt
├── templates/
│   └── academic.md             # Academic PhD CL template
└── examples/
    └── sample-cl-en.md          # Example CLs with internal analysis
```

---

## Configuration

| Key | Value | Description |
|-----|-------|-------------|
| `max_cl_length` | 8,000 chars | Maximum input length |
| `supported_languages` | `en` | English only |
| `supported_export_formats` | pdf, markdown, html | Export formats |

---

## PhD Guardrails ⚠️

- **No fabrication** — never invent lab names, professor papers, or methodologies not in the job description
- **Research directions only if invited** — only include when job explicitly asks for them
- **1-2 tightly scoped ideas** — not 4-6 broad ones; each with problem + method + evaluation
- **Research fit > structure** — committees screen for future researcher potential, not writing polish
