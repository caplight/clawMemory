# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## PhD 申请系统

### 关键路径
- **脚本目录：** `/home/cap/script/`
- **日志目录：** `/home/cap/logs/scrapers/`
- **备份目录：** `/home/cap/backup/

### Cron 任务
- **18:00：** `run_all_scrapers.sh` — 爬虫 + 评分 + 飞书报告
- **21:00：** `backup-workspaces.sh` — GitHub备份 + 飞书通知

### 管理命令
```bash
# 爬虫管理
bash /home/cap/script/run_all_scrapers.sh  # 手动运行

# 日志服务
bash /home/cap/script/conversation-logger.sh start/status/stop
bash /home/cap/script/conversation-logger-web.sh start/status/stop
```

### Cursor CLI（编码任务专用）
- **安装路径：** `/root/.local/share/cursor-agent/versions/2026.04.08-a41fba1/`
- **命令：** `cursor`（或 `/root/.local/bin/cursor`）
- **API Key：** `crsr_52a93dc742cd3f3a9934e09a364b49634f9457ead0f27bc81a7954912819d8eb`（Cursor Enterprise）
- **Wrapper：** `/root/.local/bin/cursor`（已预置 API key）

#### 常用命令模式

**默认模型：gpt-5.4-medium。不许擅自更换，除非用户明确要求。**

**1. 非交互式（headless / 脚本用）**
```bash
# 默认 gpt-5.4-medium
cursor --print --trust "任务描述"

# 指定其他模型（需用户明确指令）
cursor --print --trust --model gpt-5.3-codex-high "任务描述"

# 流式输出（实时看到进度）
cursor --print --stream-partial-output --trust "任务描述"
```

**2. 指定工作目录**
```bash
cursor --print --trust --workspace /path/to/project "任务描述"
```

**3. 指定模型**
```bash
cursor --print --trust --model auto "自动选择最佳模型"
cursor --print --trust --model composer-2 "Cursor Composer"
cursor --print --trust --model gpt-5.3-codex-high "GPT-5.3 Codex High"
```

**4. YOLO 模式（跳过所有确认，直接执行）**
```bash
cursor --print --yolo "危险任务，强制执行所有命令"
```

**5. 交互模式**
```bash
cursor  # 无参数，进入交互式对话
```

#### 可用模型（--list-models 输出）
- `gpt-5.4-medium` — GPT-5.4 中等版（默认）
- `claude-4-sonnet` / `claude-4-sonnet-1m` / `claude-4-sonnet-thinking`
- `composer-2-fast` / `composer-2` — Cursor Composer
- `gpt-5.3-codex-high` / `gpt-5.3-codex` 等 — OpenAI Codex 系列
- `gpt-5.1-codex-mini-high` / `gpt-5.4-mini` 等 — GPT-5 系列
- `sonnet-4.5` / `sonnet-4.5-1m` — Sonnet 系列

#### Cursor 编码任务（Orchestrator 模式）
当需要 Cursor 执行编码任务时：
1. 我负责拆解任务、确定目标文件路径和修改内容
2. Spawn Cursor 到对应目录，给清晰指令
3. 监控进度（后台跑输出到日志文件）
4. 验证结果

```bash
# Spawn Cursor 编码任务（后台运行）
cd /目标目录 && git init -q 2>/dev/null; \
  /root/.local/bin/cursor --print --trust --workspace /目标目录 \
  '任务描述。当完全完成后，运行: openclaw system event --text "Done: [简要说明]" --mode now' \
  > /tmp/cursor_<任务名>.log 2>&1 &
```

#### ⚠️ 重要：Cursor vs Codex
- **Cursor CLI 使用 Cursor Enterprise API key**，不需要额外配置 base_url
- **Cursor 支持模型更多**（Claude/GPT-5/Composer 等）
- **所有编码任务统一用 Cursor，不再用 Codex**

### Codex CLI（已卸载）
> ⚠️ 已于 2026-04-10 卸载，所有编码任务迁移至 Cursor CLI

### JobTracker 系统（就业岗位追踪）
- **脚本目录：** `/home/cap/script/JobTracker/`
- **数据库：** `job_tracker.jobs`（MySQL）
- **Notion 数据库：** `40798fd9-41f3-4ebd-98f1-d109b7c4ae5e`
- **Cron：** 每天 17:00（JobSpy+JSearch）、21:30（仅 JobSpy，--skip-jsearch）
- **API Key（MiniMax）：** 同 PhD 系统（base: `https://api.minimaxi.com/v1`）
- **JSearch Key：** `3bc7079c6cmshe76660c0ee787e2p11ad3cjsnf27b140f2ae4`

### 数据库
```bash
mysql -u root -proot2026pass phd_jobs -e "SELECT COUNT(*) FROM jobs"
```

## API Keys

| 服务 | Key |
|------|-----|
| MiniMax | `sk-cp-fQZxgx_WiWnu46I4AEHhprLAhHEVlr6_7s9vsTrX5Z-1rdhKPzo_8q-KrDdvlv_VhIgmMS3b7OK80MiM-4-f9Ni7PJx-p_98nqJUMRSaUrIpKge8rDTx-RE` |
| Notion | `[NOTION_TOKEN_REDACTED]` |
| GitHub | `[GITHUB_TOKEN_REDACTED]` |

## 飞书 Bot

| Bot | App ID | App Secret |
|-----|--------|------------|
| main | `cli_a931578e07789cc7` | `QIhhKSds6xR2SpmEmSwgIbdD2lCcJf2w` |
| newbot | `cli_a9343ba5a3a2dbd6` | `ckjjFzhjZGqR7fXkyIm8ZdIAAoSBjUyN` |

## Web 服务

| 服务 | URL |
|------|-----|
| 对话日志 Web UI | http://127.0.0.1:5000 |
| Notion 数据库 | https://www.notion.so/329267b2de94814a0a6aaf2f77cb5b1a2 |
| GitHub 备份 | https://github.com/caplight/clawMemory |

---

Add whatever helps you do your job. This is your cheat sheet.

## 浏览器控制：Pinchtab
- **已安装：** v0.8.5（`/usr/local/bin/pinchtab`）
- **Token：** `16f5906eb44c584e3d7a7ff1a6569281abc1b2b5e0411f03`
- **端口：** localhost:9867
- **启动服务：** `nohup pinchtab server > /tmp/pinchtab.log 2>&1 &`
- **常用命令：**
  - `pinchtab nav <url>` — 导航
  - `pinchtab screenshot` — 截图
  - `pinchtab text` — 获取文本
  - `pinchtab find <query>` — 查找元素
  - `pinchtab click <ref>` — 点击元素
  - `pinchtab tabs` — 查看标签页
- **注意：** eval 被安全策略禁用，nav 到外部 URL 也可能被拦截（remote IP blocked）

## 网页爬虫：Scrapling
- **已安装：** v0.4.2（`pip install scrapling`）
- **CLI 命令：** `scrapling extract <mode> <url> <output_file>`
- **模式：** get（基础）、fetch（浏览器）、stealthy-fetch（反爬绕过）
- **Python API：** `from scrapling import Autoparser`

## 携程机票爬虫
- Playwright（`pip install playwright`）比 scrapling 更适合携程（自定义日期控件需要 Playwright 操作）
- 携程 URL 格式：`https://flights.ctrip.com/online/list/oneway-sha-{dest}?depdate=2026-04-30&cabin=Y_S_C_F`
