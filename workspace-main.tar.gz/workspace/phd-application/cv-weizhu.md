# Wei Zhu - CV for PhD Application Review

**Contact:** caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/

## Education

**Newcastle University (UK), MSc Advanced Computer Science** — Sep 2021 - Nov 2022
- Grade: 72/100 (Distinction / First Class Honours)
- Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware, Information Security, System Security, Security and Resilience
- Thesis: The Data Flow Orchestration Platform (Score: 72, Top 5%)

**Guangzhou University Sontan College, BEng Software Engineering** — Sep 2017 - May 2021
- Grade: 84/100
- Honors: Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

## Professional Experience

**Carrier Research & Development Center (Shanghai)** — Jul 2023 - Present
Engineer Leadership Program (R&D Trainee), MASC&DI

1. **AI Architect / Engineer - RLC Real-Time Fault Detection Platform**
   - Designed real-time analytics orchestration architecture on AWS EKS
   - Components: Terminal Edge, Kafka, Flink, ClickHouse, Argo Agent System
   - Built automated inference pipeline using LLMs + regression models + physical models
   - Capabilities: refrigerant leakage and coil blockage detection for HVAC systems

2. **AI / Data Engineer - Intelligent Diagnosis Service & Solution Recommendation**
   - Led GenAI solution design using RAG architecture (Python, Hugging Face, LangChain, AnythingLLM, Ollama)
   - Built automated data pipelines for 80,000+ rows of heterogeneous data
   - Fine-tuned translation models using LoRA (150% training speed improvement with CUDA)
   - Constructed knowledge graph using Neo4j for semantic labeling and graph reasoning
   - Optimized LLaMA and DeepSeek models, increasing QA accuracy to 92%+

3. **Frontend Developer & Scrum Master - ECAT Project**
   - Served as acting Scrum Master, facilitated 10+ standups, managed 20+ JIRA items
   - Mentored 9 engineers, collaborated with global teams
   - Reduced AWS cloud resource usage by 70%, overall cost decrease 5-10%

**Accenture (China) Co., Ltd.** — Jan 2023 - Jul 2023
Frontend Developer (Cathay Pacific Vera Chatbot Project)
- Delivered core features, improved response time by 30%

## Research Experience

**The Data Flow Orchestration Platform** — 2022
12,000-word dissertation | Distinguished Grade (Top 5%)

- **Objective:** Analyzed pain points of smart city and medical IoT. Designed novel architecture for edge-cloud data transfer, addressing latency sensitivity, cross-platform deployment, and hybrid data format processing.

- **Key Contributions:**
  - Semi-structured user interviews with academic and industry collaborators
  - Dynamic routing table model using Redis for real-time device coordination
  - MessageQueue-as-plugin architecture with comparative analysis of MQTT, Kafka, RabbitMQ

- **Validation:** 10,000 msg/sec throughput, DDoS resilience testing, 5 deployment scenarios

## Skills

- **Programming:** Python, Go, Java
- **Systems/Data Infrastructure:** Kafka, Flink, Kubernetes, Redis, RabbitMQ
- **AI/Generative AI:** RAG, LangChain, Agent Systems, Hugging Face, CUDA
- **Databases/Storage:** MySQL, ClickHouse, Neo4j, Elasticsearch, AWS S3

## References

- Master's thesis supervisor: Prof. Ranjan (Raj.ranjan@newcastle.ac.uk)
- Line manager in Carrier: Liangjiang Yang (Liangjiang.Yang@Carrier.com)
