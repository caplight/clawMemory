# Wei Zhu (朱玮) — Master Resume Library
## 经历素材库（按模块拆分，支持按岗位挑选）

---

## 👤 基本信息

**Name:** Wei Zhu (朱玮)
**Email:** caplight98@gmail.com
**Phone:** +86 181 2239 7704
**LinkedIn:** linkedin.com/in/wadezhu/
**Location:** Shanghai, China

---

## 🎓 教育背景

### MSc Advanced Computer Science
**学校:** Newcastle University, UK
**时间:** Sep 2021 - Nov 2022
**成绩:** 72/100 (Distinction / First Class Honours)
**相关课程:** Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware, Information Security, System Security, Security and Resilience Group Project and Research
**论文:** The Data Flow Orchestration Platform (Score: 72 / Top 5%)

### BEng Software Engineering
**学校:** Guangzhou University Sontan College
**时间:** Sep 2017 - May 2021
**成绩:** 84/100
**荣誉:** Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

---

## 💼 工作经历

### Carrier Research & Development Center (Shanghai) Co., Ltd.
**项目:** Engineer Leadership Program (R&D Trainee), MASC&DI
**时间:** Jul 2023 - Present
**地点:** Shanghai

---

### 项目1: RLC Real-Time Fault Detection Platform
**角色:** AI Architect / Engineer

- Designed real-time analytics orchestration architecture on AWS EKS
- Components: Terminal Edge → Kafka → Flink → ClickHouse → Argo Agent System
- Built automated inference pipeline using LLMs + regression models + physical models
- Led end-to-end design: user's terminal → edge service → Kafka → Flink → ClickHouse → Argo workflows → Agentic systems
- Developed Python + LangGraph agent container that reads the latest 5-minute features from ClickHouse, calls LLM + regression models, executes post-processing, and writes inference results back to ClickHouse
- Capabilities: refrigerant leakage and coil blockage detection for HVAC systems

**技术栈:** AWS EKS, Kafka, Flink, ClickHouse, Argo Workflows, Python, LangGraph, LLM, Regression Models

---

### 项目2: Intelligent Diagnosis Service (RAG + Knowledge Graph)
**角色:** AI / Data Engineer

- Led requirements analysis and process design (Miro) for GenAI applications based on after-sales data
- Designed and implemented company's first Retrieval-Augmented Generation (RAG) architecture using Python, Hugging Face, LangChain, AnythingLLM
- Optimized chunking strategies, deduplication, and token windows on Llama and DeepSeek for significantly improved result accuracy (>92%)
- Analyzed and implemented LoRA and adapter tuning on opus-mt-zh-en for machine translation tasks, evaluated with BLEU and scores from expertise, achieving about 82% satisfaction
- Developed automated pipelines for processing and cleansing over 80,000 rows of after-sales data formats into structured data
- Engineered knowledge graph based on Neo4J, labelled and categorised data into different semantic business tags as fine-tuning dataset
- Applied DBSCAN clustering to identify anomalous patterns in real-time data; evaluated performance using Silhouette Coefficient and domain-expert validation

**技术栈:** Python, Hugging Face, LangChain, AnythingLLM, Llama, DeepSeek, LoRA, Neo4j, DBSCAN, RAG

---

### 项目3: CTD Project (Digital Twins + Predictive Modeling)
**角色:** AI/Data Engineer

- Migrated algorithm ecosystem to output predictive value to help with the qualification of test lib data used to calibrate physical models (Digital Twins)
- Developed Partial Dependence (PD) plots showing interconnection between parameters: system charge vs condenser subcooling vs EXV opening in refrigerant leakage problem
- Collaborated with modelling team, identifying cases where more than 20% refrigerant leakage has occurred

**技术栈:** Digital Twins, Physical Models, Predictive Analytics, Python

---

### 项目4: ECAT Project (Frontend + Scrum Master)
**角色:** Frontend Developer & Scrum Master

- Served as acting Scrum Master, facilitating 10+ standups, managing 20+ JIRA items (Bugs/Features), and ensuring successful deliveries
- Mentored 9 engineers in daily practice
- Collaborated with global teams to refactor and optimize a big front-end application
- Reduced single-module AWS cloud resource usage by 70%, leading to an overall cloud cost decrease of 5-10%

**技术栈:** Angular.js, TypeScript, Node.js, JIRA, AWS

---

### Accenture (China) Co., Ltd.
**时间:** Jan 2023 - Jul 2023
**地点:** Guangzhou
**项目:** Cathay Pacific Vera Chatbot Project

- Delivered core features for Cathay Pacific's Vera Chatbot using Angular.js, TypeScript, and Node.js
- Optimized the price search flow, cutting response time by 30%

**技术栈:** Angular.js, TypeScript, Node.js

---

## 🔬 研究经历

### The Data Flow Orchestration Platform (Master's Thesis)
**时间:** 2022
**学校:** Newcastle University
**字数:** 12,000 words
**成绩:** Distinguished Grade (Top 5%)

- **研究目标:** Analysed pain points of smart city and medical IoT. Designed and implemented a scalable orchestration framework to coordinate heterogeneous IoT devices across edge–cloud layers, addressing latency sensitivity, cross-platform deployment, and hybrid data format processing
- **架构设计:**
  - Created first dynamic routing table model using Redis, enabling real-time device coordination
  - Pioneered MessageQueue-as-plugin architecture with comparative analysis of cutting-edge MQ tech (MQTT, Kafka, RabbitMQ)
- **技术实现:**
  - Engineered Go-based Orchestrator with 95% automated deployment via Kubernetes API
  - Leveraged Gin Framework, exposing 5 core APIs for queue management
  - Implemented Sentinel and Cluster Patterns, achieving 99.5% uptime and reducing service disruption
- **验证与性能:**
  - Benchmarked 10,000 msg/sec throughput with low latency
  - Effective action against DDoS scenarios
  - Simulated and tested in five different real scenarios with diverse data formats

**技术栈:** Go, Gin Framework, Redis, Kubernetes, MQTT, Kafka, RabbitMQ

---

### Research Methods and Group Project in Security and Resilience
**时间:** 2022
**学校:** Newcastle University
**成绩:** 75/100

- Built secure software for cardiac resynchronization therapy (CRT) with thread-safe cryptographic arrays and resilience against MITM attacks

**技术栈:** Cryptography, Thread-safe Systems, Security

---

## 🛠 技能

### 编程语言
Python, Go, Java, TypeScript

### 系统与数据基础设施
Kafka, Flink, Kubernetes, Redis, RabbitMQ, AWS (EC2, S3, EKS), ClickHouse

### AI / 生成式 AI
RAG, LangChain, Agent Systems, Hugging Face, CUDA, LoRA/Adapter Tuning, Knowledge Graphs (Neo4j), LLM (Llama, DeepSeek)

### 数据库与存储
MySQL, Neo4j, Elasticsearch, ClickHouse, AWS S3, Pinecone

### 其他工具/方法
Git, JIRA, Miro, Agile/Scrum, CI/CD, Digital Twins, Physical Modeling

---

## 📌 可选模块（按岗位挑选）

### A. IoT / Edge Computing 专项
- Dynamic routing table model using Redis
- MessageQueue-as-plugin architecture (MQTT/Kafka/RabbitMQ comparative analysis)
- Edge-cloud orchestration, heterogeneous IoT coordination
- Kubernetes API deployment automation
- 99.5% uptime with Sentinel and Cluster patterns

### B. AI / ML / RAG 专项
- First company-wide RAG architecture (LangChain + Hugging Face + AnythingLLM)
- >92% QA accuracy (Llama + DeepSeek optimization)
- LoRA fine-tuning (150% training speed improvement with CUDA)
- Knowledge graph engineering (Neo4j for semantic labeling)
- DBSCAN anomaly detection with Silhouette Coefficient validation

### C. Distributed Systems / Performance 专项
- Go-based Orchestrator with 95% Kubernetes automated deployment
- 5 core APIs via Gin Framework
- 10,000 msg/sec throughput benchmark
- 99.5% uptime architecture
- DDoS resilience testing

### D. Security / DNS Abuse 专项
- Security and Resilience research (75/100)
- MITM attack resilient CRT software
- Thread-safe cryptographic arrays
- Reactive → proactive detection research interest
- Graph-based ML for anomaly detection

### E. Cloud / DevOps / Cost Optimization 专项
- AWS EKS architecture design
- 70% AWS resource reduction → 5-10% overall cost decrease
- Automated CI/CD pipeline understanding
- Cloud cost optimization experience

### F. HCI / AI Programming / Developer Tooling 专项
- LLM integration into real-world workflows
- CUDA-based model training acceleration
- AI-assisted programming environment design
- Human-centered and inclusive computing interest
- Configurable, transparent, user-controlled AI interaction design

### G. Predictive Maintenance / Digital Twins 专项
- Digital Twins for HVAC systems (physical model calibration)
- Refrigerant leakage detection (>20% threshold)
- Partial Dependence (PD) plots for multi-parameter correlation
- Real-time monitoring and decision support systems
- IoT data integration for anomaly detection

### H. NLP / Question Answering 专项
- RAG-based QA system (>92% accuracy)
- NLP pipeline: natural language → structured analytical workflows
- Domain-specific translation model fine-tuning (82% satisfaction)
- 80,000+ unstructured data → structured data pipelines

### I. Scrum / Leadership 专项
- Acting Scrum Master (10+ standups, 20+ JIRA items)
- Mentored 9 engineers
- Global team collaboration
- Sprint planning and process improvement

---

## 📚 参考人

- Master's thesis supervisor: Prof. Ranjan (Raj.ranjan@newcastle.ac.uk)
- Line manager in Carrier: Liangjiang Yang (Liangjiang.Yang@Carrier.com)
