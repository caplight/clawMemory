Wei Zhu

caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/

Researchdriven engineer with a distinctionlevel MSc in Advanced Computer Science (Newcastle University, UK).

Experienced in AI pipelines, model ﬁnetuning, data engineering, and applied machine learning, with a strong

interest in translating naturallanguage questions into structured, executable analytical workﬂows.

Education

Newcastle University(UK), MSc Advanced Computer Science

Sep 2021 - Nov 2022

• Grade: 72/100 (Distinction / First Class Honours)

• Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware,

Information Security, System Security, Security and Resilience Group Project and Research.

• Thesis: The Data Flow Orchestration Platform (Score: 72)

Guangzhou University Sontan College, BEng Software Engineering

Sep 2017 - May 2021

• Grade: 84/100

• Honors: Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

Professional Experience

Carrier Research & Development Center (Shanghai) Co., Ltd.

Jul 2023 - Present

Engineer Leadership Program (R&D Trainee), MASC&DI

Shanghai

• AI / Data Engineer

– Designed and implemented the company’s ﬁrst Retrieval-Augmented Generation (RAG) architecture using

Python, Hugging Face, Langchain, and AnythingLLM to support internal Q&A and decisionsupport tools.

– Optimized chunking strategies, deduplication, and token windows on Llama and DeepSeek for signiﬁcantly

improved result accuracy (>92%).

– Analyzed and implemented LoRA and adapter tuning on opus-mt-zh-en for machine translation tasks,

evaluated with BLEU and scores from expertise, achieving about 82% satisfaction.

– Developed automated pipelines for processing and cleansing over 80,000 rows of after-sales data into

structured formats, enabling closedloop analytical workﬂows.

– Engineered knowledge graph based on Neo4J to structure domain data and question–answer pairs for

highquality retrieval and model ﬁnetuning.

– Collaborated with modelling team, identifying cases where more than 20% refrigerant leakage has occurred.

• Frontend Developer & Scrum Master (ECAT Project)

Served as acting Scrum Master, facilitating 10+ standups, managing 20+ JIRA items (Bugs/Features), and

ensuring successful deliveries, and mentored 9 engineers in daily practice. Collaborated with global teams to

refactor and optimize a big front-end application. Achieved signiﬁcant cost reduction on AWS Reduced

single-module cloud resource usage by 70%, leading to an overall cloud cost decrease of 5-10%.

Accenture (China) Co., Ltd.

Frontend Developer (Cathay Paciﬁc Vera Chatbot Project) with Excellent performance

Jan 2023 - Jul 2023

Guangzhou

• Delivered features for Cathay Paciﬁc’s Vera Chatbot using Angular.js, TypeScript, and Node.js. Optimized the

price search ﬂow, cutting response time by 30%.

Research Experience

2022

The Data Flow Orchestration Platform

12,000-word dissertation | Distinguished Grade (Top 5%)

Newcastle University

• Analysed challenges in smartcity and medical IoT systems.

• Designed a novel architecture addressing latency sensitivity, crossplatform deployment, and hybrid dataformat

processing.

• Implemented and evaluated the system across multiple realworld scenarios.

• Achieved 95% automated deployment, 99.5% uptime and 10,000 msg/sec throughput.

Research Methods and Group Project in Security and Resilience

75 out of 100

2022

Newcastle University

Research Contribution： Built secure software for cardiac resynchronization therapy (CRT) with thread-safe

cryptographic arrays and resilience against MITM attacks.

Skills

• Programming Language: Python, Go, Java

• Technical: Kubernetes, NLP, AI Pipelines, spaCy

• Storage: MySQL, Redis, EletricSearch, NEO4J, AWS S3

References list

• My master’s thesis supervisor: Prof. Ranjan, Email: Raj.ranjan@newcastle.ac.uk

• My line manager in Carrier: Liangjiang Yang, Email: Liangjiang.Yang@Carrier.com
