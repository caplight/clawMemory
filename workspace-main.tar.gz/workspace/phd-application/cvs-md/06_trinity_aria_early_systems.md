Wei Zhu

caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/

Highly motivated and research-oriented with a strong academic background, excellent coding skills, and proven

ability to apply AI techniques to real-world industrial challenges. Experienced in IoT data integration, anomaly

detection, and large-scale AI pipeline development where skills are directly relevant to Early Warning Systems in

the utilities sector. Skilled at building scalable architectures for real-time monitoring and decision support, with

additional experience in predictive maintenance for complex assets.

Education

Sep 2021 - Nov 2022

Newcastle University(UK), MSc Advanced Computer Science

• Grade: 72/100 (Distinction / First Class Honours)

• Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware,

Information Security, System Security, Security and Resilience Group Project and Research.

• Thesis: The Data Flow Orchestration Platform (Score: 72)

Guangzhou University Sontan College, BEng Software Engineering

Sep 2017 - May 2021

• Grade: 84/100

• Honors: Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

Research Experience

2022

The Data Flow Orchestration Platform

12,000-word dissertation | Distinguished Grade (Top 5%)

Newcastle University

Relevance to PhD: Scalable architecture for edge-cloud communication, adaptable to robotic CPS.

Research Objective： Analyzed pain points of building smart city and medical IoT. Designed a novel architecture

to resolve data transfer challenges between edge devices and cloud services, addressing latency sensitivity,

cross-platform deployment, and hybrid data format processing.

Key Contributions & innovations:

• Designed architecture to resolve latency and interoperability issues between edge devices and cloud services.

• Implemented Redis-based dynamic routing tables and a MessageQueue-as-plugin architecture.

• Validated with scenarios simulating real-time IoT monitoring, achieving 99.5% uptime and 10,000 msg/sec

throughput.

• Direct relevance: scalable architecture for sensor fusion and early warning applications.

Research Methods and Group Project in Security and Resilience

75 out of 100

2022

Newcastle University

Research Contribution： Simulated and engineered a software supporting a cardiac resynchronization therapy

(CRT). Heart rate and beat will be collected from the patient to our software, analyzed by algorithms, then

executed CRT-P, CRT-D or nothing based on the rhythm. We contributed a thread-security, cryptographic and

synchronized array that makes sure the process is atomic, reliable, resilient and prevents from MITM attacks.

Professional Experience

Jul 2023 - Present

Carrier Research & Development Center (Shanghai) Co., Ltd.

Engineer Leadership Program (R&D Trainee), MASC&DI

Shanghai

• AI / Data Engineer (Intelligent Diagnosis Service Project)

– Designed and implemented the company’s ﬁrst RAG-based AI diagnostic system, processing 80K+

unstructured records into actionable insights with >92% accuracy.

– Analyzed and implemented LoRA and adapter tuning on opus-mt-zh-en for specialized translation tasks,

improving domain-speciﬁc data accessibility. evaluated with BLEU and scores from expertise, achieving about

82% satisfaction.

– Developed automated pipelines for processing and cleansing diverse over 80,000 rows of after-sales data

formats into structured data.

• AI/Data Engineer (CTD Project)

– Developed Partial dependence (PD) plots which showed the interconnection between parameters, such as

system charge vs condenser subcooling vs EXV opening in the refrigerant leakage problem.

– Initiated and architected algorithm ecosystem to output predictive value to help with the qualiﬁcation of test

lib data which will be used to calibrate physical models.

– Collaborated with modelling team, identifying cases where more than 20% refrigerant leakage has occurred.

• Frontend Developer & Scrum Master (ECAT Project)

Served as acting Scrum Master, facilitating 10+ standups, managing 20+ JIRA items (Bugs/Features), and

ensuring successful deliveries, and mentored 9 engineers in daily practice. Collaborated with global teams to

refactor and optimize a big front-end application. Achieved signiﬁcant cost reduction on AWS Reduced

single-module cloud resource usage by 70%, leading to an overall cloud cost decrease of 5-10%.

Accenture (China) Co., Ltd.

Jan 2023 - Jul 2023

Frontend Developer (Cathay Paciﬁc Vera Chatbot Project) with Excellent performance

• Delivered core features and optimized workﬂows, improving response time by 30

Skills

• Programming Language: Python, Go, Java, TypeScript

• Technical: Kubernetes, IoT Orchestration, AI Pipelines, RAG architectures, LoRA/Adaptor tuning

• Domain Knowledge: Edge Computing, Predictive Modeling, Cyber-security

References list

• My master’s thesis supervisor: Prof. Ranjan, Email: Raj.ranjan@newcastle.ac.uk

• My line manager in Carrier: Liangjiang Yang, Email: Liangjiang.Yang@Carrier.com

Guangzhou
