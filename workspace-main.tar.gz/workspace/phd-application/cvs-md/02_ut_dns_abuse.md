Wei Zhu

caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/

Highly motivated, research-driven engineer with distinction-level MSc in Advanced Computer Science (Newcastle

University, UK). Strong background in real-time data analysis, graph-based machine learning, distributed systems,

and AI pipelines. Experienced in building end-to-end, production-scale systems involving streaming architectures,

anomaly detection, and knowledge graphs. Research interests focus on shifting security systems from reactive to

proactive detection, particularly for real-time DNS abuse and infrastructure security.

Education

Newcastle University(UK), MSc Advanced Computer Science

Sep 2021 - Nov 2022

• Grade: 72/100 (Distinction / First Class Honours)

• Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware,

Information Security, System Security, Security and Resilience Group Project and Research.

• Thesis: The Data Flow Orchestration Platform (Score: 72)

Guangzhou University Sontan College, BEng Software Engineering

Sep 2017 - May 2021

• Grade: 84/100

• Honors: Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

Professional Experience

Carrier Research & Development Center (Shanghai) Co., Ltd.

Engineer Leadership Program (R&D Trainee), MASC&DI

Jul 2023 - Present

Shanghai

• AI / Data Engineer (Intelligent Diagnosis Service Project & Gamba-Witz Project)

– Led requirements analysis and process design (Miro) for GenAI applications based on after-sales data.

– Designed and implemented the company’s ﬁrst Retrieval-Augmented Generation (RAG) architecture, using

Python, Hugging Face, LangChain, and AnythingLLM.

– Optimized chunking strategies, deduplication, and token windows on LLaMA and DeepSeek models,

achieving >92% answer accuracy.

– Applied DBSCAN clustering to identify anomalous patterns in real-time data; evaluated performance using

Silhouette Coefﬁcient and domain-expert validation.

– Built automated data pipelines to clean and normalize 80,000+ rows of heterogeneous after-sales data.

– Engineered a knowledge graph (Neo4j), labeling and categorizing entities into semantic business tags to

support future ﬁne-tuning and graph-based inference.

• Architecture/AI Engineer (RLC Project)

– Led end-to-end design of real-time analysis orchestration on AWS EKS: user’s terminal -> edge service ->

Kafka -> Flink -> Clickhouse -> Argo workﬂows -> Agentic systems

– Developed a Python + LangChain agent container that reads the latest 5minute features from ClickHouse,

calls LLM + regression models, executes post-processing, and writes inference results back to ClickHouse

• Frontend Developer & Scrum Master (ECAT Project)

Managed 20+ JIRA items, optimized AWS resource usage by 70%, reducing cloud cost by 5–10%. Facilitated

team collaboration across global sites; led sprint planning and process improvement.

Accenture (China) Co., Ltd.

Frontend Developer (Cathay Paciﬁc Vera Chatbot Project) with Excellent performance

Jan 2023 - Jul 2023

Guangzhou

• Delivered features for Cathay Paciﬁc’s Vera Chatbot using Angular.js, TypeScript, and Node.js. Optimized the

price search ﬂow, cutting response time by 30%.

Research Experience

2022

The Data Flow Orchestration Platform

12,000-word dissertation | Distinguished Grade (Top 5%)

Newcastle University

Research Objective： Analyzed pain points of building smart city and medical IoT. Designed a novel architecture

to resolve data transfer challenges between edge devices and cloud services, addressing latency sensitivity,

cross-platform deployment, and hybrid data format processing.

Key Contributions & innovations:

• Architecture Design:

– Created the ﬁrst dynamic routing table model using Redis, enabling real-time device coordination

– Pioneered MessageQueue-as-plugin architecture with comparative analysis of cutting-edge MQ tech

• Technical Implementation:

– Engineered Go-based Orchestrator with 95% automated deployment via Kubernetes API

– Leveraged Gin Framework, exposing 5 core APIs for queue management

– Implemented Sentinel and Cluster Patterns, achieving 99.5% uptime and reducing service disruption

• Validation & Performance:

– Benchmarked 10,000 msg/sec throughput with low latency, and shown effective action to DDoS scenarios.

– Simulated and tested in ﬁve different and real scenarios with diverse data formats.

Research Methods and Group Project in Security and Resilience

75 out of 100

2022

Newcastle University

Research Contribution： Built secure software for cardiac resynchronization therapy (CRT) with thread-safe

cryptographic arrays and resilience against man-in-the-middle (MITM) attacks.

Skills

• Programming Language: Python, Go, Java

• Technical: Kubernetes, Kafka, RabbitMQ, Flink, AI Pipelines, IoT Orchestration

• Storage: MySQL, Redis, EletricSearch, NEO4J, AWS S3

References list

• My master’s thesis supervisor: Prof. Ranjan, Email: Raj.ranjan@newcastle.ac.uk

• My line manager in Carrier: Liangjiang Yang, Email: Liangjiang.Yang@Carrier.com
