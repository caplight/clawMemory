Wei Zhu

caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/

Highly motivated engineer with Distinction-level MSc in Advanced Computer Science (Newcastle University, UK).

Experienced in IoT orchestration, distributed systems, data engineering, and applied machine learning. Skilled in

building scalable orchestration frameworks, designing secure data pipelines, and integrating AI models into

operational workﬂows. Seeking to contribute to the development of self-organizing edge infrastructures for

next-generation Internet systems.

Education

Newcastle University(UK), MSc Advanced Computer Science

Sep 2021 - Nov 2022

• Grade: 72/100 (Distinction / First Class Honours)

• Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware,

Information Security, System Security, Security and Resilience Group Project and Research.

• Thesis: The Data Flow Orchestration Platform (Score: 72)

Guangzhou University Sontan College, BEng Software Engineering

Sep 2017 - May 2021

• Grade: 84/100

• Honors: Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

Research Experience

2022

The Data Flow Orchestration Platform

12,000-word dissertation | Distinguished Grade (Top 5%)

Newcastle University

Research Objective： Designed and implemented a scalable orchestration framework to coordinate

heterogeneous IoT devices across edge–cloud layers, addressing latency sensitivity, cross-platform deployment,

and hybrid data format processing.

Key Contributions & innovations:

• Architecture Design:

– Created the ﬁrst dynamic routing table model using Redis, enabling real-time device coordination

– Pioneered MessageQueue-as-plugin architecture with comparative analysis of cutting-edge MQ tech

• Technical Implementation:

– Engineered Go-based Orchestrator with 95% automated deployment via Kubernetes API

– Leveraged Gin Framework, exposing 5 core APIs for queue management

– Implemented Sentinel and Cluster Patterns, achieving 99.5% uptime and reducing service disruption

• Validation & Performance:

– Benchmarked 10,000 msg/sec throughput with low latency, and shown effective action to DDoS scenarios.

– Simulated and tested in ﬁve different and real scenarios with diverse data formats.

Research Methods and Group Project in Security and Resilience

75 out of 100

2022

Newcastle University

Research Contribution： Built secure software for cardiac resynchronization therapy (CRT) with thread-safe

cryptographic arrays and resilience against MITM attacks.

Professional Experience

Jul 2023 - Present

Carrier Research & Development Center (Shanghai) Co., Ltd.

Engineer Leadership Program (R&D Trainee), MASC&DI

Shanghai

• AI / Data Engineer (Intelligent Diagnosis Service Project & Gamba-Witz Project)

– Led requirements analysis and process design (Miro) for GenAI applications based on after-sales data.

– Designed and implemented the company’s ﬁrst Retrieval-Augmented Generation (RAG) architecture using

Python, Hugging Face, Langchain, and AnythingLLM. Optimized chunking strategies, deduplication, and

token windows on Llama and DeepSeek for signiﬁcantly improved result accuracy (>92%).

– Analyzed and implemented LoRA and adapter tuning on opus-mt-zh-en for machine translation tasks,

evaluated with BLEU and scores from expertise, achieving about 82% satisfaction.

– Developed automated pipelines for processing and cleansing over 80,000 rows of after-sales data formats

into structured data.

– Engineered knowledge graph based on Neo4J, labelled and categorised data into different semantic

business tags as the ﬁne-tuning dataset in the future.

• AI/Data Engineer (CTD Project)

– Migrated algorithm ecosystem to output predictive value to help with the qualiﬁcation of test lib data which

will be used to calibrate physical models(Digital Twins).

– Collaborated with modelling team, identifying cases where more than 20% refrigerant leakage has occurred.

• Frontend Developer & Scrum Master (ECAT Project)

Served as acting Scrum Master, facilitating 10+ standups, managing 20+ JIRA items (Bugs/Features), and

ensuring successful deliveries, and mentored 9 engineers in daily practice. Collaborated with global teams to

refactor and optimize a big front-end application. Achieved signiﬁcant cost reduction on AWS Reduced

single-module cloud resource usage by 70%, leading to an overall cloud cost decrease of 5-10%.

Accenture (China) Co., Ltd.

Frontend Developer (Cathay Paciﬁc Vera Chatbot Project) with Excellent performance

Jan 2023 - Jul 2023

Guangzhou

• Delivered features for Cathay Paciﬁc’s Vera Chatbot using Angular.js, TypeScript, and Node.js. Optimized the

price search ﬂow, cutting response time by 30%.

Skills

• Programming Language: Python, Go, Java

• Technical: Kubernetes, IoT Orchestration, AI Pipelines

• Storage: MySQL, Redis, EletricSearch, NEO4J, AWS S3

References list

• My master’s thesis supervisor: Prof. Ranjan, Email: Raj.ranjan@newcastle.ac.uk

• My line manager in Carrier: Liangjiang Yang, Email: Liangjiang.Yang@Carrier.com
