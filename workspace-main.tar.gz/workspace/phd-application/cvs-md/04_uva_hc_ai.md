Wei Zhu

caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/

Highly motivated, research-driven engineer with a distinction-level MSc in Advanced Computer Science

(Newcastle University, UK). Strong background in quantitative research, developer tooling, and AI-powered and

end-to-end application development, with experience integrating large language models into real-world workﬂows

and accelerating model training by CUDA . Motivated by human-centered and inclusive computing, I am

particularly interested in how AI-assisted programming environments can be designed to support diverse cognitive

styles through conﬁgurable, transparent, and user-controlled interactions.

Education

Newcastle University(UK), MSc Advanced Computer Science

Sep 2021 - Nov 2022

• Grade: 72/100 (Distinction / First Class Honours)

• Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware,

Information Security, System Security, Security and Resilience Group Project and Research.

• Thesis: The Data Flow Orchestration Platform (Score: 72)

Guangzhou University Sontan College, BEng Software Engineering

Sep 2017 - May 2021

• Grade: 84/100

• Honors: Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

Professional Experience

Carrier Research & Development Center (Shanghai) Co., Ltd.

Jul 2023 - Present

Engineer Leadership Program (R&D Trainee), MASC&DI

Shanghai

• AI / Data Engineer (Intelligent Diagnosis Service Project & Gamba-Witz Project)

– Led requirements analysis and human-centered UI/UX design (Miro) for GenAI-assisted engineering tools in

after-sales scenarios, focusing on clarity, efﬁciency, and reduced cognitive overhead for users.

– Designed and implemented the company’s ﬁrst Retrieval-Augmented Generation (RAG) architecture

using Python, Hugging Face, LangChain, and AnythingLLM.

– Optimized chunking strategies, deduplication, and token windows on LLaMA and DeepSeek models,

achieving >92% answer accuracy.

– Built automated data pipelines to clean and normalize 80,000+ rows of heterogeneous after-sales data.

– Engineered a Neo4j-based knowledge graph with semantic labeling to support future ﬁne-tuning and

graph-based inference.

• Frontend Developer (MASC Projects)

– Managed commonalities of UI components, leveraging conﬁg-driven design and signiﬁcantly improving

development efﬁciency up to 60%.

– Managed tests cases to keep quality of UI’s functions and components, including black and white box testing.

• Frontend Developer & Scrum Master (ECAT Project)

Managed 20+ JIRA items, optimized AWS resource usage by 70%, reducing cloud cost by 5–10%. Facilitated

team collaboration across global sites; led sprint planning and process improvement.

Accenture (China) Co., Ltd.

Jan 2023 - Jul 2023

Frontend Developer (Cathay Paciﬁc Vera Chatbot Project) with Excellent performance

Guangzhou

• Delivered features for Cathay Paciﬁc’s Vera Chatbot using Angular.js, TypeScript, and Node.js. Optimized the

price search ﬂow, cutting response time by 30%.

Research Experience

2022

The Data Flow Orchestration Platform

12,000-word dissertation | Distinguished Grade (Top 5%)

Newcastle University

Research Objective： Analyzed pain points of building smart city and medical IoT. Designed a novel architecture

to resolve data transfer challenges between edge devices and cloud services, addressing latency sensitivity,

cross-platform deployment, and hybrid data format processing.

Key Contributions & innovations:

• Users studies:

– Conducted semi-structured user interviews with potential users and academic collaborators to identify

usability barriers and design requirements, synthesizing ﬁndings into ﬁve key dimensions that informed

architectural and interaction design decisions.

• Architecture Design:

– Created the ﬁrst dynamic routing table model using Redis, enabling real-time device coordination

– Pioneered MessageQueue-as-plugin architecture with comparative analysis of cutting-edge MQ tech

• Validation & Performance:

– Benchmarked 10,000 msg/sec throughput with low latency, and shown effective action to DDoS scenarios.

– Simulated and tested in ﬁve different and real scenarios with diverse data formats.

Research Methods and Group Project in Security and Resilience

75 out of 100

2022

Newcastle University

Research Contribution： Built secure software for cardiac resynchronization therapy (CRT) with thread-safe

cryptographic arrays and resilience against man-in-the-middle (MITM) attacks.

Skills

• Programming Language: Python, TypeScript, Go

• AI & Data: LLMs, RAG, LangChain, Hugging Face, Knowledge Graphs

• Systems: Kubernetes, Kafka, Flink

• UI/UX & Prototyping: Figma, Miro

References list

• My master’s thesis supervisor: Prof. Ranjan, Email: Raj.ranjan@newcastle.ac.uk

• My line manager in Carrier: Liangjiang Yang, Email: Liangjiang.Yang@Carrier.com
