Wei Zhu

caplight98@gmail.com | +8618122397704 | linkedin.com/in/wadezhu/

Highly motivated, research-driven engineer with a distinction-level MSc in Advanced Computer Science

(Newcastle University, UK). Strong background in quantitative research, developer tooling, and AI-powered

end-to-end systems, with experience integrating large language models into real-world workﬂows and accelerating

model training using CUDA-based optimization. Research interests lie in systems and programming tools that

improve performance, productivity, and accessibility

Education

Newcastle University(UK), MSc Advanced Computer Science

Sep 2021 - Nov 2022

• Grade: 72/100 (Distinction / First Class Honours)

• Relevant Coursework: Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware,

Information Security, System Security, Security and Resilience Group Project and Research.

• Thesis: The Data Flow Orchestration Platform (Score: 72)

Guangzhou University Sontan College, BEng Software Engineering

Sep 2017 - May 2021

• Grade: 84/100

• Honors: Outstanding Graduate (Top 1%), Ranked #1 GPA in Grade (2019-2020)

Professional Experience

Carrier Research & Development Center (Shanghai) Co., Ltd.

Jul 2023 - Present

Engineer Leadership Program (R&D Trainee), MASC&DI

Shanghai

• Fullstack Engineer (MASC Projects)

– Led end-to-end design of real-time analysis orchestration on AWS EKS: user’s terminal -> edge service ->

Kafka -> Flink -> Clickhouse -> Argo workﬂows -> Agentic systems

– Developed a Python + LangChain agent container that reads the latest 5minute features from ClickHouse,

calls LLM + regression models, executes post-processing, and writes inference results back to ClickHouse

– Managed commonalities of UI components, leveraging conﬁg-driven design and signiﬁcantly improving

development efﬁciency up to 60%.

– Managed test cases to keep the quality of UI’s functions and components, including black and white box

testing.

• AI / Data Engineer (Intelligent Diagnosis Service Project & Gamba-Witz Project)

– Led requirements analysis and human-centered UI/UX design (Miro) for GenAI-assisted engineering tools in

after-sales scenarios, focusing on clarity, efﬁciency, and reduced cognitive overhead for users.

– Designed and implemented the company’s ﬁrst Retrieval-Augmented Generation (RAG) architecture

using Python, Hugging Face, LangChain, and AnythingLLM.

– Optimized chunking strategies, deduplication, and token windows on LLaMA and DeepSeek models,

achieving >92% answer accuracy.

– Built automated data pipelines to clean and normalize 80,000+ rows of heterogeneous after-sales data.

– Implemented LoRA and adapter tuning for opus-mt-zh-en machine translation models, achieving up to 167%

faster training via CUDA-enabled optimization.

• Frontend Developer & Scrum Master (ECAT Project)

Managed 20+ JIRA items, optimized AWS resource usage by 70%, reducing cloud cost by 5–10%. Facilitated

team collaboration across global sites; led sprint planning and process improvement.

Accenture (China) Co., Ltd.

Frontend Developer (Cathay Paciﬁc Vera Chatbot Project) with Excellent performance

Jan 2023 - Jul 2023

Guangzhou

• Delivered features for Cathay Paciﬁc’s Vera Chatbot using Angular.js, TypeScript, and Node.js. Optimized the

price search ﬂow, cutting response time by 30%.

Research Experience

2022

The Data Flow Orchestration Platform

12,000-word dissertation | Distinguished Grade (Top 5%)

Newcastle University

Research Objective： Analyzed pain points of building smart city and medical IoT. Designed a novel architecture

to resolve data transfer challenges between edge devices and cloud services, addressing latency sensitivity,

cross-platform deployment, and hybrid data format processing.

Key Contributions & innovations:

• Conducted semi-structured user interviews with academic and industry collaborators, identifying usability

barriers and deriving ﬁve core design dimensions.

• Designed a dynamic routing table model using Redis for real-time device coordination.

• Proposed a MessageQueue-as-plugin architecture, with comparative analysis of state-of-the-art MQ technologies.

Validation & Performance:

• Benchmarked 10,000 msg/sec throughput with low latency.

• Evaluated the system across ﬁve realistic deployment scenarios with diverse data formats.

• Demonstrated resilience under DDoS scenarios through stress testing and fault injection.

Skills

• Programming Language: Python, TypeScript, Go

• Parallel & Acceleration: CUDA

• AI & Data: LLMs, RAG, LangChain, Hugging Face, Knowledge Graphs

• Systems: Kubernetes, Kafka, Flink

• UI/UX & Prototyping: Figma, Miro

References list

• My master’s thesis supervisor: Prof. Ranjan, Email: Raj.ranjan@newcastle.ac.uk

• My line manager in Carrier: Liangjiang Yang, Email: Liangjiang.Yang@Carrier.com
