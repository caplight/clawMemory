print("Hello from Cursor!")
