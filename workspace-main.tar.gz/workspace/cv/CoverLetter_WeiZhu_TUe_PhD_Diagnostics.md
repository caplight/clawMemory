# Cover Letter

Dear Professor van de Wouw, Professor Oomen, Dr. Chong, and the Selection Committee,

I am writing to apply for the PhD position on Diagnostics for Interconnected Complex Dynamical Systems at the Eindhoven University of Technology. My background lies at the intersection of fault detection for industrial equipment, real-time data-driven monitoring, and learning-based system health management — directly aligned with the research goals of your Dynamics and Control group and the semiconductor manufacturing context of the ASML collaboration.

I hold an MSc in Advanced Computer Science from Newcastle University, awarded a Distinction (Top 5%), and I currently work as an AI/Data/Systems Engineer at Carrier's Research and Development Center. Across both my academic work and industrial projects, I have focused on automated fault detection and isolation in complex, interconnected engineering systems.

My master's thesis, *The Data Flow Orchestration Platform*, directly speaks to the interconnected systems theme of this PhD project. I designed and implemented a scalable orchestration framework coordinating heterogeneous IoT devices across edge-cloud layers, where multiple distributed modules interact in real time. The key challenge — ensuring reliable, continuous operation of the entire system while managing interactions between individual components — mirrors the fault isolation problem you are addressing in semiconductor equipment. I benchmarked the system at 10,000 messages per second with 99.5% uptime, and explored trade-offs between MQTT, Kafka, and RabbitMQ for real-time coordination of interconnected modules.

At Carrier, I have applied these ideas in a production industrial monitoring context. I helped design a real-time fault detection platform on AWS EKS using Apache Kafka and Apache Flink, where the task was to automatically detect and isolate equipment faults (such as refrigerant leakage and coil blockage) across large HVAC installations — an industrial setting where multiple subsystems are functionally and physically interconnected, just as in semiconductor equipment. I also led the implementation of an enterprise RAG system with Neo4j knowledge graphs, achieving over 92% accuracy in domain-specific fault-diagnosis question answering, and applied DBSCAN clustering to operational sensor data for anomaly detection. Additionally, I contributed to digital-twin-based predictive maintenance workflows, including partial dependence analysis to identify operational conditions leading to equipment degradation — work closely related to the hierarchical diagnostic tools you are developing.

My undergraduate background in software engineering and four years of hands-on experience with Python and MATLAB for scientific computing provide a solid foundation for the programming and modeling aspects of this PhD project. I am eager to deepen my expertise in mathematical control theory, distributed observer design, and learning-based approaches under your supervision.

I am particularly drawn to this PhD project because it sits at the intersection of rigorous control-theoretic methods and data-driven learning — two areas I have practical experience in — and applies them to the concrete challenge of fault isolation in semiconductor manufacturing equipment with ASML. The opportunity to work in a team of six PhD students within the Holistic Design Automation for Semiconductor Manufacturing Equipment project, alongside strong academic supervision and an industry partner, is an ideal environment for developing both theoretical depth and industrial impact.

Thank you for your consideration. My CV and transcripts are enclosed. I would be delighted to discuss how my background could contribute to your research group.

Sincerely,  
Wei Zhu  
Email: caplight98@gmail.com | LinkedIn: linkedin.com/in/wadezhu
