# Curriculum Vitae

## Wei Zhu

| | |
|---|---|
| Email | caplight98@gmail.com |
| Phone | +86 181 2239 7704 |
| LinkedIn | linkedin.com/in/wadezhu |
| GitHub | github.com/caplight |

---

## Research Profile

Early-career systems engineer with academic and industrial experience in distributed systems, edge-cloud orchestration, stream processing, and AI-enabled monitoring. My work combines large-scale data pipelines with learning-based diagnosis and operational decision support, with a particular interest in how intelligent services can improve the performance, resilience, and manageability of computer systems.

## Research Interests

- Large-scale computer systems and resource orchestration across the cloud-edge continuum
- Stream processing and data-intensive infrastructure for AI and big-data applications
- AI for Systems: monitoring, diagnosis, anomaly detection, and predictive maintenance
- Digital twins, system experimentation, and reproducible evaluation
- Knowledge graphs and semantic data organization for operational intelligence

---

## Education

### Master of Science in Advanced Computer Science
**Newcastle University, United Kingdom** | September 2021 - November 2022

- **Final grade:** 72/100 (Distinction / First Class Honours)
- **Thesis:** *The Data Flow Orchestration Platform* (12,000 words), **Distinguished grade (Top 5%)**
- Designed and implemented a scalable orchestration framework for heterogeneous IoT devices across edge-cloud layers, targeting latency-sensitive and cross-platform deployments
- Developed a Redis-based dynamic routing table for real-time device coordination
- Designed a MessageQueue-as-plugin architecture and compared MQTT, Kafka, and RabbitMQ for different workload patterns
- Engineered a Go-based orchestrator with Kubernetes-based automated deployment and exposed five core APIs using Gin
- Implemented Sentinel and Cluster patterns, achieving 99.5% uptime in evaluation
- Benchmarked throughput at 10,000 messages per second and validated the platform across five real-world scenarios
- **Relevant coursework:** Big Data Analytics, Cloud Computing, Distributed Algorithms, Enterprise Middleware, Information Security

### Bachelor of Engineering in Software Engineering
**Guangzhou University Sontan College, China** | September 2017 - May 2021

- **Final grade:** 84/100
- **Class standing:** Top 1% of graduating class; ranked #1 GPA in grade (2019-2020)
- **Honours:** Outstanding Graduate
- **Final-year project:** Designed and implemented a distributed microservice architecture for smart campus applications

---

## Professional Experience

### AI / Data / Systems Engineer, Engineer Leadership Program
**Carrier Research & Development Center (Shanghai)** | July 2023 - Present

#### RLC Real-Time Fault Detection Platform

- Designed a real-time analytics architecture on **AWS EKS (Kubernetes)** connecting edge devices with **Apache Kafka**, **Apache Flink**, **ClickHouse**, and workflow orchestration components
- Built an automated inference pipeline that combined LLMs, regression models, and physical models for HVAC fault detection
- Developed a Python and LangGraph service that reads time-windowed features from ClickHouse, executes model inference and post-processing, and writes results back to production data stores
- Supported diagnosis tasks such as refrigerant leakage and coil blockage detection in commercial HVAC systems

#### Intelligent Diagnosis Service: RAG and Knowledge Graphs

- Led the design and implementation of an enterprise RAG architecture using Python, Hugging Face, LangChain, and AnythingLLM
- Improved domain-specific question-answering accuracy to **more than 92%** through chunking, deduplication, and context-window optimization
- Applied **LoRA fine-tuning** to machine translation workflows and achieved a **150% training speed improvement** using CUDA acceleration
- Built automated pipelines to clean and structure **80,000+ rows** of after-sales service data
- Constructed a domain-specific **Neo4j knowledge graph** to organize business entities and semantic relationships for downstream retrieval and model improvement
- Applied **DBSCAN clustering** to sensor data for anomaly detection and validated outputs with both quantitative metrics and domain-expert review

#### CTD Project: Digital Twins and Predictive Modeling

- Contributed to a predictive analytics workflow used to calibrate **digital-twin-based physical models** for HVAC testing
- Developed **partial dependence analysis** to examine relationships among operational variables relevant to refrigerant leakage diagnosis
- Worked with modeling engineers to identify cases associated with **more than 20% refrigerant leakage**, supporting predictive maintenance analysis

#### ECAT Project: Front-End Engineering and Scrum Coordination

- Served as acting **Scrum Master**, facilitating daily standups and coordinating 20+ JIRA tasks across a cross-functional team
- Mentored **nine engineers** in day-to-day technical practice and team delivery
- Helped refactor and optimize a large front-end application used by global teams
- Reduced AWS resource usage for one module by **70%**, contributing to an overall cloud cost decrease of **5-10%**

### Front-End Developer
**Accenture (China)** | January 2023 - July 2023

- Delivered product features for **Cathay Pacific's Vera Chatbot** using AngularJS, TypeScript, and Node.js
- Optimized the price-search workflow and reduced API response times by **30%** through caching and query improvements

---

## Selected Academic and Technical Projects

### Master's Thesis: *The Data Flow Orchestration Platform*
*Newcastle University, 2022*

- Designed a scalable orchestration framework for heterogeneous IoT coordination across edge-cloud layers
- Evaluated the system at **10,000 messages per second** with **99.5% uptime**
- Validated the design across five smart-city and medical-IoT-style scenarios

### Security and Resilience Group Project
*Newcastle University, 2022 | Grade: 75/100*

- Built thread-safe cryptographic software for cardiac resynchronization therapy devices
- Designed resilience against man-in-the-middle attacks using secure software engineering principles

---

## Technical Skills

| Category | Skills |
|---|---|
| **Programming** | Python, Go, Java, TypeScript, SQL, Bash |
| **Distributed Systems** | Kubernetes, AWS EKS, Apache Kafka, Apache Flink, ClickHouse, Redis, RabbitMQ, MQTT, Argo Workflows |
| **AI / Data Systems** | RAG, LangChain, LangGraph, Hugging Face, LoRA, CUDA, Neo4j, anomaly detection, digital twins |
| **Databases / Storage** | MySQL, ClickHouse, Neo4j, Elasticsearch, AWS S3, Pinecone, Snowflake |
| **Cloud / DevOps** | AWS, Docker, Terraform, Prometheus, Grafana, CI/CD |
| **Methods / Tools** | Git, JIRA, Agile / Scrum, experimental evaluation, data pipeline development |

---

## Selected Achievements

- MSc thesis awarded **Distinguished grade (Top 5%)** at Newcastle University
- BEng completed in the **Top 1%** of graduating class, with **#1 GPA** in grade (2019-2020)
- Achieved **more than 92%** QA accuracy in a domain-specific RAG system for industrial diagnosis
- Reached **99.5% uptime** and **10,000 messages/second** in orchestration-platform evaluation
- Reduced AWS resource usage by **70%** in a production engineering project
- Improved LoRA training speed by **150%** with CUDA acceleration

---

## References

**Prof. Ranjan**  
MSc Thesis Supervisor  
Department of Computer Science, Newcastle University  
Email: Raj.ranjan@newcastle.ac.uk

**Liangjiang Yang**  
Line Manager, AI/Data Engineering  
Carrier Research & Development Center (Shanghai)  
Email: Liangjiang.Yang@Carrier.com

---

*Customized for application to the 2 PhD positions in large-scale computer systems for AI, big data, and 6G applications at VU Amsterdam (AtLarge Research Group / Massivizing Computer Systems), deadline 20 April 2026.*
