# Cover Letter — Submission-Ready Version

Dear Professor Iosup and the AtLarge Research Group,

I am writing to apply for one of the PhD positions in large-scale computer systems for AI, big data, and 6G applications at VU Amsterdam. I hold an MSc in Advanced Computer Science from Newcastle University, where my thesis received a Distinguished grade (Top 5%), and I currently work as an AI/Data/Systems Engineer at Carrier's R&D Center. Across my academic and industrial work, I have focused on distributed coordination, stream-oriented data systems, and AI-enabled monitoring for complex environments. I am now seeking to develop this work through doctoral research, and I see a strong fit with the AtLarge / Massivizing Computer Systems agenda.

My academic foundation is my master's thesis, *The Data Flow Orchestration Platform*, in which I designed and implemented a scalable orchestration framework for heterogeneous IoT devices across edge-cloud layers. The project addressed latency sensitivity, cross-platform deployment, and hybrid data formats, and resulted in a Go-based orchestrator with Kubernetes-based automated deployment, 99.5% uptime in evaluation, and throughput benchmarked at 10,000 messages per second. I also explored real-time routing and messaging trade-offs through a comparative design involving MQTT, Kafka, and RabbitMQ. This work shaped my research interest in resource orchestration and data-intensive systems spanning the edge-cloud continuum.

At Carrier, I have extended these interests in production settings. I helped design a real-time analytics and fault-detection platform on AWS EKS using Apache Kafka, Apache Flink, and ClickHouse for industrial HVAC monitoring, and built an inference workflow that combines LLMs, regression models, and physical models. I also led the implementation of an enterprise RAG system, improving domain-specific question-answering accuracy to over 92%, and applied LoRA fine-tuning with CUDA acceleration to improve training efficiency by 150%. In parallel, I contributed to digital-twin-oriented modeling work for predictive maintenance, including partial dependence analysis to support calibration of physical HVAC models. Together, these projects have strengthened my interest in AI for Systems: using intelligent methods to make large-scale infrastructures more observable, adaptive, and reliable.

I am particularly drawn to the MCS group's focus on large-scale computer systems, stream processing, and intelligent system management for emerging AI and data-intensive applications. The opportunity to work in a research environment that combines rigorous systems thinking with experimental evaluation and real-world relevance is especially appealing to me. I believe my background in edge-cloud orchestration, production data pipelines, and AI-enabled diagnosis would allow me to contribute meaningfully to the group's research while developing as an independent systems researcher.

Thank you for your consideration. My CV and transcripts are enclosed. For your reference, I have notified two referees, my MSc thesis supervisor Prof. Ranjan and my line manager at Carrier, Liangjiang Yang, who have agreed to provide references upon request. I would be very pleased to discuss my application further.

Sincerely,
Wei Zhu
Email: caplight98@gmail.com | LinkedIn: linkedin.com/in/wadezhu

---

# Cover Letter — Structured Draft (Internal Use)

## Opening Paragraph
- Names position and institution explicitly
- Establishes current status (MSc Distinction, Top 5% + Carrier engineer)
- States transition motivation from industry → PhD
- Signals specific group fit (AtLarge / MCS)

## Academic Evidence Paragraph (Thesis)
- Thesis title: "The Data Flow Orchestration Platform" (not generic title)
- Grade: Distinguished, Top 5% — strengthens academic credibility
- Key evidence: Go-based Orchestrator, 99.5% uptime, 10,000 msg/sec, 5 real scenarios
- Bridge: this edge-cloud orchestration work is the foundation for current systems research

## Professional Evidence Paragraph (Carrier × 3 projects)
- RLC Platform: 100K events/min, Kafka/Flink/ClickHouse/EKS, LangGraph, Argo Workflows — maps to stream processing and orchestration themes
- RAG system: >92% QA accuracy, LoRA with 150% CUDA speedup — maps to AI for Systems
- Digital Twins: Partial Dependence analysis, physical model calibration — maps to digital twins theme

## Research Fit Paragraph
- States AI for Systems interest explicitly
- Names MCS group work areas directly
- Avoids claiming 6G expertise; frames edge orchestration as the bridge

## Closing + References
- References explicitly named: Prof. Ranjan (MSc supervisor) + Liangjiang Yang (Carrier manager)
- Both have been notified — demonstrates professional conduct

---

# Application Checklist

- [x] Cover letter (max 2 pages, within limit)
- [x] CV with all Carrier projects + Accenture
- [x] Named referees (Prof. Ranjan + Liangjiang Yang)
- [ ] BSc transcript
- [ ] MSc transcript (in progress — degree completed by 1 June 2026)
- [ ] Confirm referee contact has been made
- [ ] Verify application portal submission before 20 April 2026

---

# Internal Notes for Future Applications

## Key Achievements to Surface

| Achievement | Metric | Relevance |
|---|---|---|
| MSc thesis (The Data Flow Orchestration Platform) | Distinguished, Top 5%, 12,000 words | Academic credibility, edge-cloud systems |
| Go-based Orchestrator | 99.5% uptime, 10,000 msg/sec, 95% K8s automated | Distributed systems, performance engineering |
| RLC Real-Time Platform | 100K events/min on AWS EKS, Kafka+Flink+ClickHouse | Large-scale stream processing |
| RAG QA system | >92% accuracy | AI for Systems |
| LoRA fine-tuning | 150% CUDA speed improvement | ML optimization, research reproducibility |
| Digital Twins (CTD) | Partial Dependence plots for >20% refrigerant leakage detection | Digital twins, predictive maintenance |
| ECAT cloud optimization | 70% resource reduction, 5-10% overall cost saving | Performance engineering, cloud systems |
| Referee 1 | Prof. Ranjan — Raj.ranjan@newcastle.ac.uk | MSc thesis supervisor |
| Referee 2 | Liangjiang Yang — Liangjiang.Yang@Carrier.com | Carrier line manager |
