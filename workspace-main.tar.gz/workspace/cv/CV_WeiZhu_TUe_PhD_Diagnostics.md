# Curriculum Vitae

## Wei Zhu

| | |
|---|---|
| Email | caplight98@gmail.com |
| Phone | +86 181 2239 7704 |
| LinkedIn | linkedin.com/in/wadezhu |
| GitHub | github.com/caplight |

---

## Research Profile

Systems engineer with academic and industrial experience in fault detection, distributed monitoring, and AI-enabled diagnostics for complex engineering systems. My work bridges real-time data pipelines, data-driven learning, and physical-model-based reasoning to achieve reliable operation of industrial-scale equipment — with a focus on automated fault isolation in interconnected dynamical systems.

## Research Interests

- Fault detection, isolation, and prognosis in complex interconnected systems
- Data-driven and learning-based approaches for health monitoring of industrial equipment
- Digital twins, distributed observer design, and predictive maintenance
- Stream processing and real-time analytics for large-scale engineering systems
- Knowledge graphs and semantic organization for operational intelligence

---

## Education

### Master of Science in Advanced Computer Science
**Newcastle University, United Kingdom** | September 2021 - November 2022

- **Final grade:** 72/100 (Distinction / First Class Honours)
- **Thesis:** *The Data Flow Orchestration Platform* (12,000 words), **Distinguished grade (Top 5%)**
- Designed and implemented a scalable orchestration framework for heterogeneous IoT devices across edge-cloud layers, addressing real-time coordination of distributed, interconnected modules
- Developed a Redis-based dynamic routing table for real-time device coordination
- Compared MQTT, Kafka, and RabbitMQ for different workload patterns in IoT contexts
- Engineered a Go-based orchestrator with Kubernetes-based automated deployment and exposed five core APIs
- Benchmarked throughput at 10,000 messages per second with 99.5% uptime across five industrial-IoT scenarios
- **Relevant coursework:** Big Data Analytics, Cloud Computing, Distributed Algorithms, Machine Learning

### Bachelor of Engineering in Software Engineering
**Guangzhou University Sontan College, China** | September 2017 - May 2021

- **Final grade:** 84/100 (**Top 1%** of graduating class; ranked **#1 GPA** in grade 2019-2020)
- **Honours:** Outstanding Graduate
- **Final-year project:** Distributed microservice architecture for smart campus applications

---

## Professional Experience

### AI / Data / Systems Engineer, Engineer Leadership Program
**Carrier Research & Development Center (Shanghai)** | July 2023 - Present

#### RLC Real-Time Fault Detection Platform

- Designed a real-time analytics architecture on **AWS EKS (Kubernetes)** connecting industrial edge devices with **Apache Kafka**, **Apache Flink**, and **ClickHouse**
- Built an automated inference pipeline combining LLMs, regression models, and physical models for automated fault detection in HVAC systems
- Developed a Python and LangGraph service that reads time-windowed features from ClickHouse, executes multi-model inference, and writes diagnostic results back to production data stores
- Supported fault isolation tasks including refrigerant leakage and coil blockage detection — directly analogous to fault isolation in semiconductor equipment

#### Intelligent Diagnosis Service: RAG, Knowledge Graphs, and LoRA Fine-Tuning

- Led the design and implementation of an enterprise RAG architecture using Python, Hugging Face, LangChain, and Neo4j knowledge graphs
- Improved domain-specific question-answering accuracy to **more than 92%** through chunking optimization, deduplication, and context-window tuning
- Applied **LoRA fine-tuning** to improve domain-specific model performance with **150% training speed improvement** using CUDA acceleration
- Built automated pipelines structuring **80,000+ rows** of after-sales service data into structured knowledge representations
- Applied **DBSCAN clustering** to operational sensor data for anomaly detection, validated with quantitative metrics and domain-expert review

#### Digital Twins and Predictive Modeling

- Contributed to predictive analytics workflows for **digital-twin-based physical model calibration** of HVAC testing equipment
- Developed **partial dependence analysis** to examine relationships among operational variables associated with refrigerant leakage — supporting prognostic health management of interconnected equipment
- Collaborated with modeling engineers to identify failure cases for predictive maintenance of equipment with complex subsystem interactions

#### ECAT Project: Front-End Engineering and Scrum Coordination

- Served as acting **Scrum Master**, coordinating 20+ JIRA tasks across a cross-functional team of nine engineers
- Reduced AWS resource usage for one module by **70%** through cloud architecture optimization

### Front-End Developer
**Accenture (China)** | January 2023 - July 2023

- Delivered product features for **Cathay Pacific's Vera Chatbot** using AngularJS, TypeScript, and Node.js
- Optimized API response times by **30%** through caching and query improvements

---

## Technical Skills

| Category | Skills |
|---|---|
| **Programming** | Python, Go, Java, MATLAB, TypeScript, SQL, Bash |
| **Distributed Systems** | Kubernetes (AWS EKS), Apache Kafka, Apache Flink, ClickHouse, Redis, RabbitMQ, MQTT, Argo Workflows |
| **AI / Machine Learning** | RAG, LangChain, LangGraph, LoRA fine-tuning, Hugging Face, anomaly detection (DBSCAN), CUDA optimization |
| **Knowledge & Semantics** | Neo4j knowledge graphs, semantic data organization, information retrieval |
| **Digital Twins / Modeling** | Physical model calibration, partial dependence analysis, predictive maintenance workflows |
| **Databases / Storage** | MySQL, ClickHouse, Neo4j, Elasticsearch, AWS S3, Pinecone, Snowflake |
| **Cloud / DevOps** | AWS, Docker, Terraform, Prometheus, Grafana, CI/CD |

---

## Selected Achievements

- MSc thesis awarded **Distinguished grade (Top 5%)** at Newcastle University
- BEng completed in the **Top 1%** of graduating class, ranked **#1 GPA** (2019-2020)
- Achieved **more than 92%** QA accuracy in an industrial RAG diagnostic system
- Reached **99.5% uptime** and **10,000 messages/second** in IoT orchestration platform evaluation
- Improved LoRA fine-tuning speed by **150%** with CUDA acceleration
- Reduced AWS resource usage by **70%** in a production engineering project

---

## References

**Prof. Ranjan**  
MSc Thesis Supervisor  
Department of Computer Science, Newcastle University  
Email: Raj.ranjan@newcastle.ac.uk  

**Liangjiang Yang**  
Line Manager, AI/Data Engineering  
Carrier Research & Development Center (Shanghai)  
Email: Liangjiang.Yang@Carrier.com  

---

*Customized for application to the PhD position in Diagnostics for Interconnected Complex Dynamical Systems at Eindhoven University of Technology (TU/e), supervised by Nathan van de Wouw, Tom Oomen, and Michelle Chong. Deadline: 18 April 2026.*
