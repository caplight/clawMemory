# MEMORY.md - Long-Term Memory

## 关于爸爸猫 (Wei Zhu)
- **名字：** 爸爸猫
- **时区：** Asia/Shanghai
- **联系方式：** 飞书
- **教育：** MSc Advanced Computer Science (Distinction) - Newcastle University; BEng Software Engineering (Top 1%) - Guangzhou University
- **工作：** Carrier R&D 中心
- **研究兴趣：** IoT编排、边缘计算、AI故障检测、数字孪生、工业数据分析

---

## PhD 申请系统

### 概述
- **目标：** 爬取荷兰+爱尔兰大学PhD岗位，存入MySQL，个性化评分后同步到Notion
- **脚本目录：** `/home/cap/script/`
- **Cron：** 每天18:00爬虫+评分，21:00备份

### 数据库 (MySQL)
- **库名：** `phd_jobs`
- **用户：** `phd_user` / `phd_pass_2026`
- **表：** `jobs`（114条记录）
- **root密码：** `root2026pass`

### Notion 同步
- **API Key：** `[NOTION_TOKEN_REDACTED]`
- **数据库 ID：** `329267b2-de94-8140-a6aa-f2f77cb5b1a2`
- **数据库名：** PhD 岗位追踪
- **评分阈值：** 50%

### 爬虫列表（18个大学）
| 国家 | 大学 |
|------|------|
| 荷兰 | TU Delft, UvA, Utrecht, Leiden, TU/e, Erasmus Rotterdam, Groningen, Wageningen, VU Amsterdam, Twente, Maastricht, Radboud, Tilburg |
| 爱尔兰 | Trinity College Dublin, UCD, UCC, University of Galway, UL, DCU, Maynooth, TU Dublin |

### Ranker 提示词
- **文件：** `/home/cap/script/phd_job_ranker.py`
- **定制维度：** 研究方向(40%) + 技术框架(30%) + 研究方法(30%)
- **加分项：** Go, Kubernetes, Redis, IoT编排, AI故障检测, 数字孪生, 预测性维护
- **减分项：** Postdoc要求, 经验不符

### 飞书报告
- **Webhook：** `https://open.feishu.cn/open-apis/bot/v2/hook/8833b911-2c46-456c-bf32-89beba681352`
- **内容：** 每个爬虫状态、新增条目、Ranker结果、高分岗位

---

## 系统配置

### OpenClaw Agent
- **main agent：** 飞书账号 `cli_a931578e07789cc7`
- **newbot agent：** 飞书账号 `cli_a9343ba5a3a2dbd6`，workspace 隔离

### Codex CLI
- **版本：** 0.116.0
- **配置：** `~/.codex/config.toml`，profile m27
- **API：** MiniMax MiniMax-M2.7 (model=MiniMax-M2.7)
- **base_url：** `https://api.minimaxi.com/v1`

### GitHub 备份
- **仓库：** `https://github.com/caplight/clawMemory`（private）
- **位置：** `/home/cap/backup/`

---

## 对话日志系统
- **数据库：** `conversation_logs.conversation_logs`
- **Web UI：** http://127.0.0.1:5000
- **脚本：** `/home/cap/script/conversation_logger.py`
- **状态：** 运行中

---

## 重要教训

### 验证原则（2026-03-22）
- 代码修改后必须先本地验证，通过后才能说"完成"
- 不能说"正在修复"而不验证结果
- 只有验证通过的需求才能验收

### 爸爸猫的反馈
- 只有验证通过的需求才能验收，才能说做完

## 工具使用规范（2026-03-24）
- **控制浏览器** → 用 **pinchtab**（浏览器自动化工具，已安装 v0.8.5）
  - Token：`16f5906eb44c584e3d7a7ff1a6569281abc1b2b5e0411f03`
  - Server 端口：localhost:9867
  - 常用命令：`pinchtab nav`, `pinchtab screenshot`, `pinchtab text`, `pinchtab find`, `pinchtab click`
- **爬网页内容** → 用 **scrapling**（自适应爬虫框架，已安装 v0.4.2）
  - CLI：`scrapling extract` / `scrapling stealthy-fetch`
  - 适合：绕过反爬、JS渲染页面、自适应解析

## AcademicTransfer 爬虫（新）
- **脚本**：`/home/cap/script/academictransfer_job_scraper.py`
- **数据**：`phd_jobs.jobs` 表，`source='academictransfer.com'`
- **URL**：`https://www.academictransfer.com/en/jobs/?q=<keyword>&function_types=1&scientific_fields=3&vacancy_type=scientific&order=published`
- **依赖**：Playwright headless（不是 scrapling）
- **关键词**：25个（精简版，见 `memory/2026-03-24.md`）

## JobTracker 就业岗位系统

### 概述
- **目标：** 爬取 LinkedIn (JobSpy) + Google Jobs (JSearch)，去重合并，落 MySQL，关键词×0.6+语义×0.4 评分，≥50分落 Notion，推飞书
- **脚本目录：** `/home/cap/script/JobTracker/`
- **Cron：** 每天 21:00（JobSpy + JSearch，JSearch 每2天一次，由状态文件控制）

### 完整流程
```
Step 1: run_search.py        → JobSpy爬虫 → MySQL（is_read=0, match_score=NULL）
                               JSearch爬虫 → 去重合并 → MySQL
Step 2: fix_descriptions.py → 补抓 description 为 NULL 的 LinkedIn 职位（scrapling）
Step 3: score_jobs.py        → 读未评分职位 → 关键词评分 × 0.6
                               MiniMax语义评分 × 0.4 → 回写MySQL（is_read=1）
Step 4: notion_sync.py      → 读MySQL评分≥50的职位 → 落入Notion新DB
Step 5: send_feishu.py      → 推送飞书报告
```

### 数据库 (MySQL - job_tracker.jobs)
- **库：** job_tracker，表：jobs
- **字段：** title, source, url, company, location, salary, employment_type, remote, posted_date, scraped_at, match_score, keyword_score, semantic_score, match_reason, technical_skills_score, experience_score, ai_agent_score, architecture_score, impact_score, education_score, strengths, gaps, resume_suggestions, hiring_decision, ats_keywords_present, ats_keywords_missing, notion_page_id
- **Notion DB：** `334267b2-de94-8131-a065-fc5ea7cdfda6`

### 搜索配置
- **关键词（12个）：** AI engineer, agent engineer, AI architect, data engineer, machine learning engineer, software engineer, backend engineer, distributed systems engineer, cloud engineer, DevOps engineer, NLP engineer, knowledge graph engineer
- **范围：** LinkedIn，仅过去24小时（time_range=day）
- **JSearch API：** 每2天跑一次

### 评分算法
- 关键词分 × 0.6 + MiniMax语义分 × 0.4 = 总分
- 语义分Prompt：Recruiter Agent格式，7维度评估（Technical Skills/Experience/AI Agent/Architecture/Impact/Education + Strengths/Gaps/Resume Suggestions/Hiring Decision/ATS Keywords）
- 阈值：≥50分落入Notion

### is_read 标记（重要！）
- **规则：** 新职位 `is_read=0`，评分后 `is_read=1`
- **查询未评分：** `WHERE match_score IS NULL AND is_read=0`
- **重新评分前提：** 必须同时 `SET match_score=NULL`（否则跳过得分的职位）
- **重要教训：** description 为 NULL 时评分会抛异常导致 match_score=NULL，此时需重新评分

### LinkedIn Description 补抓脚本
- **脚本：** `/home/cap/script/jobTracker/fix_descriptions.py`
- **方法：** scrapling + BeautifulSoup 直接抓 LinkedIn 职位页面
- **触发条件：** 新职位入库后发现 description 为 NULL
- **注意：** 必须先清空 match_score 再重跑评分

## 教训：JSON 转义（2026-03-30）
- **问题**：`send_feishu` 函数直接拼接字符串到 JSON，导致换行符破坏 JSON 格式，Feishu 拒绝请求
- **修复**：用 `jq -Rs` 做 JSON 转义 + `curl -d @-`
- **原则**：所有发往外部 API 的 JSON 必须用专门的库/jq 处理，不能手拼字符串

---

## 2026-04-01 工作记录

### JobTracker 路径问题
- 压缩包里 JobTracker 在 `/home/cap/script/jobTracker/`（小写J）
- 但脚本硬编码了 `/home/cap/script/JobTracker`（大写J）
- **修复：** `sed -i 's|/home/cap/script/JobTracker|/home/cap/script/jobTracker|g'` 全部脚本

### notion_sync.py 的 threshold Bug
- `sync_jobs_to_notion()` 函数里直接用了 `threshold` 变量但没定义
- 之前修过但因为路径问题脚本根本没更新到正确路径
- **修复：** 在函数内添加 `threshold = config.get("scoring", {}).get("score_threshold", 50)`

### 缺包问题
- `python-jobspy` 依赖 `pandas`、`markdownify`、`numpy`、`regex`
- `PyPDF2`、`python-docx` 也缺失
- pip 有 hash 校验问题，通过 `pip install --no-deps` + 手动下载 wheel 解决
- **经验：** 依赖用 `pip install --no-deps` 逐个装更干净

### description 字段缺失导致关键词评分全为0
- MySQL `job_tracker.jobs` 表没有 `description` 字段
- 95条职位 description 全是 NULL，关键词评分全是0
- **修复：** `ALTER TABLE jobs ADD COLUMN description TEXT`
- 回填：从 `/tmp/jobtracker_scraped.json` 批量 UPDATE

### 评分并发优化
- 原来串行 45-120秒/条，95条要几小时
- **修复：** `score_jobs.py` 加 `ThreadPoolExecutor(max_workers=12)` 并发
- MiniMax 超时从 45s 改为 120s

### run_all_scrapers.sh 脚本问题
- 串行跑18个爬虫，每个2-5分钟，总共跑很久
- **已重写为并行版本**（semaphore 控制最大8并发）
- 第一次重写有 bug：`collect_results` 函数定义方式不对 + emoji 未加引号
- **Bug原因：** bash `set -e` 下函数调用方式 + emoji 在 `echo` 中的问题

### IND NL 工签雇主名单
- 来源：IND 官网（scrapling stealthy-fetch 爬取）
- **12,590 个** IND Recognised Sponsors，保存在 `/home/cap/script/jobTracker/ind_nl_employers.json`
- MySQL 新增字段：`ind_visa_sponsor` TINYINT(1)
- `run_search.py` 存入时自动检查并标记
- 现有数据回填：VDL ETG Projects B.V.、ABN AMRO Bank N.V.

### 爱尔兰工签雇主名单
- **Excel：** `/home/cap/script/jobTracker/permits-issued-to-companies-2024.xlsx`（8061个雇主）
- **API：** IrishTalents API (`https://api.irishtalents.com/api/v1/companies`)
- 逻辑：Excel 优先，找不到再用 API fuzzy match
- MySQL 新增字段：`ireland_work_permit` TINYINT(1)
- `run_search.py` 存入时自动检查

### 备份优化
- 原来只备份 `workspace-main` + `workspace-newbot`
- **新增：** `scripts.tar.gz`（整个 `/home/cap/script` 目录，排除 .log 和 __pycache__）
- 大小：2.1M

### 待修复
- `run_all_scrapers.sh` 的并行版本需验证无bug，明天18:00 cron 会跑

## 重要教训

1. **修改代码后必须验证** —— 不能只改不改，更不能说"正在修复"
2. **路径问题要全局排查** —— 改了一处路径，要用 `grep` 搜所有脚本
3. **管道输出会被缓冲** —— `cmd >> log 2>&1 | tail` 看不到实时日志，直接写文件
4. **pip 包依赖问题** —— 先装兼容版本（`pandas<3.0`, `markdownify<0.14`, `numpy==1.26.3`）
5. **run_all_scrapers.sh 脚本bug** —— bash 函数不能与 `set -e` 冲突，字符串要加引号
6. **CV/CL 生成 SOP（2026-04-11）** —— 所有 resume 和 cover letter（职业+学术）必须由 main session 直接处理，禁止交给 subagent；Cursor review 也必须在 main session exec 里调用并拿到可见输出
7. **Chrome PDF header/footer 清除（2026-04-12）** —— Chrome 146/147 的 `--print-to-pdf-no-header-footer` flag 无效，Chrome 把 header/footer 渲染为光栅图形，无法用 flag 关闭；必须用 pypdfium2 高 DPI 渲染（300 DPI）→ 裁剪（顶部110px + 底部115px）→ 缩放至 200 DPI → JPEG Q=75 → PDF；参考 `/root/.openclaw/workspace/skills/resume-assistant/SKILL.md` 的 "PDF Export Pipeline" 章节

## 2026-04-20 更新

### GitHub 备份问题已解决
- **问题：** `workspace-main.tar.gz` 超过 100MB 限制，git push 被 GitHub 拒绝
- **原因：** 备份脚本之前用 `git push`，大文件超过 GitHub 限制
- **修复：** 改用 GitHub REST API 直接创建 blob/commit/ref（绕过 git push）
- **状态：** ✅ 已测试成功，commit b2c73ce32c3699a8f37fc819d4a06ec19c0beb8c

### 备份文件大小（正常值）
- `workspace-main.tar.gz`: ~148KB
- `workspace-newbot.tar.gz`: ~344KB  
- `workspace-wechatbot.tar.gz`: ~8KB
- `scripts.tar.gz`: ~2.1MB

### 待处理
- [ ] 检查 PhD 爬虫 master.log 为什么没有 4/20 的 summary（scrapers 本身运行了）

## 2026-04-26 更新

### WUR DECIDE PhD 申请
- **JD：** https://www.wur.nl/en/vacancy/phd-position-xai-help-people-make-better-dietary-choices
- **截止日期：** 4月30日
- **文件夹：** `VbCKfIUv9lZkOudZBxScaBIWnrN/WUR-xAI_Decide`（Drive folder token: `Jo1DfFTOIl7VPxd7k2zcWzWYnJd`）
- **CV token：** `WxZubCpHfoejENx1lijch2JEnjg`（2页）
- **CL token：** `Ip3NbUcgFo9Rgbxdgxocl6Xunj9`（1页）
- **参考格式：** `/home/cap/cv/CV_Engineering_Resumes_Trinity_ARIA_Early_Systems.pdf`
- **Research Vision：** tiered adaptive AI architecture（L0→L1 KG/DB→L2 counterfactual→L3 LLM），capability boundaries，trust calibration，behavioural outcomes

### UT DECIDE WP4 PhD 申请
- **JD：** https://www.academictransfer.com/en/jobs/360264/phd-position-on-domain-explanation-to-support-citizens-decision-making/
- **截止日期：** 6月11日
- **文件夹：** `VbCKfIUv9lZkOudZBxScaBIWnrN/UT-DECIDE_WP4`（Drive folder token: `OfKyfeOcDlNXxIdWOyicn7l2nzf`）
- **CV token：** `THWObnLCJokJmHxTWEgc9nTonMf`（2页）
- **CL token：** `AtiWbqoSKoo9Tsxv8AacZqjUnYf`（1页）
- **Supervisor：** Prof. Giancarlo Guizzardi（University of Twente）
- **方向：** Domain Explanation + Semantic Technologies（ontologies, KG）+ AI for citizen empowerment

### 正确的 SOP 流程（已更新到 AGENTS.md）
1. 准备：抓 JD + 读素材库 + 读参考格式 PDF（如有）
2. 内容生成：CV（无 Research Vision）+ CL（整合优化后的 Research Vision）
3. Cursor Review：prompt 写入文件 → cat 传给 cursor-agent → WeasyPrint 本地生成 PDF
4. 格式验证：pypdfium2 渲染确认格式 + 页数
5. 上传到用户提供的 Drive 文件夹（确认是用户的 Drive，不是我的）
6. 与用户对齐 Research Vision 优化方向
7. 提交检查清单
