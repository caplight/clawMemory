#!/bin/bash
# Codex Task Runner - 煤煤的代码执行封装脚本
# 用法: codex-task.sh <任务描述> [工作目录]

set -e

# 配置
MINIMAX_API_KEY="sk-cp-fQZxgx_WiWnu46I4AEHhprLAhHEVlr6_7s9vsTrX5Z-1rdhKPzo_8q-KrDdvlv_VhIgmMS3b7OK80MiM-4-f9Ni7PJx-p_98nqJUMRSaUrIpKge8rDTx-RE"
CODEX_PROFILE="m27"
WORK_DIR="${2:-/home/cap/projects}"

export MINIMAX_API_KEY

TASK="$1"

if [ -z "$TASK" ]; then
    echo "用法: codex-task.sh <任务描述> [工作目录]"
    exit 1
fi

mkdir -p "$WORK_DIR"

echo "🚀 开始执行任务: $TASK"
echo "📁 工作目录: $WORK_DIR"
echo ""

cd "$WORK_DIR"

# 执行 codex，使用 full-auto 模式
# --full-auto: 自动执行，不需要手动确认
# --sandbox workspace-write: 允许在 workspace 内写入
codex exec --profile "$CODEX_PROFILE" --full-auto -C "$WORK_DIR" -- "$TASK"

echo ""
echo "✅ 任务完成"
