#!/usr/bin/env python3
"""
Conversation Logger Web UI
Simple Flask web interface to view conversation logs.
"""

import os
import json
from datetime import datetime
from functools import wraps

from flask import Flask, render_template_string, request, jsonify
import pymysql


# ========== CONFIG ==========
MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.environ.get("MYSQL_PORT", "3306"))
MYSQL_USER = os.environ.get("MYSQL_USER", "root")
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.environ.get("MYSQL_DATABASE", "conversation_logs")

app = Flask(__name__)
app.config['DATABASE'] = {
    'host': MYSQL_HOST,
    'port': MYSQL_PORT,
    'user': MYSQL_USER,
    'password': MYSQL_PASSWORD,
    'database': MYSQL_DATABASE,
    'charset': 'utf8mb4',
}


def get_db():
    return pymysql.connect(**app.config['DATABASE'], autocommit=True)


def get_logs(session_key=None, channel=None, direction=None, tool_name=None, skill_name=None, limit=100, offset=0):
    """Fetch logs from database."""
    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cur:
            where_clauses = []
            params = []
            
            if session_key:
                where_clauses.append("session_key = %s")
                params.append(session_key)
            if channel:
                where_clauses.append("channel = %s")
                params.append(channel)
            if direction:
                where_clauses.append("direction = %s")
                params.append(direction)
            if tool_name:
                where_clauses.append("tool_name = %s")
                params.append(tool_name)
            if skill_name:
                where_clauses.append("skill_name = %s")
                params.append(skill_name)
            
            where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
            
            sql = f"""
                SELECT id, session_key, channel, log_date, direction, 
                       message, message_type, role, tool_name, skill_name,
                       LEFT(tool_input, 200) as tool_input_preview,
                       LEFT(tool_output, 200) as tool_output_preview
                FROM conversation_logs 
                WHERE {where_sql}
                ORDER BY log_date DESC, id DESC
                LIMIT %s OFFSET %s
            """
            params.extend([limit, offset])
            cur.execute(sql, params)
            return cur.fetchall()
    finally:
        conn.close()


def get_session_keys():
    """Get distinct session keys."""
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT session_key 
                FROM conversation_logs 
                GROUP BY session_key 
                ORDER BY MAX(log_date) DESC
            """)
            return [r[0] for r in cur.fetchall()]
    finally:
        conn.close()


def get_channels():
    """Get distinct channels."""
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT DISTINCT channel FROM conversation_logs ORDER BY channel")
            return [r[0] for r in cur.fetchall()]
    finally:
        conn.close()


def get_tool_names():
    """Get distinct tool names."""
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT DISTINCT tool_name 
                FROM conversation_logs 
                WHERE tool_name IS NOT NULL AND tool_name != '' AND tool_name != 'tool_result'
                ORDER BY tool_name
            """)
            return [r[0] for r in cur.fetchall() if r[0]]
    finally:
        conn.close()


def get_skill_names():
    """Get distinct skill names."""
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT DISTINCT skill_name 
                FROM conversation_logs 
                WHERE skill_name IS NOT NULL AND skill_name != ''
                ORDER BY skill_name
            """)
            return [r[0] for r in cur.fetchall() if r[0]]
    finally:
        conn.close()


def get_stats():
    """Get overall statistics."""
    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cur:
            cur.execute("""
                SELECT 
                    COUNT(*) as total,
                    SUM(CASE WHEN direction = 'inbound' THEN 1 ELSE 0 END) as inbound,
                    SUM(CASE WHEN direction = 'outbound' THEN 1 ELSE 0 END) as outbound,
                    SUM(CASE WHEN direction = 'system' THEN 1 ELSE 0 END) as sys_count,
                    SUM(CASE WHEN message_type = 'tool_use' THEN 1 ELSE 0 END) as tool_calls,
                    SUM(CASE WHEN message_type = 'tool_result' THEN 1 ELSE 0 END) as tool_results,
                    SUM(CASE WHEN message_type = 'skill_use' THEN 1 ELSE 0 END) as skill_calls,
                    COUNT(DISTINCT session_key) as sessions,
                    COUNT(DISTINCT channel) as channels
                FROM conversation_logs
            """)
            return cur.fetchone()
    finally:
        conn.close()


# ========== TEMPLATES ==========
INDEX_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Conversation Logger</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5; color: #333; line-height: 1.6;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 24px; margin-bottom: 5px; }
        .header p { opacity: 0.9; font-size: 14px; }
        .stats {
            display: flex; gap: 20px; margin-top: 15px; flex-wrap: wrap;
        }
        .stat {
            background: rgba(255,255,255,0.2); padding: 10px 15px; border-radius: 8px;
        }
        .stat-value { font-size: 24px; font-weight: bold; }
        .stat-label { font-size: 12px; opacity: 0.9; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        
        .filters {
            background: white; padding: 20px; border-radius: 12px; margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .filters h3 { margin-bottom: 15px; font-size: 16px; color: #667eea; }
        .filter-row { display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 12px; color: #666; font-weight: 500; }
        .filter-group select, .filter-group input {
            padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px;
            font-size: 14px; min-width: 150px;
        }
        .filter-group select:focus, .filter-group input:focus {
            outline: none; border-color: #667eea;
        }
        .btn {
            padding: 8px 20px; background: #667eea; color: white; border: none;
            border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500;
            transition: background 0.2s;
        }
        .btn:hover { background: #764ba2; }
        
        .logs-container {
            background: white; border-radius: 12px; overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .log-entry {
            padding: 15px 20px; border-bottom: 1px solid #eee;
            transition: background 0.2s;
        }
        .log-entry:hover { background: #f8f9fa; }
        .log-entry:last-child { border-bottom: none; }
        
        .log-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 8px; flex-wrap: wrap; gap: 10px;
        }
        .log-meta {
            display: flex; gap: 15px; align-items: center; flex-wrap: wrap;
        }
        .log-id { font-size: 12px; color: #999; }
        .log-direction {
            padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 500;
        }
        .direction-inbound { background: #e3f2fd; color: #1976d2; }
        .direction-outbound { background: #e8f5e9; color: #388e3c; }
        .direction-system { background: #f3e5f5; color: #7b1fa2; }
        
        .log-channel { 
            background: #fff3e0; color: #e65100; padding: 3px 10px; 
            border-radius: 12px; font-size: 12px;
        }
        .log-time { font-size: 12px; color: #666; }
        
        .log-message {
            background: #f8f9fa; padding: 12px; border-radius: 8px;
            font-size: 14px; word-break: break-word; max-height: 200px;
            overflow-y: auto; margin-bottom: 8px;
        }
        .log-message pre { white-space: pre-wrap; font-family: inherit; }
        
        .log-tools {
            display: flex; gap: 10px; flex-wrap: wrap; margin-top: 8px;
        }
        .tool-badge {
            background: #ffebee; color: #c62828; padding: 4px 10px;
            border-radius: 12px; font-size: 12px; font-weight: 500;
        }
        .skill-badge {
            background: #e0f2f1; color: #00695c; padding: 4px 10px;
            border-radius: 12px; font-size: 12px; font-weight: 500;
        }
        .tool-result-badge {
            background: #fff3e0; color: #e65100; padding: 4px 10px;
            border-radius: 12px; font-size: 12px; font-weight: 500;
        }
        .msg-type-badge {
            background: #e3f2fd; color: #1565c0; padding: 4px 10px;
            border-radius: 12px; font-size: 12px; font-weight: 500;
        }
        
        .pagination {
            padding: 20px; display: flex; justify-content: center; gap: 10px;
        }
        .pagination a {
            padding: 8px 15px; background: white; border: 1px solid #ddd;
            border-radius: 6px; text-decoration: none; color: #333;
        }
        .pagination a:hover { background: #667eea; color: white; border-color: #667eea; }
        
        .empty { text-align: center; padding: 60px 20px; color: #999; }
        .empty p { font-size: 18px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>💬 Conversation Logger</h1>
        <p>OpenClaw 消息记录查看器</p>
        <div class="stats">
            <div class="stat">
                <div class="stat-value">{{ stats.total or 0 }}</div>
                <div class="stat-label">总消息</div>
            </div>
            <div class="stat">
                <div class="stat-value">{{ stats.inbound or 0 }}</div>
                <div class="stat-label">收到</div>
            </div>
            <div class="stat">
                <div class="stat-value">{{ stats.outbound or 0 }}</div>
                <div class="stat-label">回复</div>
            </div>
            <div class="stat">
                <div class="stat-value">{{ stats.sessions or 0 }}</div>
                <div class="stat-label">会话</div>
            </div>
            <div class="stat">
                <div class="stat-value">{{ stats.tool_calls or 0 }}</div>
                <div class="stat-label">工具调用</div>
            </div>
            <div class="stat">
                <div class="stat-value">{{ stats.tool_results or 0 }}</div>
                <div class="stat-label">工具返回</div>
            </div>
            <div class="stat">
                <div class="stat-value">{{ stats.skill_calls or 0 }}</div>
                <div class="stat-label">技能调用</div>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="filters">
            <h3>🔍 筛选</h3>
            <form method="get" class="filter-row">
                <div class="filter-group">
                    <label>会话</label>
                    <select name="session">
                        <option value="">全部会话</option>
                        {% for sk in session_keys %}
                        <option value="{{ sk }}" {% if session == sk %}selected{% endif %}>{{ sk[:20] }}...</option>
                        {% endfor %}
                    </select>
                </div>
                <div class="filter-group">
                    <label>渠道</label>
                    <select name="channel">
                        <option value="">全部渠道</option>
                        {% for ch in channels %}
                        <option value="{{ ch }}" {% if channel == ch %}selected{% endif %}>{{ ch }}</option>
                        {% endfor %}
                    </select>
                </div>
                <div class="filter-group">
                    <label>方向</label>
                    <select name="direction">
                        <option value="">全部</option>
                        <option value="inbound" {% if direction == 'inbound' %}selected{% endif %}>收到</option>
                        <option value="outbound" {% if direction == 'outbound' %}selected{% endif %}>回复</option>
                        <option value="system" {% if direction == 'system' %}selected{% endif %}>系统</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label>工具</label>
                    <select name="tool_name">
                        <option value="">全部工具</option>
                        {% for tn in tool_names %}
                        <option value="{{ tn }}" {% if tool_name == tn %}selected{% endif %}>{{ tn }}</option>
                        {% endfor %}
                    </select>
                </div>
                <div class="filter-group">
                    <label>技能</label>
                    <select name="skill_name">
                        <option value="">全部技能</option>
                        {% for sn in skill_names %}
                        <option value="{{ sn }}" {% if skill_name == sn %}selected{% endif %}>{{ sn }}</option>
                        {% endfor %}
                    </select>
                </div>
                <div class="filter-group">
                    <label>每页数量</label>
                    <input type="number" name="limit" value="{{ limit }}" min="10" max="500">
                </div>
                <button type="submit" class="btn">应用筛选</button>
            </form>
        </div>
        
        <div class="logs-container">
            {% if logs %}
                {% for log in logs %}
                <div class="log-entry">
                    <div class="log-header">
                        <div class="log-meta">
                            <span class="log-id">#{{ log.id }}</span>
                            <span class="log-direction direction-{{ log.direction }}">{{ log.direction }}</span>
                            <span class="log-channel">{{ log.channel }}</span>
                            {% if log.role %}
                            <span class="log-id">{{ log.role }}</span>
                            {% endif %}
                        </div>
                        <span class="log-time">{{ log.log_date }}</span>
                    </div>
                    
                    {% if log.message %}
                    <div class="log-message">
                        <pre>{{ log.message }}</pre>
                    </div>
                    {% endif %}
                    
                    <div class="log-tools">
                        {% if log.message_type %}
                        <span class="msg-type-badge">{{ log.message_type }}</span>
                        {% endif %}
                        {% if log.tool_name and log.tool_name != 'tool_result' %}
                        <span class="tool-badge">🔧 {{ log.tool_name }}</span>
                        {% endif %}
                        {% if log.message_type == 'tool_result' %}
                        <span class="tool-result-badge">🔧 {{ log.tool_name }}</span>
                        {% endif %}
                        {% if log.skill_name %}
                        <span class="skill-badge">⚡ {{ log.skill_name }}</span>
                        {% endif %}
                        {% if log.tool_input_preview %}
                        <span class="log-id" title="{{ log.tool_input_preview }}">输入: {{ log.tool_input_preview[:50] }}...</span>
                        {% endif %}
                        {% if log.tool_output_preview %}
                        <span class="log-id" title="{{ log.tool_output_preview }}">输出: {{ log.tool_output_preview[:50] }}...</span>
                        {% endif %}
                    </div>
                </div>
                {% endfor %}
                
                {% if total_pages > 1 %}
                <div class="pagination">
                    {% if page > 1 %}
                    <a href="?page={{ page-1 }}&session={{ session }}&channel={{ channel }}&direction={{ direction }}&limit={{ limit }}">上一页</a>
                    {% endif %}
                    <span>第 {{ page }} / {{ total_pages }} 页</span>
                    {% if page < total_pages %}
                    <a href="?page={{ page+1 }}&session={{ session }}&channel={{ channel }}&direction={{ direction }}&limit={{ limit }}">下一页</a>
                    {% endif %}
                </div>
                {% endif %}
            {% else %}
                <div class="empty">
                    <p>暂无日志记录</p>
                    <p>尝试调整筛选条件</p>
                </div>
            {% endif %}
        </div>
    </div>
</body>
</html>
"""


# ========== ROUTES ==========
@app.route('/')
def index():
    session = request.args.get('session', '')
    channel = request.args.get('channel', '')
    direction = request.args.get('direction', '')
    tool_name = request.args.get('tool_name', '')
    skill_name = request.args.get('skill_name', '')
    page = int(request.args.get('page', 1))
    limit = int(request.args.get('limit', 100))
    offset = (page - 1) * limit
    
    logs = get_logs(session, channel, direction, tool_name, skill_name, limit, offset)
    stats = get_stats()
    session_keys = get_session_keys()
    channels = get_channels()
    tool_names = get_tool_names()
    skill_names = get_skill_names()
    
    # Count total for pagination
    conn = get_db()
    try:
        with conn.cursor() as cur:
            where_clauses = []
            params = []
            if session:
                where_clauses.append("session_key = %s")
                params.append(session)
            if channel:
                where_clauses.append("channel = %s")
                params.append(channel)
            if direction:
                where_clauses.append("direction = %s")
                params.append(direction)
            if tool_name:
                where_clauses.append("tool_name = %s")
                params.append(tool_name)
            if skill_name:
                where_clauses.append("skill_name = %s")
                params.append(skill_name)
            where_sql = " AND ".join(where_clauses) if where_clauses else "1=1"
            cur.execute(f"SELECT COUNT(*) FROM conversation_logs WHERE {where_sql}", params)
            total = cur.fetchone()[0]
    finally:
        conn.close()
    
    total_pages = (total + limit - 1) // limit
    
    return render_template_string(
        INDEX_TEMPLATE,
        logs=logs,
        stats=stats,
        session_keys=session_keys,
        channels=channels,
        tool_names=tool_names,
        skill_names=skill_names,
        session=session,
        channel=channel,
        direction=direction,
        tool_name=tool_name,
        skill_name=skill_name,
        page=page,
        limit=limit,
        total_pages=total_pages,
    )


@app.route('/api/logs')
def api_logs():
    """JSON API for logs."""
    session = request.args.get('session', '')
    channel = request.args.get('channel', '')
    direction = request.args.get('direction', '')
    limit = int(request.args.get('limit', 100))
    offset = int(request.args.get('offset', 0))
    
    logs = get_logs(session, channel, direction, limit, offset)
    return jsonify({
        'logs': [{
            'id': log['id'],
            'session_key': log['session_key'],
            'channel': log['channel'],
            'log_date': log['log_date'].isoformat() if log['log_date'] else None,
            'direction': log['direction'],
            'message': log['message'],
            'message_type': log['message_type'],
            'role': log['role'],
            'tool_name': log['tool_name'],
            'skill_name': log['skill_name'],
        } for log in logs]
    })


@app.route('/health')
def health():
    """Health check endpoint."""
    try:
        conn = get_db()
        conn.close()
        return jsonify({'status': 'ok'})
    except:
        return jsonify({'status': 'error'}), 500


# ========== MAIN ==========
if __name__ == '__main__':
    print("=" * 50)
    print("Conversation Logger Web UI")
    print(f"Database: {MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}")
    print("=" * 50)
    app.run(host='0.0.0.0', port=5000, debug=False)
