#!/bin/bash
# Conversation Logger Management Script

export MYSQL_HOST="${MYSQL_HOST:-localhost}"
export MYSQL_USER="${MYSQL_USER:-root}"
export MYSQL_PASSWORD="${MYSQL_PASSWORD:-root2026pass}"
export MYSQL_DATABASE="${MYSQL_DATABASE:-conversation_logs}"

LOGGER_PID_FILE="/tmp/conversation_logger.pid"
LOGGER_LOG_FILE="/home/cap/logs/conversation_logger.log"

mkdir -p /home/cap/logs

start() {
    if [ -f "$LOGGER_PID_FILE" ] && kill -0 $(cat "$LOGGER_PID_FILE") 2>/dev/null; then
        echo "Logger is already running (PID: $(cat $LOGGER_PID_FILE))"
        return 1
    fi
    
    echo "Starting Conversation Logger..."
    nohup python3 /home/cap/script/conversation_logger.py >> "$LOGGER_LOG_FILE" 2>&1 &
    echo $! > "$LOGGER_PID_FILE"
    echo "Logger started with PID: $(cat $LOGGER_PID_FILE)"
}

stop() {
    if [ ! -f "$LOGGER_PID_FILE" ]; then
        echo "Logger is not running (no PID file)"
        return 1
    fi
    
    PID=$(cat "$LOGGER_PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "Stopping logger (PID: $PID)..."
        kill "$PID"
        rm -f "$LOGGER_PID_FILE"
        echo "Logger stopped"
    else
        echo "Logger is not running (stale PID file)"
        rm -f "$LOGGER_PID_FILE"
    fi
}

status() {
    if [ -f "$LOGGER_PID_FILE" ] && kill -0 $(cat "$LOGGER_PID_FILE") 2>/dev/null; then
        PID=$(cat "$LOGGER_PID_FILE")
        echo "Logger is running (PID: $PID)"
        
        # Check DB count
        COUNT=$(mysql -u root -p"${MYSQL_PASSWORD}" -N -e "SELECT COUNT(*) FROM conversation_logs.conversation_logs" 2>/dev/null)
        echo "Total log entries: $COUNT"
    else
        echo "Logger is not running"
    fi
}

logs() {
    tail -50 "$LOGGER_LOG_FILE"
}

case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        stop
        sleep 1
        start
        ;;
    status)
        status
        ;;
    logs)
        logs
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs}"
        exit 1
        ;;
esac
