#!/usr/bin/env python3
"""
AcademicTransfer PhD Job Scraper

Searches AcademicTransfer for PhD positions matching Wei Zhu's keywords,
saves new jobs to MySQL phd_jobs.jobs table.

Uses Playwright (headless) to handle JS "Load more" button.
Scoring is handled by the existing phd_job_ranker.py cron task.

Usage:
    python3 academictransfer_job_scraper.py

Environment variables:
    MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE
"""

import os
import sys
import re
import time
import json
import urllib.parse
from datetime import datetime as dt

import requests
from bs4 import BeautifulSoup
import pymysql
from playwright.sync_api import sync_playwright


# ========== CONFIG ==========
DB_CONFIG = {
    'host': os.environ.get('MYSQL_HOST', 'localhost'),
    'user': os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', ''),
    'database': os.environ.get('MYSQL_DATABASE', 'phd_jobs')
}

SOURCE = 'academictransfer.com'

# Keywords matching Wei Zhu's research interests
KEYWORDS = [
    "AI",
    "machine learning",
    "deep learning",
    "computer science",
    "agent",
    "edge computing",
    "IoT",
    "orchestrator",
    "orchestration",
    "distributed systems",
    "generative AI",
    "explainable AI",
    "software",
    "data science",
    "predictive maintenance",
    "fault detection",
    "fault diagnosis",
    "knowledge graph",
    "networking",
    "wireless",
    "6G",
    "5G",
    "communication",
    "cloud",
    "edge",
]

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
}

def fetch_with_retry(url, timeout=20, max_retries=3):
    """Fetch a URL with retry and exponential backoff."""
    import time as _time
    for attempt in range(max_retries):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=timeout)
            if resp.status_code == 200:
                return resp
            elif resp.status_code == 429:
                retry_after = int(resp.headers.get("Retry-After", 60))
                print(f"  Rate limited, waiting {retry_after}s...")
                _time.sleep(retry_after)
            else:
                return resp
        except Exception as e:
            if attempt < max_retries - 1:
                _time.sleep(2 ** attempt)
            else:
                raise
    return None

BASE_URL = "https://www.academictransfer.com/en/jobs/"


# ========== DB ==========

def get_db_conn():
    return pymysql.connect(**DB_CONFIG, autocommit=True)

def job_exists(title):
    """Return True if job with same title+source already in DB."""
    conn = None
    try:
        conn = get_db_conn()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM jobs WHERE title=%s AND source=%s LIMIT 1",
                (title, SOURCE)
            )
            return cur.fetchone() is not None
    finally:
        if conn:
            conn.close()

def save_job(title, url, employer, published=None, deadline=None, full_text=""):
    """Insert job into MySQL. Skip duplicates silently."""
    try:
        conn = get_db_conn()
        with conn.cursor() as cur:
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            cur.execute(
                "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s)",
                (title, SOURCE, url, employer, published, deadline, full_text)
            )
        return True
    except pymysql.err.IntegrityError:
        return False  # duplicate
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()


# ========== DATE PARSING ==========

def parse_date(s):
    """Parse '5 Mar '26' or '16 Mar 2026' -> 'YYYY-MM-DD'."""
    if not s:
        return None
    s = s.strip()
    for fmt in ['%d %b %y', '%d %b %Y', '%Y-%m-%d', '%d/%m/%Y']:
        try:
            return dt.strptime(s, fmt).strftime('%Y-%m-%d')
        except ValueError:
            pass
    # Handle "tomorrow", "today"
    if s.lower() in ('tomorrow',):
        return dt.strftime(dt.today() + __import__('datetime').timedelta(days=1), '%Y-%m-%d')
    if s.lower() in ('today',):
        return dt.strftime(dt.today(), '%Y-%m-%d')
    return None


# ========== JOB DETAIL SCRAPER ==========

def scrape_job_detail(url, html_content=None):
    """Fetch job page, extract title/employer/dates/full_text."""
    if html_content:
        soup = BeautifulSoup(html_content, 'html.parser')
    else:
        try:
            resp = fetch_with_retry(url)
            if resp.status_code != 200:
                return None, None, None, None, None
            soup = BeautifulSoup(resp.text, 'html.parser')
        except Exception as e:
            return None, None, None, None, None

    # Title: try og:title meta first (most reliable)
    meta_title = soup.find('meta', attrs={'name': 'og:title'}) or \
                 soup.find('meta', attrs={'property': 'og:title'})
    if meta_title:
        title = meta_title.get('content', '').strip()
    else:
        tag = soup.find('h1') or soup.find('h2') or soup.find('title')
        title = tag.get_text(strip=True) if tag else f"AT Job {url}"

    # Employer: look for university name in body
    body = soup.get_text(separator=' ', strip=True)
    employer = None
    uni_pattern = (
        r'(?:at|@)\s+'
        r'(TU Delft|TU/e|Eindhoven University|Leiden University|'
        r'Utrecht University|University of Groningen|'
        r'University of Twente|Wageningen University|VU Amsterdam|'
        r'Erasmus University|Radboud|Tilburg University|'
        r'Maastricht University|TU Delft|delft|eindhoven|utrecht|leiden|'
        r'groningen|enschede|wageningen|amsterdam|rotterdam|maastricht)'
    )
    m = re.search(uni_pattern, body, re.I)
    if m:
        employer = m.group(0).lstrip('@at ').strip().title()

    # Published date
    published = None
    for pat in [
        r'Published?\s*:?\s*(\d{1,2}\s+[A-Za-z]{3}\s+[\'\"]?\d{2,4})',
        r'Publish(ed)?\s*:?\s*(\d{4}-\d{2}-\d{2})',
    ]:
        m = re.search(pat, body, re.I)
        if m:
            published = parse_date(m.group(1) or m.group(2))
            break

    # Deadline
    deadline = None
    for pat in [
        r'Deadline\s*:?\s*([\w\s\d]+?)(?:\n|$)',
        r'Closes?\s+on\s+(\d{1,2}\s+[A-Za-z]{3}\s+[\'\"]?\d{2,4})',
    ]:
        m = re.search(pat, body, re.I)
        if m:
            dl = m.group(1).strip()
            if dl.lower() not in ('none', 'n/a', '-', ''):
                deadline = parse_date(dl)
                if deadline:
                    break

    full_text = body[:3000]

    return title, employer, published, deadline, full_text


# ========== MAIN SCRAPER ==========

def build_search_url(keyword):
    """Build AcademicTransfer search URL with CS+PhD filters."""
    kw = urllib.parse.quote(keyword)
    # function_types=1: scientific positions (PhD-level)
    # scientific_fields=3: Computer Science
    # vacancy_type=scientific: scientific vacancies
    # order=published: newest first
    return (
        f"{BASE_URL}?q={kw}"
        "&function_types=1&scientific_fields=3&vacancy_type=scientific"
        "&order=published"
    )


def scrape_all_jobs_for_keyword(keyword, playwright_browser=None, ctx=None):
    """Use requests to fetch search page and extract job URLs from Nuxt SSR state."""
    search_url = build_search_url(keyword)

    try:
        resp = fetch_with_retry(search_url, timeout=15)
        if resp.status_code != 200:
            print(f"  [{keyword}] HTTP {resp.status_code}")
            return []
        html = resp.text
    except Exception as e:
        print(f"  [{keyword}] Fetch error: {e}")
        return []

    # Extract job URLs from Nuxt SSR JSON embedded in the page
    scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL)
    biggest_script = max(scripts, key=len) if scripts else ""

    job_urls = []
    seen = set()
    for href in re.findall(r'https://www\.academictransfer\.com(/en/jobs/\d+)', biggest_script):
        full_url = 'https://www.academictransfer.com' + href
        if full_url not in seen:
            seen.add(full_url)
            job_urls.append(full_url)

    # Also scan full HTML for any missed URLs
    for href in re.findall(r'/en/jobs/\d+', html):
        full_url = 'https://www.academictransfer.com' + href
        if full_url not in seen:
            seen.add(full_url)
            job_urls.append(full_url)

    # Read "X of Y" counter
    m = re.search(r'(\d+)\s+of\s+(\d+)', html)
    if m:
        shown, total = int(m.group(1)), int(m.group(2))
        print(f"  [{keyword}] Showing {shown} of {total} | found {len(job_urls)} URLs")
    else:
        print(f"  [{keyword}] Found {len(job_urls)} URLs")

    return job_urls


def main():
    print(f"\n{'='*60}")
    print(f"AcademicTransfer PhD Job Scraper")
    print(f"Keywords: {len(KEYWORDS)}")
    print(f"DB: {DB_CONFIG['database']}@{DB_CONFIG['host']}")
    print(f"{'='*60}\n")

    total_found = 0
    total_saved = 0

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=['--no-sandbox', '--disable-dev-shm-usage']
        )

        for i, keyword in enumerate(KEYWORDS):
            print(f"[{i+1}/{len(KEYWORDS)}] Keyword: '{keyword}'")

            try:
                job_urls = scrape_all_jobs_for_keyword(keyword)
            except Exception as e:
                print(f"  ERROR getting job URLs: {e}")
                continue

            for url in job_urls:
                try:
                    # Check duplicate before fetching detail (saves HTTP request)
                    # Extract job ID for title placeholder
                    m = re.search(r'/en/jobs/(\d+)/', url)
                    job_id = m.group(1) if m else '?'

                    # Quick title-only fetch first
                    resp = fetch_with_retry(url, timeout=15)
                    if resp.status_code != 200:
                        continue
                    soup = BeautifulSoup(resp.text, 'html.parser')
                    meta_t = soup.find('meta', attrs={'name': 'og:title'})
                    title = meta_t.get('content', '').strip() if meta_t else f"AT Job {job_id}"

                    if job_exists(title):
                        continue

                    # Fetch full details (reuse already-fetched HTML)
                    title, employer, published, deadline, full_text = scrape_job_detail(url, html_content=resp.text)

                    if save_job(title, url, employer, published, deadline, full_text):
                        print(f"  SAVED: {title[:65]}")
                        total_saved += 1
                    total_found += 1

                    time.sleep(3)

                except Exception as e:
                    print(f"  ERROR: {e}")
                    continue

            time.sleep(2)

        browser.close()

    print(f"\n{'='*60}")
    print(f"Done! Found {total_found} jobs, saved {total_saved} new entries.")
    print(f"{total_saved} saved to DB")
    print(f"{'='*60}\n")
    sys.exit(0)


if __name__ == '__main__':
    main()
