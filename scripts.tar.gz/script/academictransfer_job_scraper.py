#!/usr/bin/env python3
"""
AcademicTransfer PhD Job Scraper

Searches AcademicTransfer for PhD positions matching Wei Zhu's keywords,
saves new jobs to MySQL phd_jobs.jobs table.

Uses requests + BeautifulSoup; Session + browser-like headers to reduce blocks.

Usage:
    python3 academictransfer_job_scraper.py

Environment variables:
    MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD, MYSQL_DATABASE
"""

import os
import sys
import re
import time
import random
import signal
import urllib.parse
from datetime import datetime as dt

import requests
from bs4 import BeautifulSoup
import pymysql


# ========== CONFIG ==========
DB_CONFIG = {
    'host': os.environ.get('MYSQL_HOST', 'localhost'),
    'user': os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', ''),
    'database': os.environ.get('MYSQL_DATABASE', 'phd_jobs')
}

SOURCE = 'academictransfer.com'

# Keywords matching Wei Zhu's research interests
KEYWORDS = [
    "AI",
    "machine learning",
    "deep learning",
    "computer science",
    "agent",
    "edge computing",
    "IoT",
    "orchestrator",
    "orchestration",
    "distributed systems",
    "generative AI",
    "explainable AI",
    "software",
    "data science",
    "predictive maintenance",
    "fault detection",
    "fault diagnosis",
    "knowledge graph",
    "networking",
    "wireless",
    "6G",
    "5G",
    "communication",
    "cloud",
    "edge",
]

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
]


def log(msg=""):
    print(msg, flush=True)


def build_headers(referer=None):
    referer = referer or 'https://www.academictransfer.com/en/jobs/'
    return {
        'User-Agent': random.choice(USER_AGENTS),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,nl;q=0.8',
        'Accept-Encoding': 'gzip, deflate, br',
        'Referer': referer,
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'same-origin' if 'academictransfer.com' in referer else 'none',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0',
    }


def looks_like_challenge_or_block(resp):
    """Detect Cloudflare / anti-bot challenge pages and useless bodies."""
    if resp is None:
        return True
    text = resp.text or ''
    low = text.lower()
    status = resp.status_code

    markers = (
        'cf-browser-verification',
        'cf-challenge',
        'cf-chl-bypass',
        '__cf_chl',
        'challenge-platform',
        '/cdn-cgi/challenge',
        'just a moment',
        'checking your browser',
        'enable javascript and cookies',
        'attention required',
        'sorry, you have been blocked',
        '挑战',
        'ddos protection',
        'ray id',
    )
    if any(m in low for m in markers):
        return True
    if status in (403, 503):
        return True
    if status == 200:
        # Likely interstitial or empty shell (no Nuxt / job payload)
        if len(text.strip()) < 800 and 'nuxt' not in low and '__NUXT' not in text:
            if 'academictransfer' in low or len(text.strip()) < 200:
                return True
    return False


def fetch_with_retry(url, session, timeout=20, max_retries=4, referer=None):
    """Fetch with Session cookies, rotating UA, retry on challenge/block."""
    for attempt in range(max_retries):
        headers = build_headers(referer=referer)
        try:
            resp = session.get(url, headers=headers, timeout=timeout)
            log(f"  GET {url[:90]}{'...' if len(url) > 90 else ''} -> HTTP {resp.status_code} len={len(resp.text or '')}")

            if resp.status_code == 429:
                retry_after = int(resp.headers.get('Retry-After', 30))
                log(f"  Rate limited, waiting {retry_after}s...")
                time.sleep(retry_after)
                continue

            if resp.status_code != 200:
                log(f"  HTTP {resp.status_code} (attempt {attempt + 1}/{max_retries}) url={url[:100]}")
                if attempt < max_retries - 1:
                    time.sleep(0.5 * (attempt + 1))
                continue

            if looks_like_challenge_or_block(resp):
                log(f"  Challenge/block-like response (attempt {attempt + 1}/{max_retries}), retrying...")
                if attempt < max_retries - 1:
                    time.sleep(0.75 * (attempt + 1))
                continue

            return resp

        except Exception as e:
            log(f"  Request error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                time.sleep(0.5 * (2 ** attempt))

    log(f"  FAILED after retries: {url[:120]}")
    return None


BASE_URL = "https://www.academictransfer.com/en/jobs/"


# ========== DB ==========

def get_db_conn():
    return pymysql.connect(**DB_CONFIG, autocommit=True)

def job_exists(title):
    """Return True if job with same title+source already in DB."""
    log(f"  job_exists check: {title[:80]}{'...' if len(title) > 80 else ''}")
    conn = None
    try:
        conn = get_db_conn()
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM jobs WHERE title=%s AND source=%s LIMIT 1",
                (title, SOURCE)
            )
            exists = cur.fetchone() is not None
            log(f"  job_exists -> {exists}")
            return exists
    except Exception as e:
        log(f"  [DB ERROR job_exists] {e}")
        raise
    finally:
        if conn:
            conn.close()

def save_job(title, url, employer, published=None, deadline=None, full_text=""):
    """Insert job into MySQL. Skip duplicates silently."""
    conn = None
    try:
        conn = get_db_conn()
        with conn.cursor() as cur:
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            cur.execute(
                "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) "
                "VALUES (%s,%s,%s,%s,%s,%s,%s)",
                (title, SOURCE, url, employer, published, deadline, full_text)
            )
        log(f"  save_job: inserted OK -> {title[:65]}{'...' if len(title) > 65 else ''}")
        return True
    except pymysql.err.IntegrityError:
        log(f"  save_job: duplicate (integrity), skipped")
        return False  # duplicate
    except Exception as e:
        log(f"  [DB ERROR save_job] {e}")
        return False
    finally:
        if conn:
            conn.close()


# ========== DATE PARSING ==========

def parse_date(s):
    """Parse '5 Mar '26' or '16 Mar 2026' -> 'YYYY-MM-DD'."""
    if not s:
        return None
    s = s.strip()
    for fmt in ['%d %b %y', '%d %b %Y', '%Y-%m-%d', '%d/%m/%Y']:
        try:
            return dt.strptime(s, fmt).strftime('%Y-%m-%d')
        except ValueError:
            pass
    # Handle "tomorrow", "today"
    if s.lower() in ('tomorrow',):
        return dt.strftime(dt.today() + __import__('datetime').timedelta(days=1), '%Y-%m-%d')
    if s.lower() in ('today',):
        return dt.strftime(dt.today(), '%Y-%m-%d')
    return None


# ========== JOB DETAIL SCRAPER ==========

def scrape_job_detail(url, html_content=None, session=None):
    """Fetch job page, extract title/employer/dates/full_text."""
    if html_content:
        soup = BeautifulSoup(html_content, 'html.parser')
    else:
        try:
            log(f"  scrape_job_detail: fetching {url}")
            sess = session or requests.Session()
            resp = fetch_with_retry(url, sess, timeout=15, referer=BASE_URL)
            if resp is None or resp.status_code != 200:
                log(f"  scrape_job_detail: bad response for {url}")
                return None, None, None, None, None
            if looks_like_challenge_or_block(resp):
                log(f"  scrape_job_detail: challenge/block page for {url}")
                return None, None, None, None, None
            soup = BeautifulSoup(resp.text, 'html.parser')
        except Exception as e:
            log(f"  scrape_job_detail: error {e}")
            return None, None, None, None, None

    # Title: try og:title meta first (most reliable)
    meta_title = soup.find('meta', attrs={'name': 'og:title'}) or \
                 soup.find('meta', attrs={'property': 'og:title'})
    if meta_title:
        title = meta_title.get('content', '').strip()
    else:
        tag = soup.find('h1') or soup.find('h2') or soup.find('title')
        title = tag.get_text(strip=True) if tag else f"AT Job {url}"

    # Employer: look for university name in body
    body = soup.get_text(separator=' ', strip=True)
    employer = None
    uni_pattern = (
        r'(?:at|@)\s+'
        r'(TU Delft|TU/e|Eindhoven University|Leiden University|'
        r'Utrecht University|University of Groningen|'
        r'University of Twente|Wageningen University|VU Amsterdam|'
        r'Erasmus University|Radboud|Tilburg University|'
        r'Maastricht University|TU Delft|delft|eindhoven|utrecht|leiden|'
        r'groningen|enschede|wageningen|amsterdam|rotterdam|maastricht)'
    )
    m = re.search(uni_pattern, body, re.I)
    if m:
        employer = m.group(0).lstrip('@at ').strip().title()

    # Published date
    published = None
    for pat in [
        r'Published?\s*:?\s*(\d{1,2}\s+[A-Za-z]{3}\s+[\'\"]?\d{2,4})',
        r'Publish(ed)?\s*:?\s*(\d{4}-\d{2}-\d{2})',
    ]:
        m = re.search(pat, body, re.I)
        if m:
            published = parse_date(m.group(1) or m.group(2))
            break

    # Deadline
    deadline = None
    for pat in [
        r'Deadline\s*:?\s*([\w\s\d]+?)(?:\n|$)',
        r'Closes?\s+on\s+(\d{1,2}\s+[A-Za-z]{3}\s+[\'\"]?\d{2,4})',
    ]:
        m = re.search(pat, body, re.I)
        if m:
            dl = m.group(1).strip()
            if dl.lower() not in ('none', 'n/a', '-', ''):
                deadline = parse_date(dl)
                if deadline:
                    break

    full_text = body[:3000]

    return title, employer, published, deadline, full_text


# ========== MAIN SCRAPER ==========

def build_search_url(keyword):
    """Build AcademicTransfer search URL with CS+PhD filters."""
    kw = urllib.parse.quote(keyword)
    # function_types=1: scientific positions (PhD-level)
    # scientific_fields=3: Computer Science
    # vacancy_type=scientific: scientific vacancies
    # order=published: newest first
    return (
        f"{BASE_URL}?q={kw}"
        "&function_types=1&scientific_fields=3&vacancy_type=scientific"
        "&order=published"
    )


def scrape_all_jobs_for_keyword(keyword, session):
    """Fetch search page and extract job URLs from Nuxt SSR state."""
    search_url = build_search_url(keyword)
    log(f"  Fetching search: {search_url}")

    try:
        resp = fetch_with_retry(search_url, session, timeout=15, referer='https://www.academictransfer.com/en/')
        if resp is None:
            log(f"  [{keyword}] No usable response after retries")
            return []
        if resp.status_code != 200:
            log(f"  [{keyword}] HTTP {resp.status_code}")
            return []
        html = resp.text
    except Exception as e:
        log(f"  [{keyword}] Fetch error: {e}")
        return []

    if looks_like_challenge_or_block(resp):
        log(f"  [{keyword}] Response still looks blocked/challenge after fetch; skipping parse")
        return []

    # Extract job URLs from Nuxt SSR JSON embedded in the page
    scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.DOTALL)
    biggest_script = max(scripts, key=len) if scripts else ""

    job_urls = []
    seen = set()
    for href in re.findall(r'https://www\.academictransfer\.com(/en/jobs/\d+)', biggest_script):
        full_url = 'https://www.academictransfer.com' + href
        if full_url not in seen:
            seen.add(full_url)
            job_urls.append(full_url)

    # Also scan full HTML for any missed URLs
    for href in re.findall(r'/en/jobs/\d+', html):
        full_url = 'https://www.academictransfer.com' + href
        if full_url not in seen:
            seen.add(full_url)
            job_urls.append(full_url)

    # Read "X of Y" counter
    m = re.search(r'(\d+)\s+of\s+(\d+)', html)
    if m:
        shown, total = int(m.group(1)), int(m.group(2))
        log(f"  [{keyword}] Showing {shown} of {total} | found {len(job_urls)} URLs")
    else:
        log(f"  [{keyword}] Found {len(job_urls)} URLs")

    return job_urls


def main():
    log(f"\n{'='*60}")
    log(f"AcademicTransfer PhD Job Scraper — start {dt.now().isoformat()}")
    log(f"Keywords: {len(KEYWORDS)}")
    log(f"DB: {DB_CONFIG['database']}@{DB_CONFIG['host']}")
    log(f"{'='*60}\n")

    session = requests.Session()
    # Prime cookies from site root (helps some WAFs)
    log("Priming session (homepage)...")
    try:
        fetch_with_retry(
            'https://www.academictransfer.com/en/',
            session,
            timeout=15,
            max_retries=2,
            referer='https://www.academictransfer.com/',
        )
    except Exception as e:
        log(f"  Homepage prime failed (continuing): {e}")

    total_found = 0
    total_saved = 0

    try:
        for i, keyword in enumerate(KEYWORDS):
            log(f"[{i+1}/{len(KEYWORDS)}] Keyword: '{keyword}'")

            try:
                job_urls = scrape_all_jobs_for_keyword(keyword, session)
                log(f"  Keyword '{keyword}': {len(job_urls)} job URL(s) to process")
            except Exception as e:
                log(f"  ERROR getting job URLs: {e}")
                continue

            for url in job_urls:
                try:
                    m = re.search(r'/en/jobs/(\d+)/', url)
                    job_id = m.group(1) if m else '?'
                    log(f"  Processing job URL id={job_id}: {url}")

                    resp = fetch_with_retry(url, session, timeout=15, referer=BASE_URL)
                    if resp is None or resp.status_code != 200:
                        log(f"  SKIP job {job_id}: bad response")
                        continue
                    if looks_like_challenge_or_block(resp):
                        log(f"  SKIP job {job_id}: challenge/block page")
                        continue

                    soup = BeautifulSoup(resp.text, 'html.parser')
                    meta_t = soup.find('meta', attrs={'name': 'og:title'})
                    title = meta_t.get('content', '').strip() if meta_t else f"AT Job {job_id}"

                    if job_exists(title):
                        log(f"  SKIP (already in DB): {title[:65]}")
                        continue

                    title, employer, published, deadline, full_text = scrape_job_detail(
                        url, html_content=resp.text, session=session
                    )

                    if save_job(title, url, employer, published, deadline, full_text):
                        log(f"  SAVED: {title[:65]}")
                        total_saved += 1
                    else:
                        log(f"  Not saved (duplicate or DB error): {title[:65]}")
                    total_found += 1

                    time.sleep(0.75)

                except Exception as e:
                    log(f"  ERROR processing URL: {e}")
                    continue

            time.sleep(0.4)

    finally:
        log("Main loop finished.")

    log(f"\n{'='*60}")
    log(f"Done! Found {total_found} jobs, saved {total_saved} new entries.")
    log(f"{total_saved} saved to DB")
    log(f"{'='*60}\n")
    sys.exit(0)


if __name__ == '__main__':
    def _on_sigterm(signum, frame):
        log("SIGTERM received, exiting gracefully...")
        sys.exit(0)

    signal.signal(signal.SIGTERM, _on_sigterm)
    main()
