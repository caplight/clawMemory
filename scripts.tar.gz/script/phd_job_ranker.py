#!/usr/bin/env python3
"""
PhD Job Semantic Ranker
Uses Cursor LLM to score unread jobs across 3 dimensions:
  1. Research direction/theme (40%)
  2. Theoretical framework (30%)
  3. Research methods (30%)

Jobs with total score >= threshold sync to Notion.
Cron: 19:00 daily.
"""

import os
import re
import time
import json
import subprocess
import sys
from datetime import datetime as dt

import pymysql
import requests

# ========== CONFIG ==========
# Prefer environment variables (set by shell wrappers); fall back to config.json for cron/isolated runs.
DEFAULT_CONFIG_PATH = "/home/cap/script/phd_job_ranker_config.json"


def load_ranker_config():
    """Load config from env vars first, then config.json as fallback."""
    cfg = {}
    # Env vars take priority
    cfg["minimax_api_key"] = os.environ.get("MINIMAX_API_KEY", "")
    cfg["minimax_model"] = os.environ.get("MINIMAX_MODEL", "MiniMax-M2.7")
    cfg["minimax_api"] = os.environ.get("MINIMAX_API", "https://api.minimaxi.com/v1/chat/completions")
    cfg["mysql_host"] = os.environ.get("MYSQL_HOST", "localhost")
    cfg["mysql_user"] = os.environ.get("MYSQL_USER", "root")
    cfg["mysql_password"] = os.environ.get("MYSQL_PASSWORD", "")
    cfg["mysql_database"] = os.environ.get("MYSQL_DATABASE", "phd_jobs")
    cfg["notion_api_key"] = os.environ.get("NOTION_API_KEY", "")
    cfg["notion_db_id"] = os.environ.get("NOTION_DB_ID", "")
    cfg["feishu_webhook"] = os.environ.get("FEISHU_WEBHOOK", "")
    cfg["score_threshold"] = int(os.environ.get("SCORE_THRESHOLD", "50"))

    # If required keys are still empty, try config.json
    if not cfg["minimax_api_key"] or not cfg["notion_db_id"]:
        config_path = os.environ.get("PHD_RANKER_CONFIG", DEFAULT_CONFIG_PATH)
        try:
            with open(config_path) as f:
                file_cfg = json.load(f)
            for k, v in file_cfg.items():
                # Always use file value for these keys if env is empty
                if k in ("minimax_api_key", "notion_api_key", "notion_db_id"):
                    if not cfg.get(k):
                        cfg[k] = v
                elif k not in cfg or not cfg[k]:
                    cfg[k] = v
        except Exception:
            pass
    return cfg


RANKER_CFG = load_ranker_config()

# Convenience aliases
MINIMAX_API_KEY = RANKER_CFG["minimax_api_key"]
MINIMAX_MODEL = RANKER_CFG["minimax_model"]
MINIMAX_API = RANKER_CFG["minimax_api"]
MYSQL_CONFIG = {
    "host": RANKER_CFG["mysql_host"],
    "user": RANKER_CFG["mysql_user"],
    "password": RANKER_CFG["mysql_password"],
    "database": RANKER_CFG["mysql_database"],
    "charset": "utf8mb4",
}
NOTION_API_KEY = RANKER_CFG["notion_api_key"]
NOTION_DB_ID = RANKER_CFG["notion_db_id"]
FEISHU_WEBHOOK = RANKER_CFG["feishu_webhook"]
SCORE_THRESHOLD = RANKER_CFG["score_threshold"]

NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2025-09-03",
    "Content-Type": "application/json",
}

BATCH_SIZE = 5

# ========== PROMPT ==========
def build_prompt(title, employer, full_text):
    desc = full_text[:3000] if full_text else "No description available."
    # Candidate background for personalized matching
    CANDIDATE_BACKGROUND = """
## 候选人背景（Wei Zhu）

### 教育
- MSc Advanced Computer Science (Distinction, 72/100) - Newcastle University, UK
- BEng Software Engineering (84/100, Top 1%) - Guangzhou University Sontan College

### 研究经历
1. **硕士论文：数据流编排平台** (Distinction, Top 5%)
   - 设计实现可扩展编排框架，协调边缘-云层异构IoT设备
   - Go语言开发，Kubernetes部署，Redis动态路由表，MessageQueue插件架构
   - 99.5%可用性，10,000 msg/sec吞吐量

2. **安全与弹性项目**：CRT医疗设备加密软件

### 工作经验（Carrier R&D中心）
- RAG架构：HuggingFace、Langchain、LLaMA/DeepSeek优化（>92%准确率）
- LoRA微调：机器翻译（BLEU评估，82%满意度）
- 知识图谱：Neo4j构建，HVAC诊断预测
- 数字孪生：算法生态系统迁移

### 技术栈
- 语言：Python, Go, Java
- 框架/工具：Kubernetes, Redis, Kafka/RabbitMQ, Langchain, HuggingFace
- 数据库：MySQL, Redis, Elasticsearch, Neo4j
- 云：AWS S3, EC2

### 研究兴趣
- 自组织边缘基础设施、边缘-云资源编排
- IoT协调与协议标准化、ML/AI监控与故障检测
- 知识图谱、数字孪生
"""
    
    return f"""你是一个PhD岗位匹配度评估助手。请根据候选人的背景信息，对候选岗位进行个性化评分。

{CANDIDATE_BACKGROUND}

---

## 评分维度（三个维度，总分100分）

### 1. 研究方向匹配度 (40%)
评估岗位的核心研究方向是否与候选人的背景和兴趣高度契合：
- 高度相关：IoT编排、边缘计算、分布式系统、网络基础设施、自组织系统、云计算协调、**AI故障检测与预测性维护**、**数字孪生**、**工业数据分析**、异常检测、实时监控系统
- 中等相关：物联网、移动网络、5G/6G、在线服务、制造业数字化
- 低相关：纯理论AI、纯ML应用（非系统方向）、前端开发、生物医学工程

### 2. 技术/理论框架匹配度 (30%)
评估岗位要求的理论框架是否与候选人的技能栈匹配：
- 高度相关：分布式系统理论、消息队列/中间件、Kubernetes/容器编排、Redis、数据流处理、边缘计算架构
- 中等相关：微服务架构，云原生技术、NoSQL
- 低相关：仅传统ML、深度学习框架（非分布式场景）

### 3. 研究方法/技能匹配度 (30%)
评估岗位的研究方法是否与候选人的实际经验匹配：
- 高度相关：Go/Python开发、Kubernetes部署、Redis、消息队列、**机器学习/AI方法**（异常检测、分类、回归）、**数字孪生**、性能基准测试、IoT设备协调、实时系统、**工业数据分析**
- 中等相关：Java开发，云服务、数据工程、MATLAB/Simulink
- 低相关：仅理论分析，前端开发

---

## 加分/减分规则
- **加分**：岗位涉及Go语言、Kubernetes、Redis、IoT编排、边缘-云协调 → 额外加5-10分
- **减分**：岗位要求Postdoc经历、经验不符 → 扣10-20分

请从以下岗位描述中提取评分信息，并返回JSON格式结果（只返回JSON，不要任何其他内容）：

JSON格式：
{{
  "research_direction_score": <int 0-100>,
  "research_direction_reason": "<一句话说明理由，引用原文关键词>",
  "theoretical_framework_score": <int 0-100>,
  "theoretical_framework_reason": "<一句话说明理由，引用原文关键词>",
  "research_methods_score": <int 0-100>,
  "research_methods_reason": "<一句话说明理由，引用原文关键词>",
  "total_score": <int 0-100>,
  "matching_keywords": ["<关键词1>", "<关键词2>"],
  "warning_flags": ["<警告：如Postdoc、经验不符等>"],
  "summary": "<50字以内的综合评价>"
}}

岗位信息：
Title: {title}
Employer: {employer}
Description: {desc}
"""

# ========== DB ==========


def get_db():
    return pymysql.connect(**MYSQL_CONFIG, autocommit=True)


def get_unread_jobs():
    conn = None
    try:
        conn = get_db()
        with conn.cursor(pymysql.cursors.DictCursor) as cur:
            cur.execute("""
                SELECT id, title, source, url, employer, published, deadline, full_text
                FROM jobs
                WHERE is_read = 0
                ORDER BY created_at DESC
            """)
            return cur.fetchall()
    finally:
        if conn:
            conn.close()


def mark_jobs_read(ids):
    if not ids:
        return
    conn = None
    try:
        conn = get_db()
        with conn.cursor() as cur:
            placeholders = ",".join(["%s"] * len(ids))
            sql = f"UPDATE jobs SET is_read = 1 WHERE id IN ({placeholders})"
            cur.execute(sql, ids)
    finally:
        if conn:
            conn.close()


# ========== LLM SCORING (Cursor) ==========
def score_job_llm(job):
    """Call Cursor to score a job across 3 dimensions."""
    prompt = build_prompt(
        str(job.get("title") or ""),
        str(job.get("employer") or ""),
        str(job.get("full_text") or ""),
    )

    cursor_cmd = [
        "/root/.local/share/cursor-agent/versions/2026.04.17-787b533/cursor-agent",
        "--print", "--trust",
        "--workspace", "/tmp",
        "--model", "gpt-5.4-medium",
        prompt
    ]

    try:
        env = {**os.environ, 'HOME': '/root', 'CURSOR_API_KEY': 'crsr_52a93dc742cd3f3a9934e09a364b49634f9457ead0f27bc81a7954912819d8eb'}
        result = subprocess.run(
            cursor_cmd,
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )
        content = result.stdout.strip()

        if not content:
            # Fallback to stderr if stdout empty
            content = result.stderr.strip()
        if not content:
            return None, f"Cursor returned empty output (returncode={result.returncode})"

        # Extract JSON from response
        start = content.find("{")
        end = content.rfind("}") + 1
        if start == -1 or end == 0:
            return None, f"No JSON found in Cursor output: {content[:200]}"

        json_str = content[start:end]
        # Remove any markdown code fences if present
        json_str = re.sub(r'^```(?:json)?\s*', '', json_str).strip()
        json_str = re.sub(r'\s*```$', '', json_str).strip()

        parsed = json.loads(json_str)

        total = parsed.get("total_score", 0)
        reason = " | ".join([
            f"方向:{parsed.get('research_direction_score',0)} {parsed.get('research_direction_reason','')[:40]}",
            f"框架:{parsed.get('theoretical_framework_score',0)} {parsed.get('theoretical_framework_reason','')[:40]}",
            f"方法:{parsed.get('research_methods_score',0)} {parsed.get('research_methods_reason','')[:40]}",
        ])

        return {
            "total_score": total,
            "research_direction_score": parsed.get("research_direction_score", 0),
            "theoretical_framework_score": parsed.get("theoretical_framework_score", 0),
            "research_methods_score": parsed.get("research_methods_score", 0),
            "summary": parsed.get("summary", ""),
            "reason": reason,
        }, None

    except subprocess.TimeoutExpired:
        return None, "Cursor timeout (>120s)"
    except json.JSONDecodeError as e:
        return None, f"JSON parse error: {e} | content: {content[:200]}"
    except Exception as e:
        return None, f"Cursor error: {e}"


# ========== NOTION ==========
def notion_search_existing(url):
    if not url:
        return False
    try:
        r = requests.post(
            f"https://api.notion.com/v1/databases/{NOTION_DB_ID}/query",
            headers=NOTION_HEADERS,
            json={"filter": {"property": "链接", "url": {"equals": url}}},
            timeout=15,
        )
        if r.status_code == 200:
            return len(r.json().get("results", [])) > 0
    except Exception:
        pass
    return False


def notion_create_page(job, score_info):
    deadline_str = None
    if job.get("deadline"):
        dl = job["deadline"]
        deadline_str = dl.strftime("%Y-%m-%d") if hasattr(dl, "strftime") else str(dl)

    published_str = None
    if job.get("published"):
        pb = job["published"]
        published_str = pb.strftime("%Y-%m-%d") if hasattr(pb, "strftime") else str(pb)

    reason_text = score_info.get("reason", "")[:1000]

    payload = {
        "parent": {"database_id": NOTION_DB_ID},
        "properties": {
            "岗位名称": {"title": [{"text": {"content": job["title"][:200]}}]},
            "学校": {"rich_text": [{"text": {"content": job.get("employer") or ""}}]},
            "匹配度": {"number": round(score_info.get("total_score", 0) / 100.0, 2)},
            "匹配原因": {"rich_text": [{"text": {"content": reason_text}}]},
            "链接": {"url": job.get("url") or ""},
            "截止日期": {"date": {"start": deadline_str}} if deadline_str else {"date": None},
            "发布时间": {"date": {"start": published_str}} if published_str else {"date": None},
            "创建时间": {"date": {"start": dt.now().strftime("%Y-%m-%d")}},
        }
    }

    try:
        r = requests.post(
            "https://api.notion.com/v1/pages",
            headers=NOTION_HEADERS,
            json=payload,
            timeout=15,
        )
        return r.status_code == 200, r.text[:200]
    except Exception as e:
        return False, str(e)


# ========== MAIN ==========
def log(msg):
    print(msg, flush=True)


def main():
    # Validate required config
    missing = []
    if not NOTION_API_KEY:
        missing.append("NOTION_API_KEY")
    if not NOTION_DB_ID:
        missing.append("NOTION_DB_ID")
    if missing:
        log(f"[ERROR] Missing required config: {', '.join(missing)}")
        log(f"  Set env vars or create {DEFAULT_CONFIG_PATH}")
        return

    log(f"[{dt.now().strftime('%Y-%m-%d %H:%M:%S')}] PhD Cursor Ranker started (PhD full scoring via Cursor)")
    log(f"  Threshold: {SCORE_THRESHOLD}%")

    jobs = get_unread_jobs()
    log(f"  Unread jobs: {len(jobs)}")

    if not jobs:
        log("  Nothing to process.")
        return

    processed_ids = []
    synced = 0
    skipped = 0
    errors = 0

    for i, job in enumerate(jobs):
        jid = job["id"]
        title = job["title"][:60]
        log(f"\n  [{i+1}/{len(jobs)}] [{jid}] {title}...")

        score_info, err = score_job_llm(job)

        if err:
            log(f"     ERROR: {err}")
            errors += 1
            continue

        total = score_info["total_score"]
        rd = score_info["research_direction_score"]
        tf = score_info["theoretical_framework_score"]
        rm = score_info["research_methods_score"]
        log(f"     方向:{rd} | 框架:{tf} | 方法:{rm} | 总分:{total}")

        if total >= SCORE_THRESHOLD:
            if notion_search_existing(job.get("url")):
                log(f"     -> Already in Notion, skipping")
                skipped += 1
            else:
                ok, msg = notion_create_page(job, score_info)
                if ok:
                    log(f"     -> Synced to Notion ✓")
                    synced += 1
                else:
                    log(f"     -> Notion error: {msg[:80]}")
                    errors += 1
        else:
            log(f"     -> Below threshold ({total} < {SCORE_THRESHOLD})")

        processed_ids.append(jid)
        time.sleep(1)

    mark_jobs_read(processed_ids)

    log(f"\n  Summary:")
    log(f"    Total processed: {len(jobs)}")
    log(f"    Synced to Notion: {synced}")
    log(f"    Already existed: {skipped}")
    log(f"    Errors: {errors}")
    log(f"  Done!")


if __name__ == "__main__":
    main()
