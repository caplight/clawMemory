#!/bin/bash
# Conversation Logger Web UI Management Script

export MYSQL_HOST="${MYSQL_HOST:-localhost}"
export MYSQL_PORT="${MYSQL_PORT:-3306}"
export MYSQL_USER="${MYSQL_USER:-root}"
export MYSQL_PASSWORD="${MYSQL_PASSWORD:-root2026pass}"
export MYSQL_DATABASE="${MYSQL_DATABASE:-conversation_logs}"

WEB_PID_FILE="/tmp/conversation_logger_web.pid"
WEB_LOG_FILE="/home/cap/logs/web.log"

start_web() {
    if [ -f "$WEB_PID_FILE" ] && kill -0 $(cat "$WEB_PID_FILE") 2>/dev/null; then
        echo "Web UI is already running (PID: $(cat $WEB_PID_FILE))"
        return 1
    fi
    
    echo "Starting Conversation Logger Web UI..."
    cd /home/cap
    nohup python3 script/conversation_logger_web.py >> "$WEB_LOG_FILE" 2>&1 &
    echo $! > "$WEB_PID_FILE"
    sleep 2
    
    if curl -s http://127.0.0.1:5000/health > /dev/null 2>&1; then
        echo "Web UI started successfully (PID: $(cat $WEB_PID_FILE))"
        echo "Access at: http://127.0.0.1:5000"
    else
        echo "Web UI failed to start. Check logs: $WEB_LOG_FILE"
        rm -f "$WEB_PID_FILE"
        return 1
    fi
}

stop_web() {
    if [ ! -f "$WEB_PID_FILE" ]; then
        echo "Web UI is not running (no PID file)"
        return 1
    fi
    
    PID=$(cat "$WEB_PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "Stopping Web UI (PID: $PID)..."
        kill "$PID"
        rm -f "$WEB_PID_FILE"
        echo "Web UI stopped"
    else
        echo "Web UI is not running (stale PID file)"
        rm -f "$WEB_PID_FILE"
    fi
}

status_web() {
    if [ -f "$WEB_PID_FILE" ] && kill -0 $(cat "$WEB_PID_FILE") 2>/dev/null; then
        PID=$(cat "$WEB_PID_FILE")
        echo "Web UI is running (PID: $PID)"
        curl -s http://127.0.0.1:5000/health
    else
        echo "Web UI is not running"
    fi
}

logs_web() {
    tail -50 "$WEB_LOG_FILE"
}

case "$1" in
    start)
        start_web
        ;;
    stop)
        stop_web
        ;;
    restart)
        stop_web
        sleep 1
        start_web
        ;;
    status)
        status_web
        ;;
    logs)
        logs_web
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status|logs}"
        exit 1
        ;;
esac
