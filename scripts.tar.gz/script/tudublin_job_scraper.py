#!/usr/bin/env python3
"""Technological University Dublin job scraper"""

import os
import re
import time
from datetime import datetime

import requests
from bs4 import BeautifulSoup
import pymysql

DB_CONFIG = {
    'host': os.environ.get('MYSQL_HOST', 'localhost'),
    'user': os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', ''),
    'database': os.environ.get('MYSQL_DATABASE', 'phd_jobs')
}

KEYWORDS = [
    'ai', 'machine learning', 'deep learning', 'agent', 'computer science', 'edge',
    'iot', 'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
    'embedded', 'neural', 'foundation model', 'generative ai', 'causal',
    'explainable ai', 'software', 'data science', 'quantum', 'robot', 'cognitive'
]

SOURCE = 'tudublin.ie'
HEADERS = {'User-Agent': 'Mozilla/5.0 (compatible; PhDJobScraper/1.0)'}

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def save_job(title, url, employer, published, deadline, full_text):
    conn = None
    try:
        conn = pymysql.connect(**DB_CONFIG, autocommit=True)
        cursor = conn.cursor()
        if len(full_text) > 3000:
            full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
        cursor.execute(
            "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (title, SOURCE, url, employer, published, deadline, full_text)
        )
        cursor.close()
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def matches_keywords(text):
    if not text:
        return False
    return any(kw.lower() in text.lower() for kw in KEYWORDS)

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def parse_date(s):
    if not s:
        return None
    for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%B %d, %Y', '%d-%b-%Y']:
        try:
            return datetime.strptime(s.strip(), fmt).date()
        except:
            pass
    return None

def scrape():
    found = 0
    saved = 0
    
    base_url = 'https://www.tudublin.ie/research/ VACANCIES/'
    try:
        resp = requests.get(base_url, headers=HEADERS, timeout=15)
        print(f"[TU Dublin] {base_url} -> {resp.status_code}")
        
        soup = BeautifulSoup(resp.text, 'html.parser')
        job_links = []
        
        for a in soup.find_all('a', href=True):
            href = a['href']
            if any(k in href.lower() for k in ['vacancy', 'job', 'position', 'role', 'phd']):
                if href.startswith('http'):
                    job_links.append(href)
                elif href.startswith('/'):
                    job_links.append('https://www.tudublin.ie' + href)
        
        job_links = list(set(job_links))
        print(f"[TU Dublin] Found {len(job_links)} potential job links")
        
        for url in job_links:
            try:
                time.sleep(0.3)
                jresp = requests.get(url, headers=HEADERS, timeout=15)
                if jresp.status_code == 429:
                    retry_after = jresp.headers.get("Retry-After", "60")
                    print(f"  [WARN] Rate limited, waiting {retry_after}s...")
                    time.sleep(int(retry_after))
                    continue
                if jresp.status_code != 200:
                    continue
                
                jsoup = BeautifulSoup(jresp.text, 'html.parser')
                title_tag = jsoup.find('h1') or jsoup.find('title')
                title = title_tag.get_text(strip=True) if title_tag else ''
                
                text_content = jsoup.get_text()
                if not matches_keywords(title + ' ' + text_content) or is_postdoc(title):
                    continue
                
                found += 1
                employer = 'Technological University Dublin'
                published = None
                deadline = None
                
                for pat in [r'Closing\s*Date[:\s]*([\d\-\/\w\s]+)', r'Deadline[:\s]*([\d\-\/\w\s]+)']:
                    m = re.search(pat, text_content, re.IGNORECASE)
                    if m and not deadline:
                        deadline = parse_date(m.group(1))
                
                if save_job(title, url, employer, published, deadline, text_content):
                    saved += 1
                    print(f"  [TU Dublin] Saved: {title[:60]}")
                
            except Exception as e:
                print(f"  [TU Dublin] Error: {e}")
                
    except Exception as e:
        print(f"[TU Dublin] Error with {base_url}: {e}")
    
    print(f"[TU Dublin] Done. Found {found}, saved {saved}")
    return found, saved

if __name__ == '__main__':
    scrape()
