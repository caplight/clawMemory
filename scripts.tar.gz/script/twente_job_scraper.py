#!/usr/bin/env python3
"""University of Twente PhD Job Scraper"""

import os
import re
import time

import requests
from bs4 import BeautifulSoup
import pymysql

SOURCE = 'utwente.nl'
LIST_URL = 'https://utwentecareers.nl/en/vacancies/?type=WP&page=1&category=PR'

KEYWORDS = ['ai', 'machine learning', 'deep learning', 'agent', 'computer science', 'edge',
            'iot', 'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
            'embedded', 'neural', 'foundation model', 'generative ai', 'causal',
            'explainable ai', 'software', 'data science', 'quantum', 'robot', 'cognitive']

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def save_job(title, url, employer, published=None, deadline=None, full_text=""):
    conn = None
    try:
        conn = pymysql.connect(
            host=os.environ.get('MYSQL_HOST', 'localhost'),
            user=os.environ.get('MYSQL_USER', 'root'),
            password=os.environ.get('MYSQL_PASSWORD', ''),
            database=os.environ.get('MYSQL_DATABASE', 'phd_jobs'),
            autocommit=True
        )
        with conn.cursor() as cur:
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            cur.execute(
                "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                (title, SOURCE, url, employer, published, deadline, full_text)
            )
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def title_matches_keywords(title):
    t = title.lower()
    return any(kw in t for kw in KEYWORDS)

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def scrape():
    print(f"Scraping Twente...")
    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'}
    
    jobs_found = 0
    jobs_saved = 0
    job_urls = set()
    
    try:
        resp = requests.get(LIST_URL, headers=headers, timeout=15)
        if resp.status_code == 429:
            retry_after = resp.headers.get("Retry-After", "60")
            print(f"  [WARN] Rate limited, waiting {retry_after}s...")
            time.sleep(int(retry_after))
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        BAD_PATTERNS = ['/student-jobs/', '/ut-as-employer/', '/job-alert/', 'twitter.com',
                        '/en/vacancies/?', '/en/vacancies$']
        for a in soup.find_all('a', href=True):
            href = a.get('href', '')
            if any(bad in href.lower() for bad in BAD_PATTERNS):
                continue
            # Only accept URLs with numeric ID (actual job postings)
            has_numeric = bool(re.search(r'/\d{3,}/', href)) or bool(re.search(r'-\d{6,}/', href))
            if has_numeric:
                if href.startswith('/'):
                    job_urls.add('https://utwentecareers.nl' + href)
                elif href.startswith('http'):
                    job_urls.add(href)
        
        print(f"  Found {len(job_urls)} job URLs")
        
        for url in job_urls:
            time.sleep(0.3)
            
            try:
                detail_resp = requests.get(url, headers=headers, timeout=15)
                if detail_resp.status_code == 429:
                    retry_after = detail_resp.headers.get("Retry-After", "60")
                    print(f"  [WARN] Rate limited, waiting {retry_after}s...")
                    time.sleep(int(retry_after))
                    continue
                detail_resp.raise_for_status()
                detail_soup = BeautifulSoup(detail_resp.text, 'html.parser')
                
                title_tag = detail_soup.find(['h1', 'h2']) or detail_soup.find('title')
                title = title_tag.get_text(strip=True) if title_tag else 'Unknown'
                
                if is_postdoc(title):
                    print(f"  SKIP (postdoc): {title[:60]}")
                    continue
                
                if not title_matches_keywords(title):
                    print(f"  SKIP (no keyword): {title[:60]}")
                    continue
                
                jobs_found += 1
                
                employer = 'University of Twente'
                published = None
                deadline = None
                
                date_pattern = re.compile(r'\d{1,2}[-/]\d{1,2}[-/]\d{2,4}')
                all_text = detail_soup.get_text()
                dates = date_pattern.findall(all_text)
                if dates:
                    deadline = dates[-1] if len(dates) > 1 else dates[0]
                
                full_text = detail_soup.get_text(separator=' ', strip=True)
                if len(full_text) > 3000:
                    full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
                
                if save_job(title, url, employer, published, deadline, full_text):
                    jobs_saved += 1
                    print(f"  SAVED: {title[:60]}")
                else:
                    print(f"  FAILED: {title[:60]}")
                    
            except Exception as e:
                print(f"  Error fetching {url}: {e}")
                
    except Exception as e:
        print(f"  Error on list page: {e}")
    
    print(f"  => Total found: {jobs_found}, Saved: {jobs_saved}")
    return jobs_found, jobs_saved

if __name__ == '__main__':
    scrape()
