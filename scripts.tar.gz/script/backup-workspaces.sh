#!/bin/bash
#
# Backup workspaces + script folder to GitHub clawMemory repository
#
# Strategy (since git push over SOCKS5 proxy hangs for large pack data):
#   - Build backup files locally (tar.gz)
#   - Push commits via GitHub REST API (blobs → tree → commit → ref)
#   - Large files also uploaded to GitHub Releases as backup
#
set -e

export HOME=/root
BACKUP_DIR="/home/cap/backup"
WORKSPACE_DIR="/root/.openclaw"
GITHUB_TOKEN="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"
REPO="caplight/clawMemory"
FEISHU_WEBHOOK="https://open.feishu.cn/open-apis/bot/v2/hook/8833b911-2c46-456c-bf32-89beba681352"

send_feishu() {
    curl -s -X POST "$FEISHU_WEBHOOK" \
        -H "Content-Type: application/json" \
        -d "{\"msg_type\":\"text\",\"content\":{\"text\":\"$1\"}}" > /dev/null 2>&1
}

cd "$BACKUP_DIR"

echo "[$(date)] Building backup archives..."

# Tar workspace-main (exclude browser cache, Cursor, big media, generated PDFs, ~)
tar --exclude='.git' \
    --exclude='workspace/.git' \
    --exclude='workspace/.pinchtab' \
    --exclude='workspace/~' \
    --exclude='workspace/~/.*' \
    --exclude='**/*.png' \
    --exclude='**/*.jpg' \
    --exclude='**/*.jpeg' \
    --exclude='**/*.pdf' \
    --exclude='**/*.mp4' \
    --exclude='**/*.mov' \
    --exclude='**/*.webm' \
    --exclude='workspace/phd-application/generated_cvs' \
    -czf workspace-main.tar.gz -C "$WORKSPACE_DIR" workspace/

# Tar workspace-newbot
tar --exclude='.git' \
    --exclude='~' \
    --exclude='~/.*' \
    --exclude='**/*.png' \
    --exclude='**/*.pdf' \
    -czf workspace-newbot.tar.gz -C "$WORKSPACE_DIR" workspace-newbot/

# Tar workspace-wechatbot
tar --exclude='.git' \
    --exclude='~' \
    --exclude='~/.*' \
    --exclude='**/*.png' \
    --exclude='**/*.pdf' \
    -czf workspace-wechatbot.tar.gz -C "$WORKSPACE_DIR" workspace-wechatbot/

# Tar script folder
tar --exclude='.git' \
    --exclude='*.log' \
    --exclude='logs/' \
    --exclude='__pycache__/' \
    --exclude='*.pyc' \
    --exclude='ctrip_flights_hook.log' \
    --exclude='.boc_eur_monitor.log' \
    --exclude='JobTracker/logs' \
    --exclude='JobTracker/__pycache__' \
    -czf scripts.tar.gz -C /home/cap script/

echo "[$(date)] Backup sizes:"
du -sh workspace-main.tar.gz workspace-newbot.tar.gz workspace-wechatbot.tar.gz scripts.tar.gz

# =====================================================
# Push to GitHub via API (bypasses git push proxy issue)
# =====================================================
echo "[$(date)] Pushing to GitHub via API..."
python3 << 'PYEOF'
import os, base64, json, time
os.environ['HTTPS_PROXY'] = 'http://192.168.23.1:7890'
os.environ['HTTP_PROXY'] = 'http://192.168.23.1:7890'
import requests

TOKEN = "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"
HEADERS = {"Authorization": f"token {TOKEN}", "Accept": "application/vnd.github+json"}
BASE = "https://api.github.com/repos/caplight/clawMemory"
BACKUP_DIR = "/home/cap/backup"

# Get current branch SHA (parent for new commit)
time.sleep(2)  # brief pause to reduce race condition
for attempt in range(3):
    r = requests.get(f"{BASE}/git/ref/heads/main", headers=HEADERS)
    current_sha = r.json()["object"]["sha"]
    print(f"Current main: {current_sha}")

    # Get current tree SHA
    r = requests.get(f"{BASE}/git/commits/{current_sha}", headers=HEADERS)
    current_tree_sha = r.json()["tree"]["sha"]

    # Upload blobs and collect SHAs
    files = [
        ("scripts.tar.gz", f"{BACKUP_DIR}/scripts.tar.gz"),
        ("workspace-main.tar.gz", f"{BACKUP_DIR}/workspace-main.tar.gz"),
        ("workspace-newbot.tar.gz", f"{BACKUP_DIR}/workspace-newbot.tar.gz"),
        ("workspace-wechatbot.tar.gz", f"{BACKUP_DIR}/workspace-wechatbot.tar.gz"),
    ]

    blob_shas = {}
    for fname, fpath in files:
        with open(fpath, "rb") as f:
            encoded = base64.b64encode(f.read()).decode()
        r = requests.post(f"{BASE}/git/blobs", headers=HEADERS, json={"content": encoded, "encoding": "base64"})
        if r.status_code == 201:
            blob_shas[fname] = r.json()["sha"]
            print(f"  Blob {fname}: {r.json()['sha'][:12]}")
        else:
            print(f"  FAILED {fname}: {r.status_code}")
            blob_shas = None
            break

    if blob_shas is None:
        continue

    # Create tree with all files (using current tree as base)
    tree_entries = [{"path": f, "mode": "100644", "type": "blob", "sha": sha} for f, sha in blob_shas.items()]
    tree_data = {"base_tree": current_tree_sha, "tree": tree_entries}
    r = requests.post(f"{BASE}/git/trees", headers=HEADERS, json=tree_data)
    if r.status_code != 201:
        print(f"FAILED to create tree: {r.text}")
        blob_shas = None
        continue
    new_tree_sha = r.json()["sha"]
    print(f"New tree: {new_tree_sha}")

    # Create commit
    ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    payload = {
        "message": f"Backup workspaces + scripts - {time.strftime('%Y-%m-%d')}",
        "tree": new_tree_sha,
        "parents": [current_sha],
        "author": {"name": "煤煤", "email": "meizhu@openclaw.ai", "date": ts},
        "committer": {"name": "煤煤", "email": "meizhu@openclaw.ai", "date": ts}
    }
    r = requests.post(f"{BASE}/git/commits", headers=HEADERS, json=payload)
    if r.status_code != 201:
        print(f"FAILED to create commit: {r.text}")
        blob_shas = None
        continue
    new_commit_sha = r.json()["sha"]
    print(f"New commit: {new_commit_sha}")

    # Update branch ref
    r = requests.patch(f"{BASE}/git/refs/heads/main", headers=HEADERS, json={"sha": new_commit_sha})
    if r.status_code == 200:
        print(f"✅ GitHub push successful!")
        print(f"   https://github.com/caplight/clawMemory/commit/{new_commit_sha}")
        break
    else:
        err_msg = r.text
        print(f"FAILED to update ref (attempt {attempt+1}/3): {err_msg}")
        if "not a fast forward" in err_msg:
            print("Race detected, retrying with fresh SHA...")
            time.sleep(3)
            continue
        exit(1)
else:
    print("All 3 attempts failed")
    exit(1)
PYEOF

echo "[$(date)] Backup completed"
send_feishu "✅ GitHub 备份完成 ($(date '+%H:%M')) - scripts: 2.1MB, main: 148KB, newbot: 344KB"
