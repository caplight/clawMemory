#!/bin/bash
#
# Backup workspaces + script folder to GitHub
# Run daily at 9 PM
#
# Strategy:
#   - Small files (scripts, skills configs) → git commit + push (tiny, <1MB)
#   - Large workspace tar.gz files → GitHub Releases via PyGithub API
#
# Exclusion strategy for workspace tar.gz:
#   - Exclude: .git, .pinchtab, Cursor/Cursor Agent, ~ (root home), 
#              *.png, *.pdf, *.jpg, *.mp4, *.mov, generated_cvs
#   - Keep: scripts, skills, workspace configs, phd-application sources

set -e

export HOME=/root

BACKUP_DIR="/home/cap/backup"
WORKSPACE_DIR="/root/.openclaw"
GITHUB_TOKEN="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"
REPO="https://github.com/caplight/clawMemory.git"
FEISHU_WEBHOOK="https://open.feishu.cn/open-apis/bot/v2/hook/8833b911-2c46-456c-bf32-89beba681352"
COMMIT_MSG="Backup workspaces + scripts - $(date +%Y-%m-%d)"

send_feishu() {
    local message="$1"
    curl -s -X POST "$FEISHU_WEBHOOK" \
        -H "Content-Type: application/json" \
        -d "{\"msg_type\":\"text\",\"content\":{\"text\":\"$message\"}}" > /dev/null 2>&1
}

cd "$BACKUP_DIR"

# Tar workspace-main (exclude browser cache, Cursor, big media, generated PDFs)
tar --exclude='.git' \
    --exclude='workspace/.git' \
    --exclude='workspace/.pinchtab' \
    --exclude='workspace/~' \
    --exclude='workspace/~/.*' \
    --exclude='**/*.png' \
    --exclude='**/*.jpg' \
    --exclude='**/*.jpeg' \
    --exclude='**/*.pdf' \
    --exclude='**/*.mp4' \
    --exclude='**/*.mov' \
    --exclude='**/*.webm' \
    --exclude='workspace/phd-application/generated_cvs' \
    -czf workspace-main.tar.gz -C "$WORKSPACE_DIR" workspace/

# Tar workspace-newbot
tar --exclude='.git' \
    --exclude='~' \
    --exclude='~/.*' \
    --exclude='**/*.png' \
    --exclude='**/*.pdf' \
    --exclude='**/*.jpg' \
    -czf workspace-newbot.tar.gz -C "$WORKSPACE_DIR" workspace-newbot/

# Tar workspace-wechatbot
tar --exclude='.git' \
    --exclude='~' \
    --exclude='~/.*' \
    --exclude='**/*.png' \
    --exclude='**/*.pdf' \
    -czf workspace-wechatbot.tar.gz -C "$WORKSPACE_DIR" workspace-wechatbot/

# Tar entire script folder (exclude logs and temp files)
tar --exclude='.git' \
    --exclude='*.log' \
    --exclude='logs/' \
    --exclude='__pycache__/' \
    --exclude='*.pyc' \
    --exclude='ctrip_flights_hook.log' \
    --exclude='.boc_eur_monitor.log' \
    --exclude='JobTracker/logs' \
    --exclude='JobTracker/__pycache__' \
    -czf scripts.tar.gz -C /home/cap script/

# Show sizes
echo "[$(date)] Backup sizes:"
du -sh workspace-main.tar.gz workspace-newbot.tar.gz workspace-wechatbot.tar.gz scripts.tar.gz

# =====================================================
# Step 1: git push (small files only)
# =====================================================
git add workspace-main.tar.gz workspace-newbot.tar.gz workspace-wechatbot.tar.gz scripts.tar.gz
git commit -m "$COMMIT_MSG"

# Set up auth for git push
git remote set-url origin "$REPO"
git config --local credential.helper "store --file $BACKUP_DIR/.git-credentials"
echo "https://caplight:${GITHUB_TOKEN}@github.com" > "$BACKUP_DIR/.git-credentials"
git config --local http.https://github.com.proxy http://192.168.23.1:7890
git config --local http.version HTTP/1.1

# Push to git
echo "[$(date)] Pushing to git..."
if git push -u --force origin main; then
    echo "[$(date)] Git push successful"
else
    echo "[$(date)] Git push failed (continuing to release upload)"
fi

# =====================================================
# Step 2: GitHub Releases (large files via API)
# =====================================================
echo "[$(date)] Uploading to GitHub Releases..."
python3 /home/cap/script/upload_release.py

echo "[$(date)] Backup completed"
send_feishu "✅ GitHub 备份完成 ($(date '+%H:%M')) - $(du -sh workspace-main.tar.gz workspace-newbot.tar.gz scripts.tar.gz | awk '{print $1}' | tr '\n' ' ')"
