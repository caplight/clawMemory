#!/usr/bin/env python3
"""
TU Delft PhD Job Scraper
Searches TU Delft career portal for relevant positions and saves to MySQL.
"""

import os
import re
import time
import json
from datetime import datetime

import requests
from bs4 import BeautifulSoup
import pymysql

# ========== CONFIG ==========
BASE_URL = "https://careers.tudelft.nl/go/Vacatures/9020902/"
KEYWORDS = [
    "AI", "machine learning", "deep learning", "computer science",
    "agent", "edge", "IoT", "orchestrator", "orchestration",
    "autonomous", "distributed systems", "embedded"
]

# MySQL config (credentials from environment variables)
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "phd_user"),
    "password": os.environ.get("MYSQL_PASSWORD", ""),
    "database": os.environ.get("MYSQL_DATABASE", "phd_jobs"),
    "charset": "utf8mb4",
}

# Compile regex once at module level
POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def is_postdoc(title):
    """Return True if title contains 'postdoc' (case-insensitive)."""
    return bool(POSTDOC_RE.search(title))


def get_db_connection():
    return pymysql.connect(**MYSQL_CONFIG, autocommit=True)


def save_job_to_db(job):
    """Insert job into MySQL. If title+source already exists, skip silently."""
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            sql = """
                INSERT INTO jobs (title, source, url, employer, published, deadline, full_text)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            deadline = job.get("deadline") or None
            if deadline == "":
                deadline = None

            cur.execute(sql, (
                job["title"],
                "tudelft.nl",
                job.get("url", ""),
                job.get("employer", ""),
                None,  # published - leave as NULL
                deadline,
                job.get("full_text", ""),
            ))
        return True
    except Exception as e:
        print(f"    [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()


# ========== WEB SCRAPING ==========
def fetch_page(url, params=None):
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,nl;q=0.8",
    }
    for attempt in range(3):
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=30)
            if resp.status_code == 200:
                return resp.text
            elif resp.status_code == 429:
                # Rate limited - respect Retry-After header if present
                retry_after = resp.headers.get("Retry-After", "60")
                print(f"  [WARN] Rate limited (429). Waiting {retry_after}s...")
                time.sleep(int(retry_after))
                continue
            time.sleep(3)
        except Exception as e:
            print(f"  Attempt {attempt+1} failed: {e}")
            time.sleep(3)
    return None


def parse_deadline(date_str):
    """Convert date string like '10 Apr 2026' to MySQL DATE format 'YYYY-MM-DD'."""
    if not date_str:
        return None
    date_str = date_str.strip()
    for fmt in ("%d %b %Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(date_str, fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            pass
    return None


def parse_listing_page(html):
    """Parse the job listing page and return list of job dicts."""
    soup = BeautifulSoup(html, "html.parser")
    jobs = []

    # Jobs are in <tr class="data-row"> elements
    for row in soup.find_all("tr", class_="data-row"):
        try:
            # Title: first jobTitle-link in the row
            title_link = row.find("a", class_="jobTitle-link")
            if not title_link:
                continue
            title = title_link.get_text(strip=True)
            href = title_link.get("href", "")
            if not href.startswith("http"):
                href = "https://careers.tudelft.nl" + href

            # Faculty (employer) - column "colFacility"
            facility_cell = row.find("td", class_="colFacility")
            employer = ""
            if facility_cell:
                fac_span = facility_cell.find("span", class_="jobFacility")
                employer = fac_span.get_text(strip=True) if fac_span else facility_cell.get_text(strip=True)

            # Hours per week - column "colDepartment"
            hours = ""
            hours_cell = row.find("td", class_="colDepartment")
            if hours_cell:
                hours = hours_cell.get_text(strip=True)

            # Deadline - column "colShifttype"
            deadline_raw = ""
            deadline_cell = row.find("td", class_="colShifttype")
            if deadline_cell:
                deadline_raw = deadline_cell.get_text(strip=True)

            deadline = parse_deadline(deadline_raw)

            if title and href:
                jobs.append({
                    "title": title,
                    "url": href,
                    "employer": employer,
                    "hours": hours,
                    "deadline": deadline,
                    "deadline_raw": deadline_raw,
                })
        except Exception as e:
            print(f"    [PARSE WARN] Failed to parse row: {e}")
            continue

    return jobs


def parse_total_count(html):
    """Extract total number of results from pagination info."""
    soup = BeautifulSoup(html, "html.parser")
    pagination_label = soup.find("span", class_="paginationLabel")
    if pagination_label:
        text = pagination_label.get_text(strip=True)
        match = re.search(r"van(\d+)", text)
        if match:
            return int(match.group(1))
    return None


def parse_detail_page(html):
    """Extract full text description from job detail page. Returns cleaned text."""
    soup = BeautifulSoup(html, "html.parser")
    text = soup.get_text(separator=" ", strip=True)
    text = re.sub(r"\s+", " ", text)
    # Truncate at word boundary, max 3000 chars
    if len(text) > 3000:
        text = text[:3000].rsplit(" ", 1)[0] + "..."
    return text


# ========== MAIN ==========
def main():
    print("=" * 60)
    print("TU Delft PhD Job Scraper")
    print("=" * 60)

    # Collect all seen job URLs to deduplicate across keyword searches
    seen_urls = set()

    total_found = 0
    total_saved = 0
    total_errors = 0

    all_jobs = []

    print(f"\nSearching with {len(KEYWORDS)} keywords...")

    for keyword in KEYWORDS:
        print(f"\n{'='*60}")
        print(f"Keyword: '{keyword}'")
        print(f"{'='*60}")

        # Fetch first page to get total count
        first_url = f"{BASE_URL}?q={requests.utils.quote(keyword)}&sortColumn=referencedate&sortDirection=desc"
        html = fetch_page(first_url)
        if not html:
            print(f"  [ERROR] Failed to fetch page for keyword '{keyword}'")
            total_errors += 1
            continue

        jobs_on_page = parse_listing_page(html)
        total_count = parse_total_count(html)
        print(f"  Found ~{total_count} total results, {len(jobs_on_page)} on first page")

        all_jobs_for_kw = list(jobs_on_page)

        # Fetch remaining pages (20 per page)
        if total_count and total_count > 20:
            num_pages = (total_count + 19) // 20
            for page_num in range(1, num_pages):
                offset = page_num * 20
                page_url = f"{BASE_URL}{offset}/?q={requests.utils.quote(keyword)}&sortColumn=referencedate&sortDirection=desc"
                page_html = fetch_page(page_url)
                if page_html:
                    page_jobs = parse_listing_page(page_html)
                    all_jobs_for_kw.extend(page_jobs)
                    print(f"  Page {page_num+1}/{num_pages}: {len(page_jobs)} jobs")
                    time.sleep(1)
                else:
                    print(f"  [WARN] Failed to fetch page {page_num+1}")
                    time.sleep(3)

        print(f"  Total jobs for '{keyword}': {len(all_jobs_for_kw)}")

        # Deduplicate by URL within this keyword
        new_jobs = [j for j in all_jobs_for_kw if j["url"] not in seen_urls]
        print(f"  New (not seen before): {len(new_jobs)}")

        all_jobs.extend(new_jobs)
        for j in new_jobs:
            seen_urls.add(j["url"])

        total_found += len(all_jobs_for_kw)

    print(f"\n{'='*60}")
    print(f"All keywords done. Total unique new jobs to process: {len(all_jobs)}")
    print(f"{'='*60}")

    # Fetch details and save to DB
    print(f"\nFetching details and saving to DB...")
    for i, job in enumerate(all_jobs):
        print(f"\n  [{i+1}/{len(all_jobs)}] {job['title'][:60]}...")
        detail_html = fetch_page(job["url"])
        if detail_html:
            job["full_text"] = parse_detail_page(detail_html)
        else:
            job["full_text"] = ""
            print(f"    [WARN] Could not fetch detail page")

        if is_postdoc(job["title"]):
            print(f"    [SKIP] Postdoc position")
            continue
        saved = save_job_to_db(job)
        if saved:
            total_saved += 1
            print(f"    [OK] saved | {job['employer']} | deadline: {job['deadline']}")
        else:
            total_errors += 1
            print(f"    [ERROR] DB save failed")

        time.sleep(0.5)

    # Summary
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    print(f"  Keywords searched: {len(KEYWORDS)}")
    print(f"  Total jobs found across all searches: {total_found}")
    print(f"  Unique new jobs saved to DB: {total_saved}")
    print(f"  Total errors: {total_errors}")

    # Print JSON for reference
    print(f"\n{'='*60}")
    print("JSON OUTPUT (all scraped jobs):")
    print(f"{'='*60}")
    print(json.dumps(all_jobs, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
