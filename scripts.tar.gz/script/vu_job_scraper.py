#!/usr/bin/env python3
"""VU Amsterdam PhD Job Scraper"""

import os
import re
import time

import requests
from bs4 import BeautifulSoup
import pymysql

SOURCE = 'vu.nl'
BASE_URL = 'https://workingat.vu.nl'
LIST_URL = BASE_URL + '/vacancies?type=phd'
HEADERS = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'}

KEYWORDS = ['ai','machine learning','deep learning','agent','computer science','edge','iot','orchestrator','autonomous','distributed','embedded','neural','foundation model','generative ai','causal','explainable ai','software','data science','quantum','robot','cognitive']
POSTDOC_RE = re.compile(r'\bpostdoc\b', re.I)

def is_postdoc(title): return bool(POSTDOC_RE.search(title))
def title_matches(title):
    t = title.lower()
    return any(kw.lower() in t for kw in KEYWORDS)

def save_job(title, url, employer, published=None, deadline=None, full_text=""):
    conn = None
    try:
        conn = pymysql.connect(
            host=os.environ.get('MYSQL_HOST', 'localhost'),
            user=os.environ.get('MYSQL_USER', 'root'),
            password=os.environ.get('MYSQL_PASSWORD', ''),
            database=os.environ.get('MYSQL_DATABASE', 'phd_jobs'),
            autocommit=True
        )
        with conn.cursor() as cur:
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            cur.execute(
                "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                (title, SOURCE, url, employer, published, deadline, full_text)
            )
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def scrape():
    print(f"Scraping VU Amsterdam...")
    try:
        r = requests.get(LIST_URL, headers=HEADERS, timeout=15)
        if r.status_code == 429:
            retry_after = r.headers.get("Retry-After", "60")
            print(f"  [WARN] Rate limited, waiting {retry_after}s...")
            time.sleep(int(retry_after))
        r.raise_for_status()
        soup = BeautifulSoup(r.text, 'html.parser')

        job_links = {}
        for a in soup.find_all('a'):
            href = a.get('href', '')
            t = a.get_text(strip=True)
            if not href or not t or len(t) < 15: continue
            # Only match actual job links under /vacancies/
            if '/vacancies/' in href:
                full_url = href if href.startswith('http') else BASE_URL + href
                job_links[full_url] = t

        print(f"  Found {len(job_links)} job links")
        
        saved = 0
        for url, title in job_links.items():
            print(f"  Processing: {title[:60]}...")
            time.sleep(0.3)
            try:
                dr = requests.get(url, headers=HEADERS, timeout=15)
                dr.raise_for_status()
                dsoup = BeautifulSoup(dr.text, 'html.parser')
                if is_postdoc(title) or not title_matches(title):
                    print(f"    SKIP")
                    continue
                employer = 'VU Amsterdam'
                published = None
                deadline = None
                full_text = dsoup.get_text(separator=' ', strip=True)
                if len(full_text) > 3000:
                    full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
                if save_job(title, url, employer, published, deadline, full_text):
                    saved += 1
                    print(f"    SAVED")
            except Exception as e:
                print(f"    ERROR: {e}")
        print(f"  Total saved: {saved}")
    except Exception as e:
        print(f"  Error: {e}")

if __name__ == '__main__':
    scrape()
