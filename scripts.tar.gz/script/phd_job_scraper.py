#!/usr/bin/env python3
"""
AcademicTransfer PhD Job Scraper
只负责爬取数据，不做评分
"""

import os
import re
import time
import json

import requests
from bs4 import BeautifulSoup
import pymysql

# ========== CONFIG ==========
SEARCH_URL = "https://www.academictransfer.com/en/jobs/"
SEARCH_PARAMS = {
    "q": "Computer science",
    "function_types": "1",
    "scientific_fields": "3",
    "vacature_type": "scientific",
    "order": "published"
}

# MySQL config (from environment variables)
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "phd_user"),
    "password": os.environ.get("MYSQL_PASSWORD", ""),
    "database": os.environ.get("MYSQL_DATABASE", "phd_jobs"),
    "charset": "utf8mb4",
}

def get_db_connection():
    return pymysql.connect(**MYSQL_CONFIG, autocommit=True)

def save_job_to_db(job):
    """Insert job into MySQL. If title+source already exists, skip silently."""
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            sql = """
                INSERT INTO jobs (title, source, url, employer, published, deadline, full_text)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            published = job.get("published") or None
            deadline = job.get("deadline") or None
            if published == "":
                published = None
            if deadline == "":
                deadline = None

            # Truncate full_text at word boundary, max 3000 chars
            full_text = job.get("full_text", "") or ""
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."

            cur.execute(sql, (
                job["title"],
                "academictransfer",
                job.get("url", ""),
                job.get("employer", ""),
                published,
                deadline,
                full_text,
            ))
        return True
    except Exception as e:
        print(f"    [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

# ========== WEB SCRAPING ==========
def fetch_page(url, params=None):
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    for attempt in range(3):
        try:
            resp = requests.get(url, params=params, headers=headers, timeout=30)
            if resp.status_code == 200:
                return resp.text
            elif resp.status_code == 429:
                retry_after = resp.headers.get("Retry-After", "60")
                print(f"  [WARN] Rate limited (429). Waiting {retry_after}s...")
                time.sleep(int(retry_after))
                continue
            time.sleep(3)
        except Exception as e:
            print(f"  Attempt {attempt+1} failed: {e}")
            time.sleep(3)
    return None

def parse_job_list(html):
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    for article in soup.find_all("article"):
        try:
            link = article.find("a")
            if not link:
                continue
            href = link.get("href", "")
            if not href.startswith("http"):
                href = "https://www.academictransfer.com" + href
            
            heading = article.find(["h2", "h3"])
            title = heading.get_text(strip=True) if heading else ""
            
            emp_img = article.find("img")
            employer = emp_img.get("alt", "Unknown") if emp_img else "Unknown"
            
            deadline, published = "", ""
            for time_tag in article.find_all("time"):
                parent = time_tag.find_parent()
                if parent:
                    text = parent.get_text()
                    if "Deadline" in text:
                        deadline = time_tag.get("datetime", "")
                    elif "Published" in text:
                        published = time_tag.get("datetime", "")
            
            if title and href:
                jobs.append({
                    "title": title,
                    "url": href,
                    "employer": employer,
                    "published": published,
                    "deadline": deadline
                })
        except Exception as e:
            print(f"    [PARSE WARN] Failed to parse article: {e}")
            continue
    return jobs

def parse_job_detail(html):
    soup = BeautifulSoup(html, "html.parser")
    text = soup.get_text(separator=" ", strip=True)
    text = re.sub(r'\s+', ' ', text)
    # Truncate at word boundary
    if len(text) > 3000:
        text = text[:3000].rsplit(" ", 1)[0] + "..."
    return text

# ========== MAIN ==========
def main():
    print("=" * 60)
    print("AcademicTransfer PhD Job Scraper")
    print("=" * 60)
    
    print("\n[1/2] Fetching job listings...")
    html = fetch_page(SEARCH_URL, SEARCH_PARAMS)
    if not html:
        print("Failed to fetch listings")
        return
    
    jobs = parse_job_list(html)
    print(f"Found {len(jobs)} jobs")
    
    print("\n[2/2] Fetching job details...")
    for i, job in enumerate(jobs):
        print(f"\n  [{i+1}/{len(jobs)}] {job['title'][:60]}...")
        detail_html = fetch_page(job["url"])
        if detail_html:
            job["full_text"] = parse_job_detail(detail_html)
        else:
            job["full_text"] = ""
            print(f"    [WARN] Could not fetch detail page")

        saved = save_job_to_db(job)
        db_status = "✓ saved" if saved else "✗ db error"
        print(f"    {db_status} | {job['employer']} | {job['published']} | {job['deadline']}")
        time.sleep(1)
    
    print("\n" + "=" * 60)
    print("JSON OUTPUT:")
    print("=" * 60)
    print(json.dumps(jobs, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
