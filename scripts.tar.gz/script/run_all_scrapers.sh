#!/bin/bash
# Master Crawler + Ranker Scheduler (Parallel Version)
# All scrapers run in parallel (semaphore-controlled), then ranker, then report

set -e

FEISHU_WEBHOOK="https://open.feishu.cn/open-apis/bot/v2/hook/8833b911-2c46-456c-bf32-89beba681352"
LOG_DIR="/home/cap/logs/scrapers"
PARALLEL_JOBS=8
TODAY=$(date +%Y%m%d)
mkdir -p "$LOG_DIR"

send_feishu() {
    local text="$1"
    local payload
    payload=$(jq -n --arg t "$text" '{"msg_type":"text","content":{"text":$t}}')
    local response
    response=$(curl -s -w "\n%{http_code}" -X POST "$FEISHU_WEBHOOK" \
        -H "Content-Type: application/json" \
        -d "$payload")
    local http_code=$(echo "$response" | tail -1)
    if [ "$http_code" != "200" ]; then
        echo "Feishu webhook error: HTTP $http_code - $(echo "$response" | head -1)"
        return 1
    fi
    return 0
}

SCRAPERS=(
    "tudelf_job_scraper"
    "uva_job_scraper"
    "utrecht_job_scraper"
    "dcu_job_scraper"
    "ucd_job_scraper"
    "ucc_job_scraper"
    "ul_job_scraper"
    "tcd_job_scraper"
    "galway_job_scraper"
    "maynooth_job_scraper"
    "utwente_job_scraper"
    "twente_job_scraper"
    "rug_job_scraper"
    "vu_job_scraper"
    "wageningen_job_scraper"
    "maastricht_job_scraper"
    "eur_job_scraper"
    "erasmus_job_scraper"
    "academictransfer_job_scraper"
)

TOTAL=${#SCRAPERS[@]}
echo "=== Parallel scraper run: $TOTAL scrapers, max $PARALLEL_JOBS concurrent ==="
echo "Started at $(date)"

JOBS_BEFORE=$(mysql -u root -proot2026pass -N -e "SELECT COUNT(*) FROM phd_jobs.jobs" 2>/dev/null || echo "0")

# ---------- Launch all scrapers in parallel with semaphore ----------
declare -a PIDS=()
launch_parallel() {
    local running=0
    local idx=0

    for scraper in "${SCRAPERS[@]}"; do
        idx=$((idx + 1))
        script="/home/cap/script/${scraper}.py"
        log="${LOG_DIR}/${scraper}_${TODAY}.log"

        if [ ! -f "$script" ]; then
            echo "[$idx/$TOTAL] SKIP $scraper (not found)"
            continue
        fi

        while [ $running -ge $PARALLEL_JOBS ]; do
            for i in "${!PIDS[@]}"; do
                if ! kill -0 "${PIDS[$i]}" 2>/dev/null; then
                    unset 'PIDS[$i]'
                    running=$((running - 1))
                fi
            done
            PIDS=("${PIDS[@]}")
            [ $running -ge $PARALLEL_JOBS ] && sleep 2
        done

        (
            MYSQL_HOST="localhost" \
            MYSQL_USER="root" \
            MYSQL_PASSWORD="root2026pass" \
            MYSQL_DATABASE="phd_jobs" \
                python3 "$script" > "$log" 2>&1
            echo "EXIT_CODE:$?" >> "$log"
        ) &
        PIDS+=($!)
        running=$((running + 1))
        echo "[$idx/$TOTAL] Launched $scraper (PID $!, running:$running)"
    done

    echo "All launched. Waiting for ${#PIDS[@]} workers..."
    for pid in "${PIDS[@]}"; do wait $pid 2>/dev/null; done
    echo "All workers done at $(date)"
}

# ---------- Collect results ----------
collect_results() {
    local completed=0 failed=0 total_new=0
    local output=""
    local cutoff
    cutoff=$(date -d "today 00:00" +%s 2>/dev/null || echo 0)

    for scraper in "${SCRAPERS[@]}"; do
        log="${LOG_DIR}/${scraper}_${TODAY}.log"
        [ ! -f "$log" ] && continue

        local file_time
        file_time=$(stat -c %Y "$log" 2>/dev/null || echo 0)
        [ "$file_time" -lt "$cutoff" ] && continue

        local exit_code
        exit_code=$(grep -o 'EXIT_CODE:[0-9]*' "$log" 2>/dev/null | tail -1 | cut -d: -f2 || echo "1")
        [ -z "$exit_code" ] && exit_code=1

        local new_jobs saved_count
        new_jobs=$(grep -oP '\d+(?= saved to DB)' "$log" 2>/dev/null | awk '{s+=$1} END {print s+0}')
        [ -z "$new_jobs" ] && new_jobs=0
        saved_count=$(grep -oP '\d+(?=/\d+ saved to DB)' "$log" 2>/dev/null | tail -1 || echo "0")

        local last_title
        last_title=$(grep ">>" "$log" 2>/dev/null | tail -1 | cut -c3- | cut -c1-60 || echo "")

        if [ "$exit_code" = "0" ]; then
            completed=$((completed + 1))
            total_new=$((total_new + new_jobs + 0))  # +0 prevents exit-1 from ((0+0)) under set -e
            output="${output}OK:${scraper}:${new_jobs}:${last_title}"
        else
            failed=$((failed + 1))
            output="${output}FAIL:${scraper}"
        fi
    done

    local jobs_after
    jobs_after=$(mysql -u root -proot2026pass -N -e "SELECT COUNT(*) FROM phd_jobs.jobs" 2>/dev/null || echo "0")
    local actual_new=$((jobs_after - JOBS_BEFORE))
    echo "RESULT:completed=$completed failed=$failed total_new=$total_new actual_new=$actual_new jobs_after=$jobs_after"
    echo "OUTPUT_START${output}OUTPUT_END"
}

# ---------- Main ----------
launch_parallel

echo ""
echo "=== Collecting results ==="
RESULTS=$(collect_results)
echo "$RESULTS"

completed=$(echo "$RESULTS" | grep "^RESULT:" | sed 's/.*completed=\([0-9]*\).*/\1/')
failed=$(echo "$RESULTS" | grep "^RESULT:" | sed 's/.*failed=\([0-9]*\).*/\1/')
total_new=$(echo "$RESULTS" | grep "^RESULT:" | sed 's/.*total_new=\([0-9]*\).*/\1/')
actual_new=$(echo "$RESULTS" | grep "^RESULT:" | sed 's/.*actual_new=\([0-9]*\).*/\1/')
jobs_after=$(echo "$RESULTS" | grep "^RESULT:" | sed 's/.*jobs_after=\([0-9]*\).*/\1/')
raw_output=$(echo "$RESULTS" | grep "^OUTPUT_START" | sed 's/^OUTPUT_START//;s/OUTPUT_END$//')

echo "Scrapers: completed=$completed failed=$failed new_jobs=$actual_new"

# ---------- Ranker ----------
echo ""
echo "=== Starting PhD Job Ranker at $(date) ==="
RANKER_LOG="${LOG_DIR}/ranker_${TODAY}.log"

export MYSQL_HOST="localhost" MYSQL_USER="root" MYSQL_PASSWORD="root2026pass"
export MYSQL_DATABASE="phd_jobs"
export MINIMAX_API_KEY="sk-cp-fQZxgx_WiWnu46I4AEHhprLAhHEVlr6_7s9vsTrX5Z-1rdhKPzo_8q-KrDdvlv_VhIgmMS3b7OK80MiM-4-f9Ni7PJx-p_98nqJUMRSaUrIpKge8rDTx-RE"
export NOTION_API_KEY="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"
export NOTION_DB_ID="329267b2-de94-8140-a6aa-f2f77cb5b1a2"

python3 /home/cap/script/phd_job_ranker.py > "$RANKER_LOG" 2>&1 || true

ranker_processed=$(mysql -u root -proot2026pass -N -e "SELECT COUNT(*) FROM phd_jobs.jobs WHERE is_read=1" 2>/dev/null || echo "0")
ranker_unread=$(mysql -u root -proot2026pass -N -e "SELECT COUNT(*) FROM phd_jobs.jobs WHERE is_read=0" 2>/dev/null || echo "0")
ranker_synced=$(grep -i "Synced to Notion" "$RANKER_LOG" 2>/dev/null | wc -l || echo "0")
ranker_errors=$(grep -i "ERROR\|Error" "$RANKER_LOG" 2>/dev/null | wc -l || echo "0")

echo "Ranker done: processed=$ranker_processed unread=$ranker_unread synced=$ranker_synced errors=$ranker_errors"

# ---------- Feishu Report ----------
echo ""
echo "=== Sending Feishu report ==="

report_text="📊 PhD 爬虫+评分报告 - $(date '+%H:%M')

🔍 爬虫结果（${TODAY}）：
完成 ${completed}/${TOTAL}，失败 ${failed}
📦 新增岗位：${actual_new} 条（${JOBS_BEFORE} → ${jobs_after}）

🤖 Ranker：
- 已处理：${ranker_processed} 条
- 待处理：${ranker_unread} 条
- 同步Notion：${ranker_synced} 条
- 错误：${ranker_errors} 条

⏰ $(date '+%H:%M:%S')"

send_feishu "$report_text"
echo "Report sent. All done at $(date)."
