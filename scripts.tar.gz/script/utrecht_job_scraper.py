#!/usr/bin/env python3
"""
Utrecht University PhD Job Scraper
Portal: https://www.uu.nl/en/organisation/working-at-utrecht-university/jobs
Searches with keyword filters and saves matching jobs to MySQL.
"""

import os
import re
import time

import requests
from bs4 import BeautifulSoup
import pymysql

BASE_URL = "https://www.uu.nl/en/organisation/working-at-utrecht-university/jobs"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml",
}

MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", ""),
    "database": os.environ.get("MYSQL_DATABASE", "phd_jobs"),
    "charset": "utf8mb4",
}

KEYWORDS = [
    "ai", "machine learning", "deep learning", "agent", "multi-agent",
    "computer science", "edge computing", "iot", "internet of things",
    "orchestrator", "orchestration", "autonomous", "distributed systems",
    "embedded", "neural network", "foundation model", "generative ai",
    "causal", "explainable ai", "xai", "artificial intelligence",
    "data science", "software engineering", "software development",
    "quantum", "robot", "cognitive science", "human-computer",
]

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def get_db():
    return pymysql.connect(**MYSQL_CONFIG, autocommit=True)

def save_job_to_db(job):
    conn = None
    try:
        conn = get_db()
        with conn.cursor() as cur:
            full_text = job.get("full_text", "") or ""
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            sql = """
                INSERT INTO jobs (title, source, url, employer, published, deadline, full_text)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            cur.execute(sql, (
                job["title"],
                "uu.nl",
                job.get("url", ""),
                job.get("employer", ""),
                job.get("published"),
                job.get("deadline"),
                full_text,
            ))
        return True
    except Exception as e:
        print(f"    [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def keyword_matches(text, keywords):
    text_lower = text.lower()
    return any(kw.lower() in text_lower for kw in keywords)

def parse_jobs_list_page(html):
    soup = BeautifulSoup(html, "html.parser")
    jobs = []
    seen = set()
    for a in soup.find_all("a", href=True):
        href = a.get("href", "")
        title = a.get_text(strip=True)
        # Only match actual PhD job links
        if "/jobs/phd" in href and href not in seen and len(title) > 10:
            seen.add(href)
            if href.startswith("/"):
                href = "https://www.uu.nl" + href
            jobs.append({
                "title": title,
                "url": href,
                "employer": "Utrecht University",
            })
    return jobs

def fetch_job_detail(url):
    try:
        r = requests.get(url, headers=HEADERS, timeout=15)
        if r.status_code == 429:
            retry_after = r.headers.get("Retry-After", "60")
            print(f"    [WARN] Rate limited, waiting {retry_after}s...")
            time.sleep(int(retry_after))
            return {}
        if r.status_code != 200:
            return {}
        soup = BeautifulSoup(r.text, "html.parser")
        text = soup.get_text(separator=" ", strip=True)
        text = re.sub(r"\s+", " ", text)
        deadline_match = re.search(r"(?:closes?|deadline|expiry)[:\s]+(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4})", text, re.I)
        deadline = deadline_match.group(1) if deadline_match else None
        return {"full_text": text, "deadline": deadline}
    except Exception as e:
        print(f"    [FETCH ERROR] {e}")
        return {}

def main():
    print("=" * 60)
    print("Utrecht University PhD Job Scraper")
    print("=" * 60)

    all_jobs = []
    
    for kw in ["phd", "ai", "machine learning"]:
        url = f"{BASE_URL}?q={requests.utils.quote(kw)}"
        print(f"\n  Fetching keyword: '{kw}'...")
        try:
            r = requests.get(url, headers=HEADERS, timeout=15)
            print(f"    HTTP {r.status_code}")
            if r.status_code == 200:
                jobs = parse_jobs_list_page(r.text)
                print(f"    Found {len(jobs)} jobs")
                all_jobs.extend(jobs)
            time.sleep(1)
        except Exception as e:
            print(f"    [ERROR] {e}")

    # Deduplicate
    seen = set()
    unique = []
    for j in all_jobs:
        if j["url"] not in seen:
            seen.add(j["url"])
            unique.append(j)
    all_jobs = unique
    print(f"\n  Total unique: {len(all_jobs)}")

    # Filter
    relevant = [j for j in all_jobs if keyword_matches(j["title"], KEYWORDS) and not is_postdoc(j["title"])]
    print(f"  Keyword-matched: {len(relevant)}")

    # Fetch and save
    saved = 0
    for j in relevant:
        print(f"\n  → {j['title'][:60]}...", end=" ", flush=True)
        detail = fetch_job_detail(j["url"])
        j.update(detail)
        if save_job_to_db(j):
            saved += 1
            print("✓")
        else:
            print("✗")
        time.sleep(0.5)

    print(f"\n  Done! Saved {saved}/{len(relevant)} jobs.")

if __name__ == "__main__":
    main()
