#!/usr/bin/env python3
"""
Utrecht University PhD Job Scraper

Uses the PhD vacancies page directly - the main jobs page (uu.nl/en/organisation/working-at-utrecht-university/jobs)
is blocked from this server, but the PhD-specific page works.
"""

import os
import re
import time
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
import pymysql
import warnings
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

SOURCE = 'uu.nl'
BASE_URL = 'https://www.uu.nl/en/organisation/phd-programmes/starting-a-phd-track/phd-vacancies'
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}

MYSQL_CONFIG = {
    'host': os.environ.get('MYSQL_HOST', 'localhost'),
    'user': os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', ''),
    'database': os.environ.get('MYSQL_DATABASE', 'phd_jobs'),
    'charset': 'utf8mb4',
}

KEYWORDS = [
    'ai', 'machine learning', 'deep learning', 'agent', 'multi-agent',
    'computer science', 'edge computing', 'iot', 'internet of things',
    'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
    'embedded', 'neural network', 'foundation model', 'generative ai',
    'causal', 'explainable ai', 'xai', 'artificial intelligence',
    'data science', 'software engineering', 'software development',
    'quantum', 'robot', 'cognitive science', 'human-computer',
]

POSTDOC_RE = re.compile(r'\bpostdoc\b', re.I)
TIMEOUT = 20


def get_db():
    return pymysql.connect(**MYSQL_CONFIG, autocommit=True)


def save_job(title, url, employer, published=None, deadline=None, full_text=''):
    conn = None
    try:
        conn = get_db()
        with conn.cursor() as cur:
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(' ', 1)[0] + '...'
            cur.execute(
                'INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) '
                'VALUES (%s,%s,%s,%s,%s,%s,%s)',
                (title, SOURCE, url, employer, published, deadline, full_text)
            )
        return True
    except Exception as e:
        print(f'  [DB ERROR] {e}')
        return False
    finally:
        if conn:
            conn.close()


def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))


def keyword_matches(text):
    text_lower = text.lower()
    return any(kw.lower() in text_lower for kw in KEYWORDS)


def parse_date(s):
    if not s:
        return None
    for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%B %d, %Y', '%d-%b-%Y']:
        try:
            return time.strftime('%Y-%m-%d', time.strptime(s.strip(), fmt))
        except:
            pass
    return None


def extract_deadline(text):
    patterns = [
        r'Closing\s*Date[:\s]*([\d\w\s,]+?)(?:\n|$)',
        r'Deadline[:\s]*([\d\-\/\w\s]+?)(?:\n|$)',
        r'Apply\s*by[:\s]*([\d\-\/\w\s]+?)(?:\n|$)',
        r'(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4})',
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            d = parse_date(m.group(1).strip())
            if d:
                return d
    return None


def fetch_jobs_from_list_page(html):
    """Parse PhD job links from the PhD vacancies page."""
    soup = BeautifulSoup(html, 'html.parser')
    jobs = []
    seen = set()

    for a in soup.find_all('a', href=True):
        href = a.get('href', '')
        # Match PhD job detail pages
        if '/jobs/phd' in href and href not in seen:
            seen.add(href)
            title = a.get_text(strip=True)
            if title and len(title) > 10:
                if href.startswith('/'):
                    href = 'https://www.uu.nl' + href
                jobs.append({'title': title, 'url': href})
    return jobs


def fetch_job_detail(url):
    """Fetch job detail page and extract full text + deadline."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=TIMEOUT, verify=False)
        if r.status_code != 200:
            return None, None
        soup = BeautifulSoup(r.text, 'html.parser')
        body = soup.find('body')
        text = body.get_text(separator=' ', strip=True) if body else soup.get_text()
        text = re.sub(r'\s+', ' ', text).strip()
        deadline = extract_deadline(text)
        return text, deadline
    except Exception as e:
        print(f'  [FETCH ERROR] {e}')
        return None, None


def main():
    print('=' * 60)
    print('Utrecht University PhD Job Scraper')
    print('=' * 60)
    print(f'  Source: {BASE_URL}')

    all_jobs = []
    print(f'\n  Fetching list page...')
    try:
        r = requests.get(BASE_URL, headers=HEADERS, timeout=TIMEOUT, verify=False)
        print(f'    HTTP {r.status_code}, {len(r.text)} bytes')
        if r.status_code == 200:
            all_jobs = fetch_jobs_from_list_page(r.text)
            print(f'    Found {len(all_jobs)} PhD job links')
    except Exception as e:
        print(f'    [ERROR] {e}')
        return

    # Deduplicate
    seen_urls = set()
    unique_jobs = []
    for j in all_jobs:
        if j['url'] not in seen_urls:
            seen_urls.add(j['url'])
            unique_jobs.append(j)
    all_jobs = unique_jobs
    print(f'  Total unique: {len(all_jobs)}')

    # Filter by keyword and postdoc
    relevant = [j for j in all_jobs if keyword_matches(j['title']) and not is_postdoc(j['title'])]
    print(f'  Keyword-matched (no postdoc): {len(relevant)}')

    saved = 0
    for j in relevant:
        print(f'\n  -> {j["title"][:70]}...', flush=True)
        full_text, deadline = fetch_job_detail(j['url'])
        if full_text:
            print(f'    Fetched {len(full_text)} chars, deadline={deadline}')
            if save_job(j['title'], j['url'], 'Utrecht University', None, deadline, full_text):
                saved += 1
                print(f'    SAVED')
            else:
                print(f'    FAILED')
        else:
            print(f'    Could not fetch detail page')
        time.sleep(1)

    print(f'\n  Done! Saved {saved}/{len(relevant)} jobs.')


if __name__ == '__main__':
    main()
