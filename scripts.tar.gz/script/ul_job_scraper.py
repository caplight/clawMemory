#!/usr/bin/env python3
"""University of Limerick PhD Job Scraper - uses pinchtab for JS-rendered CoreHR pages"""

import os
import re
import subprocess
import time
from datetime import datetime

import requests
from bs4 import BeautifulSoup
import pymysql

DB_CONFIG = {
    'host': os.environ.get('MYSQL_HOST', 'localhost'),
    'user': os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', ''),
    'database': os.environ.get('MYSQL_DATABASE', 'phd_jobs')
}

KEYWORDS = [
    'ai', 'machine learning', 'deep learning', 'agent', 'computer science', 'edge',
    'iot', 'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
    'embedded', 'neural', 'foundation model', 'generative ai', 'causal',
    'explainable ai', 'software', 'data science', 'quantum', 'robot', 'cognitive'
]

SOURCE = 'ul.ie'
HEADERS = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'}

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def fetch_via_pinchtab(url, output_file):
    """Fetch a URL using pinchtab (scrapling stealthy) and save to file."""
    try:
        result = subprocess.run(
            ['scrapling', 'extract', 'stealthy-fetch', url, output_file],
            capture_output=True, text=True, timeout=30
        )
        return result.returncode == 0 and os.path.exists(output_file) and os.path.getsize(output_file) > 1000
    except Exception as e:
        print(f"  [pinchtab] Error: {e}")
        return False

def save_job(title, url, employer, published, deadline, full_text):
    conn = None
    try:
        conn = pymysql.connect(**DB_CONFIG, autocommit=True)
        cursor = conn.cursor()
        if len(full_text) > 3000:
            full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
        cursor.execute(
            "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (title, SOURCE, url, employer, published, deadline, full_text)
        )
        cursor.close()
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def matches_keywords(text):
    if not text:
        return False
    text_lower = text.lower()
    return any(kw.lower() in text_lower for kw in KEYWORDS)

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def parse_date(s):
    if not s:
        return None
    for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%B %d, %Y', '%d-%b-%Y']:
        try:
            return datetime.strptime(s.strip(), fmt).date()
        except:
            pass
    return None

def scrape():
    found = 0
    saved = 0
    
    # UL uses CoreHR system - try pinchtab on the main vacancies page
    base_url = 'https://www.ul.ie/vacancies'
    output_file = '/tmp/ul_pinchtab.html'
    
    print(f"[UL] Fetching {base_url} via pinchtab...")
    
    # Try pinchtab first
    success = fetch_via_pinchtab(base_url, output_file)
    
    if not success:
        print(f"[UL] pinchtab failed, trying direct request...")
        resp = requests.get(base_url, headers=HEADERS, timeout=15, allow_redirects=True)
        print(f"[UL] Direct: {resp.status_code} -> {resp.url}")
        html_content = resp.text
    else:
        with open(output_file) as f:
            html_content = f.read()
        print(f"[UL] Got {len(html_content)} bytes via pinchtab")
    
    soup = BeautifulSoup(html_content, 'html.parser')
    job_links = []
    
    # Find links in the rendered page
    for a in soup.find_all('a', href=True):
        href = a['href']
        t = a.get_text(strip=True)
        if len(t) > 10:
            # Match job vacancy links (CoreHR, /vacancy/, /job/, etc.)
            if any(k in href.lower() for k in ['vacancy', 'job', 'position', 'corehr', 'phd']) or \
               any(k in t.lower() for k in ['phd', 'researcher', 'postdoc', 'research-fellow']):
                if href.startswith('http'):
                    job_links.append(href)
                elif href.startswith('/'):
                    job_links.append('https://www.ul.ie' + href)
    
    job_links = list(set(job_links))
    print(f"[UL] Found {len(job_links)} potential job links")
    
    for url in job_links:
        try:
            time.sleep(0.5)
            jresp = requests.get(url, headers=HEADERS, timeout=15)
            if jresp.status_code != 200:
                continue
            
            jsoup = BeautifulSoup(jresp.text, 'html.parser')
            meta = jsoup.find('meta', attrs={'name': 'og:title'}) or jsoup.find('meta', attrs={'property': 'og:title'})
            if meta:
                title = meta.get('content', '').strip()
            else:
                title_tag = jsoup.find('h1') or jsoup.find('h2') or jsoup.find('title')
                title = title_tag.get_text(strip=True) if title_tag else ''
            
            text_content = jsoup.get_text(separator=' ', strip=True)
            
            if is_postdoc(title):
                continue
            
            # Check keywords against both title AND full text
            if not matches_keywords(title + ' ' + text_content):
                continue
            
            found += 1
            deadline = None
            for pat in [r'Closing\s*Date[:\s]*([\d\-\/\w\s]+)', r'Deadline[:\s]*([\d\-\/\w\s]+)']:
                m = re.search(pat, text_content, re.IGNORECASE)
                if m and not deadline:
                    deadline = parse_date(m.group(1))
            
            if save_job(title, url, 'University of Limerick', None, deadline, text_content):
                saved += 1
                print(f"  SAVED: {title[:60]}")
            else:
                print(f"  SKIPPED/ERROR: {title[:60]}")
                
        except Exception as e:
            print(f"  Error fetching {url}: {e}")
    
    print(f"[UL] Done. Found {found}, saved {saved}")
    return found, saved

if __name__ == '__main__':
    scrape()
