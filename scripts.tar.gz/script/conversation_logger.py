#!/usr/bin/env python3
"""
Conversation Logger for OpenClaw
Watches session transcript JSONL files and logs to MySQL asynchronously.
"""

import os
import sys
import json
import time
import queue
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List

import pymysql
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileModifiedEvent


# ========== CONFIG ==========
MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
MYSQL_PORT = int(os.environ.get("MYSQL_PORT", "3306"))
MYSQL_USER = os.environ.get("MYSQL_USER", "root")
MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.environ.get("MYSQL_DATABASE", "conversation_logs")

SESSION_DIR = Path.home() / ".openclaw" / "agents"
POLL_INTERVAL = 1.0
TRUNCATE_LEN = 10000


# ========== DB ==========
def get_db_connection():
    return pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE,
        charset="utf8mb4",
        autocommit=True,
    )


def init_db():
    """Create table if not exists."""
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS conversation_logs (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    session_key VARCHAR(128) NOT NULL,
                    channel VARCHAR(32) NOT NULL,
                    log_date DATETIME NOT NULL,
                    direction ENUM('inbound', 'outbound', 'system') NOT NULL,
                    message TEXT,
                    message_type VARCHAR(32),
                    role VARCHAR(32),
                    content_blocks JSON,
                    tool_name VARCHAR(128),
                    tool_input JSON,
                    tool_output TEXT,
                    skill_name VARCHAR(128),
                    skill_input JSON,
                    skill_output TEXT,
                    response TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_session (session_key),
                    INDEX idx_channel (channel),
                    INDEX idx_log_date (log_date),
                    INDEX idx_tool_name (tool_name),
                    INDEX idx_skill_name (skill_name)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
        print(f"[Logger] Database initialized")
    except Exception as e:
        print(f"[Logger] DB init error: {e}")
    finally:
        if conn:
            conn.close()


def truncate_text(text: str, max_len: int = TRUNCATE_LEN) -> str:
    if not text or len(text) <= max_len:
        return text or ""
    return text[:max_len].rsplit(" ", 1)[0] + "..."


def extract_text_from_content(content: Any) -> str:
    """Extract text from content (can be string or list of blocks)."""
    if not content:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        texts = []
        for block in content:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    texts.append(block.get("text", ""))
                elif block.get("type") == "toolCall":
                    tool_name = block.get("name", "unknown")
                    texts.append(f"[TOOL: {tool_name}()]")
                elif block.get("type") == "toolCallResult":
                    texts.append("[TOOL RESULT]")
                elif block.get("type") == "skill_use":
                    skill_name = block.get("name", "unknown")
                    texts.append(f"[SKILL: {skill_name}]")
                elif block.get("type") == "image":
                    texts.append("[IMAGE]")
                elif block.get("type") == "audio":
                    texts.append("[AUDIO]")
        return " ".join(texts)
    return str(content)


def process_content_blocks(blocks: List[Dict], session_key: str, channel: str, log_date: datetime) -> List[Dict]:
    """Process content blocks and yield individual log entries."""
    entries = []
    
    if not blocks:
        return entries
    
    for block in blocks:
        if not isinstance(block, dict):
            continue
        
        block_type = block.get("type", "")
        
        if block_type == "toolCall":
            tool_name = block.get("name", "")
            tool_input = block.get("arguments", {})
            entries.append({
                "session_key": session_key,
                "channel": channel,
                "log_date": log_date,
                "direction": "system",
                "message": f"[TOOL CALL: {tool_name}] " + json.dumps(tool_input, ensure_ascii=False)[:500],
                "message_type": "toolCall",
                "role": "assistant",
                "content_blocks": None,
                "tool_name": tool_name,
                "tool_input": json.dumps(tool_input, ensure_ascii=False),
                "tool_output": None,
                "skill_name": None,
            })

        elif block_type == "toolCallResult":
            # toolCallResult contains id and content
            content = block.get("content", "")
            tool_id = block.get("toolUseId", block.get("id", ""))
            entries.append({
                "session_key": session_key,
                "channel": channel,
                "log_date": log_date,
                "direction": "system",
                "message": truncate_text(f"[TOOL RESULT for {tool_id}] {str(content)[:200]}"),
                "message_type": "toolCallResult",
                "role": "tool",
                "content_blocks": None,
                "tool_name": "toolCallResult",
                "tool_input": tool_id,
                "tool_output": truncate_text(str(content)),
                "skill_name": None,
            })
        
        elif block_type == "skill_use":
            skill_name = block.get("name", "")
            skill_input = block.get("input", {})
            entries.append({
                "session_key": session_key,
                "channel": channel,
                "log_date": log_date,
                "direction": "system",
                "message": f"[SKILL CALL: {skill_name}]",
                "message_type": "skill_use",
                "role": "assistant",
                "content_blocks": None,
                "tool_name": None,
                "tool_input": None,
                "tool_output": None,
                "skill_name": skill_name,
                "skill_input": json.dumps(skill_input, ensure_ascii=False),
            })
    
    return entries


def parse_jsonl_entry(entry: Dict, session_key: str, channel: str) -> List[Dict]:
    """Parse a JSONL entry and return list of log entries."""
    entries = []
    entry_type = entry.get("type", "")
    ts = parse_timestamp(entry.get("timestamp"))
    
    if entry_type == "message":
        msg = entry.get("message", {})
        role = msg.get("role", "")
        content = msg.get("content", [])
        
        # Determine direction
        if role == "user":
            direction = "inbound"
        elif role == "assistant":
            direction = "outbound"
        elif role == "toolResult":
            direction = "system"
        else:
            direction = "system"
        
        # Extract text content
        text_content = extract_text_from_content(content)
        
        # Create main message entry
        entries.append({
            "session_key": session_key,
            "channel": channel,
            "log_date": ts,
            "direction": direction,
            "message": truncate_text(text_content),
            "message_type": "message",
            "role": role,
            "content_blocks": json.dumps(content, ensure_ascii=False) if isinstance(content, list) else None,
            "tool_name": None,
            "tool_input": None,
            "tool_output": None,
            "skill_name": None,
        })
        
        # Process content blocks for tools and skills
        if isinstance(content, list):
            block_entries = process_content_blocks(content, session_key, channel, ts)
            entries.extend(block_entries)
    
    elif entry_type == "toolCall":
        # Standalone toolCall entry (not in message content)
        tool_name = entry.get("name", "")
        tool_input = entry.get("arguments", {})
        entries.append({
            "session_key": session_key,
            "channel": channel,
            "log_date": ts,
            "direction": "system",
            "message": f"[TOOL CALL: {tool_name}] " + json.dumps(tool_input, ensure_ascii=False)[:500],
            "message_type": "toolCall",
            "role": "assistant",
            "content_blocks": None,
            "tool_name": tool_name,
            "tool_input": json.dumps(tool_input, ensure_ascii=False),
            "tool_output": None,
            "skill_name": None,
        })
    
    elif entry_type == "toolCallResult":
        # Standalone toolCallResult entry
        content = entry.get("content", "")
        tool_name = entry.get("name", "unknown")
        entries.append({
            "session_key": session_key,
            "channel": channel,
            "log_date": ts,
            "direction": "system",
            "message": truncate_text(str(content)[:200]),
            "message_type": "toolCallResult",
            "role": "tool",
            "content_blocks": None,
            "tool_name": tool_name,
            "tool_input": None,
            "tool_output": truncate_text(str(content)),
            "skill_name": None,
        })
    
    elif entry_type == "custom":
        custom_type = entry.get("customType", "")
        data = entry.get("data", {})
        entries.append({
            "session_key": session_key,
            "channel": channel,
            "log_date": ts,
            "direction": "system",
            "message": f"[{custom_type}]",
            "message_type": f"custom_{custom_type}",
            "role": "system",
            "content_blocks": json.dumps(data, ensure_ascii=False),
            "tool_name": None,
            "tool_input": None,
            "tool_output": None,
            "skill_name": None,
        })
    
    elif entry_type == "skill":
        # Standalone skill entry
        skill_name = entry.get("name", "")
        skill_input = entry.get("input", {})
        entries.append({
            "session_key": session_key,
            "channel": channel,
            "log_date": ts,
            "direction": "system",
            "message": f"[SKILL: {skill_name}]",
            "message_type": "skill",
            "role": "assistant",
            "content_blocks": None,
            "tool_name": None,
            "tool_input": None,
            "tool_output": None,
            "skill_name": skill_name,
            "skill_input": json.dumps(skill_input, ensure_ascii=False),
        })
    
    return entries


def parse_timestamp(ts: Any) -> datetime:
    if not ts:
        return datetime.now()
    if isinstance(ts, (int, float)):
        return datetime.fromtimestamp(ts / 1000)
    if isinstance(ts, str):
        try:
            return datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except:
            try:
                return datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")
            except:
                return datetime.now()
    return datetime.now()


def get_session_channel(session_file: Path) -> str:
    """Get channel from session file metadata."""
    try:
        sessions_file = session_file.parent / "sessions.json"
        if sessions_file.exists():
            with open(sessions_file, "r") as f:
                sessions = json.load(f)
                session_id = session_file.stem
                if session_id in sessions:
                    return sessions[session_id].get("channel", "feishu")
    except:
        pass
    return "feishu"


# ========== LOG QUEUE & WORKER ==========
log_queue: queue.Queue = queue.Queue(maxsize=10000)


def log_worker():
    """Background worker that inserts logs to MySQL."""
    conn = None
    while True:
        try:
            entry = log_queue.get(timeout=1)
            if entry is None:
                break
            
            conn = get_db_connection()
            with conn.cursor() as cur:
                sql = """
                    INSERT INTO conversation_logs 
                    (session_key, channel, log_date, direction, message, message_type, role,
                     content_blocks, tool_name, tool_input, tool_output, skill_name, response)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cur.execute(sql, (
                    entry.get("session_key", ""),
                    entry.get("channel", "unknown"),
                    entry.get("log_date", datetime.now()),
                    entry.get("direction", "system"),
                    entry.get("message", ""),
                    entry.get("message_type", ""),
                    entry.get("role", ""),
                    entry.get("content_blocks"),
                    entry.get("tool_name"),
                    entry.get("tool_input"),
                    entry.get("tool_output"),
                    entry.get("skill_name"),
                    entry.get("response", ""),
                ))
            conn.close()
            
        except queue.Empty:
            continue
        except Exception as e:
            print(f"[Logger] DB insert error: {e}")
            if conn:
                try:
                    conn.close()
                except:
                    pass
            time.sleep(1)


def enqueue_log(entry: Dict):
    """Add log entry to queue. Silently drops if full."""
    try:
        log_queue.put_nowait(entry)
    except queue.Full:
        pass


# ========== FILE WATCHER ==========
class SessionLogHandler(FileSystemEventHandler):
    def __init__(self):
        super().__init__()
        self.file_positions: Dict[Path, int] = {}
    
    def on_modified(self, event):
        if event.is_directory:
            return
        path = Path(event.src_path)
        if path.suffix != ".jsonl" or path.name.endswith(".lock"):
            return
        
        self.process_new_entries(path)
    
    def process_new_entries(self, path: Path):
        try:
            last_pos = self.file_positions.get(path, 0)
            
            with open(path, "r", encoding="utf-8") as f:
                f.seek(last_pos)
                new_content = f.read()
                new_pos = f.tell()
                self.file_positions[path] = new_pos
            
            if not new_content.strip():
                return
            
            session_key = path.stem
            channel = get_session_channel(path)
            
            for line in new_content.strip().split("\n"):
                if not line.strip():
                    continue
                try:
                    entry = json.loads(line)
                    log_entries = parse_jsonl_entry(entry, session_key, channel)
                    for log_entry in log_entries:
                        enqueue_log(log_entry)
                except json.JSONDecodeError:
                    continue
                    
        except Exception as e:
            pass


def find_session_files() -> List[Path]:
    session_files = []
    if not SESSION_DIR.exists():
        return session_files
    
    for agent_dir in SESSION_DIR.iterdir():
        if not agent_dir.is_dir():
            continue
        sessions_dir = agent_dir / "sessions"
        if sessions_dir.exists():
            for jsonl_file in sessions_dir.glob("*.jsonl"):
                if not jsonl_file.name.endswith(".lock") and not jsonl_file.name.endswith(".deleted"):
                    session_files.append(jsonl_file)
    
    return session_files


def poll_session_files(handler: SessionLogHandler):
    while True:
        try:
            session_files = find_session_files()
            for path in session_files:
                if path.exists():
                    handler.process_new_entries(path)
        except Exception:
            pass
        time.sleep(POLL_INTERVAL)


# ========== MAIN ==========
def main():
    print(f"[Logger] Conversation Logger starting...")
    print(f"[Logger] Session dir: {SESSION_DIR}")
    print(f"[Logger] MySQL: {MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}")
    
    init_db()
    
    worker_thread = threading.Thread(target=log_worker, daemon=True)
    worker_thread.start()
    print(f"[Logger] Worker thread started")
    
    handler = SessionLogHandler()
    session_files = find_session_files()
    print(f"[Logger] Found {len(session_files)} session files")
    
    for path in session_files:
        try:
            handler.file_positions[path] = path.stat().st_size
        except:
            pass
    
    try:
        observer = Observer()
        for path in session_files:
            parent = path.parent
            if not any(w.path == str(parent) for w in observer.handlers.keys()):
                observer.schedule(handler, str(parent), recursive=False)
        observer.start()
        print(f"[Logger] File observer started")
        
        while True:
            time.sleep(60)
            
    except Exception as e:
        print(f"[Logger] Falling back to polling mode: {e}")
        while True:
            poll_session_files(handler)
            time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
