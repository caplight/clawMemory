#!/usr/bin/env python3
"""
University of Amsterdam (UvA) PhD Job Scraper
Portal: https://werkenbij.uva.nl/en/vacancies
Searches PhD + Researcher positions and saves matching jobs to MySQL.
"""

import os
import re
import time

import requests
from bs4 import BeautifulSoup
import pymysql

BASE_URL = "https://werkenbij.uva.nl/en/vacancies"
SEARCH_URL = BASE_URL

MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", ""),
    "database": os.environ.get("MYSQL_DATABASE", "phd_jobs"),
    "charset": "utf8mb4",
}

KEYWORDS = [
    "ai", "machine learning", "deep learning", "agent", "multi-agent",
    "computer science", "edge computing", "iot", "internet of things",
    "orchestrator", "orchestration", "autonomous", "distributed systems",
    "embedded", "neural network", "foundation model", "generative ai",
    "causal", "explainable ai", "xai", "artificial intelligence",
    "data science", "software engineering", "software development",
    "quantum", "robot", "cognitive science", "human-computer",
]

CAREER_FILTERS = ["74", "134"]  # f=74: PhD position, f=134: Researcher

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def get_db():
    return pymysql.connect(**MYSQL_CONFIG, autocommit=True)

def save_job_to_db(job):
    conn = None
    try:
        conn = get_db()
        with conn.cursor() as cur:
            full_text = job.get("full_text", "") or ""
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            sql = """
                INSERT INTO jobs (title, source, url, employer, published, deadline, full_text)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            cur.execute(sql, (
                job["title"],
                "uva.nl",
                job.get("url", ""),
                job.get("employer", ""),
                job.get("published"),
                job.get("deadline"),
                full_text,
            ))
        return True
    except Exception as e:
        print(f"    [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def parse_vacancy_list_page(html):
    """Parse vacancy list page, return list of dicts with title, url, employer."""
    soup = BeautifulSoup(html, "html.parser")
    jobs = []

    for item in soup.find_all("li", class_="vacancy-item-cell"):
        link = item.find("a", class_="vacancy-item")
        if not link:
            continue
        href = link.get("href", "")
        if href:
            full_url = "https://werkenbij.uva.nl" + href if href.startswith("/") else href
        else:
            continue

        title_el = item.find("h3")
        title = title_el.get_text(strip=True) if title_el else ""

        employer = ""
        meta_items = item.find_all("li", class_=re.compile("success-factors"))
        for mi in meta_items:
            txt = mi.get_text(strip=True)
            if txt:
                employer = txt
                break

        if title and full_url:
            jobs.append({
                "title": title,
                "url": full_url,
                "employer": employer,
            })

    return jobs

def parse_vacancy_detail(html, url):
    """Extract full text description from vacancy detail page."""
    soup = BeautifulSoup(html, "html.parser")

    desc_el = soup.find("div", class_=re.compile("vacancy-description|job-description|description"))
    if not desc_el:
        desc_el = soup.find("section", class_=re.compile("content|description|main"))

    text_parts = []
    if desc_el:
        for p in desc_el.find_all(["p", "h2", "h3", "li", "div"]):
            t = p.get_text(strip=True)
            if t and len(t) > 5:
                text_parts.append(t)

    if not text_parts:
        body = soup.find("body")
        if body:
            for tag in ["section", "article", "div"]:
                for el in body.find_all(tag):
                    cls = el.get("class", [])
                    cls_str = " ".join(cls).lower()
                    if "description" in cls_str or "content" in cls_str or "vacancy" in cls_str:
                        t = el.get_text(strip=True)
                        if len(t) > 50:
                            text_parts.append(t[:3000])
                            break

    full_text = " ".join(text_parts)
    if len(full_text) > 3000:
        full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."

    deadline = None
    deadline_match = re.search(r"(?:closes?|deadline|expiry)[:\s]+(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4})", html, re.I)
    if deadline_match:
        deadline = deadline_match.group(1)

    return {
        "full_text": full_text,
        "deadline": deadline,
    }

def fetch_vacancy_list(keyword="", career_filter=""):
    """Fetch vacancy list page with given keyword and career filter."""
    params = {}
    if keyword:
        params["q"] = keyword
    if career_filter:
        params["f"] = career_filter
    params["o"] = "0"
    params["n"] = "100"

    try:
        r = requests.get(SEARCH_URL, params=params, headers=HEADERS, timeout=15)
        if r.status_code == 429:
            retry_after = r.headers.get("Retry-After", "60")
            print(f"  [WARN] Rate limited, waiting {retry_after}s...")
            time.sleep(int(retry_after))
            return []
        if r.status_code != 200:
            print(f"  HTTP {r.status_code} for {params}")
            return []
        return parse_vacancy_list_page(r.text)
    except Exception as e:
        print(f"  Fetch error: {e}")
        return []

def fetch_vacancy_detail(url):
    """Fetch individual vacancy page."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=15)
        if r.status_code == 429:
            retry_after = r.headers.get("Retry-After", "60")
            print(f"    [WARN] Rate limited, waiting {retry_after}s...")
            time.sleep(int(retry_after))
            return {}
        if r.status_code != 200:
            return {}
        return parse_vacancy_detail(r.text, url)
    except Exception as e:
        print(f"    [DETAIL ERROR] {e}")
        return {}

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def keyword_matches(text, keywords):
    """Check if any keyword matches in text."""
    text_lower = text.lower()
    return any(kw.lower() in text_lower for kw in keywords)

def main():
    print("=" * 60)
    print("UvA PhD Job Scraper")
    print("=" * 60)

    all_jobs = []

    for cf in CAREER_FILTERS:
        print(f"\n  Fetching career filter f={cf}...")
        jobs = fetch_vacancy_list(career_filter=cf)
        print(f"  Found {len(jobs)} vacancy items")
        all_jobs.extend(jobs)

    seen_urls = set()
    unique_jobs = []
    for j in all_jobs:
        if j["url"] not in seen_urls:
            seen_urls.add(j["url"])
            unique_jobs.append(j)
    print(f"  Total unique: {len(unique_jobs)}")

    print(f"\n  Filtering by keywords...")
    relevant = []
    for j in unique_jobs:
        if keyword_matches(j["title"], KEYWORDS) and not is_postdoc(j["title"]):
            relevant.append(j)
            print(f"    ✓ [{j['title'][:70]}]")
        else:
            print(f"    - {j['title'][:70]}")
    print(f"  Keyword-matched: {len(relevant)}")

    if not relevant:
        print("  No matching jobs found.")
        return

    print(f"\n  Fetching details and saving to DB...")
    saved = 0
    for j in relevant:
        print(f"  → {j['title'][:60]}...", end=" ", flush=True)
        detail = fetch_vacancy_detail(j["url"])
        j.update(detail)

        if not j.get("full_text"):
            j["full_text"] = ""

        ok = save_job_to_db(j)
        if ok:
            saved += 1
            print("✓ saved")
        else:
            print("✗ error")

        time.sleep(0.3)

    print(f"\n  Done! Saved {saved}/{len(relevant)} jobs to DB.")
    print(f"  Source: uva.nl")

if __name__ == "__main__":
    main()
