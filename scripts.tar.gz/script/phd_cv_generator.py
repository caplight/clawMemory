#!/usr/bin/env python3
"""
PhD CV Generator
================
Pulls all "applied but not reviewed" PhD jobs from Notion,
generates customized academic CVs for each using MiniMax + Resume Assistant framework,
outputs formatted HTML and PDF files.

Usage:
    python3 phd_cv_generator.py [--dry-run] [--job-id NOTE_ID]

Dependencies:
    pip install requests beautifulsoup4
    Chrome + xvfb for PDF generation
"""

import os
import sys
import json
import time
import argparse
import requests
import subprocess
import re
from pathlib import Path
from datetime import datetime

# ─── Config ───────────────────────────────────────────────────────────────────

CONFIG_PATH = "/home/cap/script/phd_job_ranker_config.json"
RESUME_LIBRARY_PATH = "/root/.openclaw/workspace/phd-application/Master_Resume_Library.md"
HTML_TEMPLATE_PATH = "/root/.openclaw/workspace/phd-application/cv_templates/academic_cv_template.html"
OUTPUT_DIR = Path("/root/.openclaw/workspace/phd-application/generated_cvs")
NOTION_DB_ID = "329267b2-de94-8140-a6aa-f2f77cb5b1a2"

with open(CONFIG_PATH) as f:
    cfg = json.load(f)

NOTION_KEY = cfg["notion_api_key"]
MINIMAX_KEY = cfg["minimax_api_key"]
MINIMAX_MODEL = cfg["minimax_model"]
MINIMAX_API = cfg["minimax_api"]

HEADERS_NOTION = {
    "Authorization": f"Bearer {NOTION_KEY}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json"
}

# ─── Notion helpers ───────────────────────────────────────────────────────────

def notion_query(payload):
    url = f"https://api.notion.com/v1/databases/{NOTION_DB_ID}/query"
    r = requests.post(url, headers=HEADERS_NOTION, json=payload, timeout=30)
    r.raise_for_status()
    return r.json()

def get_unreviewed_applied_jobs():
    """Return list of job pages where 是否投递=True AND 是否审核=False."""
    payload = {
        "page_size": 100,
        "filter": {
            "and": [
                {"property": "是否投递", "checkbox": {"equals": True}},
                {"property": "是否审核", "checkbox": {"equals": False}}
            ]
        }
    }
    all_results = []
    while True:
        data = notion_query(payload)
        all_results.extend(data.get("results", []))
        if not data.get("has_more"):
            break
        payload["start_cursor"] = data.get("next_cursor")
    return all_results

def get_prop(page, name, ptype="title"):
    """Safely extract a property value from a Notion page."""
    props = page.get("properties", {})
    prop = props.get(name, {})
    t = prop.get("type", "")
    try:
        if t == "title":
            return "".join(p.get("plain_text", "") for p in prop.get("title", []))
        elif t == "rich_text":
            return "".join(p.get("plain_text", "") for p in prop.get("rich_text", []))
        elif t == "url":
            return prop.get("url") or ""
        elif t == "number":
            return prop.get("number")
        elif t == "checkbox":
            return prop.get("checkbox")
        elif t == "date":
            d = prop.get("date", {})
            return d.get("start", "") if d else ""
        elif t == "select":
            return prop.get("select", {}).get("name", "")
        else:
            return str(prop)
    except Exception:
        return ""

def update_notion_page(page_id, properties):
    """Update a Notion page's properties."""
    url = f"https://api.notion.com/v1/pages/{page_id}"
    payload = {"properties": properties}
    r = requests.patch(url, headers=HEADERS_NOTION, json=payload, timeout=15)
    return r.status_code == 200

# ─── Job Description Fetcher ─────────────────────────────────────────────────

def fetch_job_description(url):
    """
    Fetch job description text from a URL.
    Uses curl + BeautifulSoup to strip HTML.
    Falls back to raw web fetch if needed.
    """
    if not url or not url.startswith("http"):
        return ""

    try:
        # Use curl with browser UA
        r = requests.get(
            url,
            timeout=15,
            headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml"
            },
            allow_redirects=True
        )
        html = r.text

        # Strip script and style tags
        html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL)
        html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL)
        # Strip tags
        text = re.sub(r'<[^>]+>', ' ', html)
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text).strip()

        # Try to extract meaningful content (skip cookie notices)
        sentences = text.split('. ')
        meaningful = []
        skip_phrases = ["cookie", "privacy policy", "accept", "decline", "this website uses"]
        for s in sentences:
            s = s.strip()
            if len(s) > 50 and not any(p in s.lower() for p in skip_phrases):
                meaningful.append(s)

        result = '. '.join(meaningful[:50])  # first 50 sentences
        return result[:8000]  # cap at 8000 chars

    except Exception as e:
        print(f"  ⚠ Failed to fetch {url}: {e}")
        return ""


def is_document_url(url: str) -> bool:
    """Return True if URL points to a downloadable document."""
    return bool(re.search(r"\.(docx?|pdf)(\?|$)", url, re.I))


def download_document(url: str, cache_dir: Path = Path("/tmp/doc_cache")) -> str:
    """
    Download a docx/pdf URL to cache dir, return local file path.
    Supports: .docx, .pdf
    """
    cache_dir.mkdir(parents=True, exist_ok=True)

    # Determine filename
    parsed = requests.utils.urlparse(url)
    path_part = parsed.path.split("/")[-1]
    if not re.search(r"\.(docx?|pdf)$", path_part, re.I):
        # Try to detect from Content-Type header
        try:
            head = requests.head(url, timeout=10,
                headers={"User-Agent": "Mozilla/5.0"}, allow_redirects=True)
            ct = head.headers.get("Content-Type", "")
            if "word" in ct or "document" in ct:
                path_part += ".docx"
            elif "pdf" in ct:
                path_part += ".pdf"
        except:
            pass

    local_path = cache_dir / path_part

    if local_path.exists():
        print(f"  Using cached doc: {local_path.name}")
        return str(local_path)

    print(f"  Downloading document: {url}")
    try:
        r = requests.get(url, timeout=30,
            headers={"User-Agent": "Mozilla/5.0"}, stream=True)
        r.raise_for_status()
        with open(local_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"  Downloaded: {local_path.name} ({local_path.stat().st_size} bytes)")
        return str(local_path)
    except Exception as e:
        print(f"  ⚠ Download failed: {e}")
        return ""


def read_docx_text(path: str) -> str:
    """Extract plain text from a .docx file."""
    try:
        from zipfile import ZipFile
        from xml.etree import ElementTree as ET

        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        with ZipFile(path) as z:
            with z.open("word/document.xml") as f:
                tree = ET.parse(f)
        root = tree.getroot()
        paragraphs = []
        for para in root.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
            texts = []
            for run in para.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"):
                if run.text:
                    texts.append(run.text)
            line = "".join(texts)
            if line.strip():
                paragraphs.append(line)
        return "\n".join(paragraphs)
    except Exception as e:
        print(f"  ⚠ docx read error: {e}")
        return ""


def fetch_job_description_v2(url: str, cache_dir: Path = Path("/tmp/doc_cache")) -> str:
    """
    Full version: handle both web URLs and document URLs.
    For documents (.docx/.pdf), download then extract text.
    """
    if not url or not url.startswith("http"):
        return ""

    if is_document_url(url):
        doc_path = download_document(url, cache_dir)
        if not doc_path:
            return ""
        if doc_path.endswith(".docx"):
            return read_docx_text(doc_path)
        elif doc_path.endswith(".pdf"):
            # Try pdftotext
            import subprocess
            try:
                result = subprocess.run(
                    ["pdftotext", doc_path, "-"],
                    capture_output=True, text=True, timeout=30
                )
                if result.returncode == 0:
                    return result.stdout[:8000]
            except Exception as e:
                print(f"  ⚠ pdftotext failed: {e}")
            return ""
        return ""

    # Regular web page
    return fetch_job_description(url)

# ─── MiniMax LLM ─────────────────────────────────────────────────────────────

def minimax_chat(system_prompt: str, user_prompt: str, model: str = None,
                  temperature: float = 0.3, max_tokens: int = 3000) -> str:
    """Call MiniMax chat completion API."""
    model = model or MINIMAX_MODEL
    base = MINIMAX_API.rstrip('/')
    # Avoid double /chat/completions
    if base.endswith('/chat/completions'):
        url = base
    else:
        url = f"{base}/chat/completions"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": temperature,
        "max_tokens": max_tokens
    }
    r = requests.post(
        url,
        headers={
            "Authorization": f"Bearer {MINIMAX_KEY}",
            "Content-Type": "application/json"
        },
        json=payload,
        timeout=120
    )
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"]

# ─── Resume Assistant Customize Prompt ────────────────────────────────────────

def build_customize_prompt(job_title: str, job_description: str, resume_library: str) -> tuple:
    """
    Build system + user prompts for the Resume Assistant customize workflow.
    Returns (system_prompt, user_prompt).
    """
    system_prompt = """You are an expert academic CV writer following the Resume Assistant /resume customize framework.

Your task: Given a candidate's master resume library and a PhD job description, produce a fully customized academic CV in Markdown format.

## Output Format
Output ONLY the customized CV in Markdown format. No preamble, no explanation.

## Rules
1. Extract relevant experience from the resume library — match keywords from the job description
2. Reorder bullets within each role to put the most relevant achievements first
3. Rewrite the Professional Summary / Research Statement to directly address the PhD topic
4. Use bold for section headers and company names
5. Use • for primary bullets, – for nested bullets
6. Keep the tone professional and academic
7. Include all sections: Education, Research/Professional Experience, Technical Skills, References
8. Preserve honest history — never delete real experience
9. Infer cross-disciplinary connections where the candidate's background overlaps with the role (e.g., industry RAG work → related to HCI/AI interaction)
10. Match terminology from the job description exactly
"""

    user_prompt = f"""## Job Title
{job_title}

## Job Description (excerpt)
{job_description[:6000]}

## Candidate Master Resume Library
{resume_library}

---

Following the Resume Assistant /resume customize framework, produce a complete customized academic CV in Markdown format for this PhD application. Output ONLY the CV markdown."""

    return system_prompt, user_prompt

# ─── HTML CV Generator ───────────────────────────────────────────────────────

def md_to_academic_html(cv_content: str, job_title: str, school: str,
                         output_path: Path) -> bool:
    """
    Convert Markdown CV content to academic-formatted HTML,
    then generate PDF via Chrome headless.
    """
    # Parse markdown-ish content into structured sections
    # This is a simplified parser — expects specific headings
    sections = parse_cv_markdown(cv_content)

    # Load HTML template
    with open(HTML_TEMPLATE_PATH, encoding="utf-8") as f:
        template = f.read()

    # Build body content
    body_html = build_cv_html(sections)

    # Fill template
    html = template.replace("<body>", f"<body>\n{body_html}")

    html_path = output_path.with_suffix(".html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)

    return str(html_path)


def parse_cv_markdown(md_text: str) -> dict:
    """Parse markdown CV into structured sections."""
    sections = {}
    current_section = None
    current_content = []

    for line in md_text.split("\n"):
        line = line.rstrip()
        # Section header (## or **)
        if re.match(r"^##?\s+", line) or (line.startswith("**") and line.endswith("**")):
            if current_section:
                sections[current_section] = "\n".join(current_content).strip()
            header = re.sub(r"^##?\s+|\*\*(.*)\*\*", r"\1", line).strip()
            current_section = header
            current_content = []
        else:
            current_content.append(line)

    if current_section:
        sections[current_section] = "\n".join(current_content).strip()

    return sections


def escape_html(text: str) -> str:
    """Basic HTML escaping."""
    return (text.replace("&", "&amp;")
              .replace("<", "&lt;")
              .replace(">", "&gt;")
              .replace('"', "&quot;"))


def build_cv_html(sections: dict) -> str:
    """Build HTML body from parsed CV sections."""
    html_parts = []

    def add_section(title, content_lines):
        if not content_lines:
            return ""
        # Determine section type
        if title in ("Education", "Professional Experience", "Research Experience",
                     "Technical Skills", "References"):
            return _build_formatted_section(title, content_lines)
        else:
            return _build_generic_section(title, content_lines)

    def _build_formatted_section(title, content_lines):
        lines = content_lines if isinstance(content_lines, list) else content_lines.split("\n")
        parts = [f'<div class="section-header">{escape_html(title)}</div>']

        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if not line:
                i += 1
                continue

            # Entry header (bolded, or with **)
            if line.startswith("**") or re.match(r"^[A-Z]", line):
                # Try to extract bold runs
                bold_runs = re.findall(r"\*\*(.*?)\*\*", line)
                if bold_runs:
                    entry_text = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", line)
                    parts.append(f"<div class='entry-header-text'>{entry_text}</div>")
                else:
                    parts.append(f"<div class='entry-header-text'><strong>{escape_html(line)}</strong></div>")
            elif line.startswith("•"):
                bullet_content = line[1:].strip()
                bullet_html = _format_bullet(bullet_content)
                parts.append(f"<ul><li>{bullet_html}</li></ul>")
            elif line.startswith("-"):
                bullet_content = line[1:].strip()
                bullet_html = _format_bullet(bullet_content)
                parts.append(f"<ul><li class='sub'>{bullet_html}</li></ul>")
            else:
                parts.append(f"<p>{escape_html(line)}</p>")
            i += 1

        return "\n".join(parts)

    def _build_generic_section(title, content):
        content = content.strip() if isinstance(content, str) else content
        return f"<div class='section-header'>{escape_html(title)}</div><p>{escape_html(str(content))}</p>"

    def _format_bullet(text):
        # Handle **bold** and : separators
        # e.g. "**Research Objective:** Designed..."
        formatted = re.sub(r"\*\*(.*?)\*\*", r"<strong>\1</strong>", escape_html(text))
        formatted = re.sub(r"\*\*:", r"</strong>:", formatted)
        return formatted

    # Process known sections
    for sec_title, sec_content in sections.items():
        if sec_title in ("Education", "Professional Experience", "Research Experience",
                         "Technical Skills", "References"):
            html_parts.append(_build_formatted_section(sec_title, sec_content))
        elif sec_title:
            html_parts.append(_build_generic_section(sec_title, sec_content))

    return "\n".join(html_parts)


# ─── PDF Generator ────────────────────────────────────────────────────────────

def html_to_pdf(html_path: str, pdf_path: str) -> bool:
    """Generate PDF from HTML using Chrome headless."""
    html_abs = os.path.abspath(html_path)
    pdf_abs = os.path.abspath(pdf_path)
    file_url = f"file://{html_abs}"

    result = subprocess.run(
        [
            "xvfb-run", "--auto-servernum",
            "google-chrome", "--headless", "--disable-gpu", "--no-sandbox",
            f"--print-to-pdf={pdf_abs}",
            "--print-to-pdf-no-header",
            file_url
        ],
        capture_output=True, timeout=60
    )
    # Chrome writes to pdf even if stderr has errors
    return os.path.exists(pdf_abs)


# ─── Main ─────────────────────────────────────────────────────────────────────

def generate_cv_for_job(page: dict, output_dir: Path, dry_run: bool = False) -> dict:
    """Generate a single CV for a Notion job page. Returns result dict."""
    job_id = page["id"]
    title = get_prop(page, "岗位名称")
    school = get_prop(page, "学校")
    url = get_prop(page, "链接")
    match_reason = get_prop(page, "匹配原因")

    print(f"\n{'='*60}")
    print(f"Processing: {title}")
    print(f"School: {school}")
    print(f"URL: {url}")

    if not url:
        print("  ⚠ No URL — skipping")
        return {"job_id": job_id, "title": title, "school": school, "status": "skipped", "reason": "no URL"}

    # 1. Fetch job description (handles both web and document URLs)
    print("  Fetching job description...")
    job_desc = fetch_job_description_v2(url)
    if not job_desc:
        print("  ⚠ Could not fetch job description — using match_reason fallback")
        job_desc = match_reason  # fallback to match reason field

    if dry_run:
        print("  [DRY RUN] Skipping MiniMax call")
        return {"job_id": job_id, "title": title, "school": school, "status": "dry_run"}

    # 2. Load resume library
    with open(RESUME_LIBRARY_PATH, encoding="utf-8") as f:
        resume_library = f.read()

    # 3. Build MiniMax prompt
    system_prompt, user_prompt = build_customize_prompt(title, job_desc, resume_library)

    print("  Generating CV via MiniMax...")
    try:
        cv_md = minimax_chat(system_prompt, user_prompt)
    except Exception as e:
        print(f"  ⚠ MiniMax failed: {e}")
        # Save error log
        safe_school2 = re.sub(r"[^\w\s\-]", "", school[:30]).strip().replace(" ", "_")
        safe_title2 = re.sub(r"[^\w\s\-]", "", title[:40]).strip().replace(" ", "_")
        fp2 = f"CV_{safe_school2}_{safe_title2}"
        log_path_err = output_dir / f"{fp2}_log.json"
        with open(log_path_err, "w", encoding="utf-8") as f:
            json.dump({
                "job_id": job_id, "title": title, "school": school,
                "url": url, "status": "error",
                "error": str(e), "timestamp": datetime.now().isoformat()
            }, f, indent=2, ensure_ascii=False)
        return {"job_id": job_id, "title": title, "school": school, "status": "error", "reason": str(e)}

    if not cv_md or len(cv_md) < 200:
        print(f"  ⚠ CV content too short ({len(cv_md)} chars)")
        return {"job_id": job_id, "title": title, "school": school, "status": "error", "reason": "CV too short"}

    # 4. Save raw Markdown
    # Safe filename: CV_学校名_岗位名.pdf
    safe_school = re.sub(r"[^\w\s\-]", "", school[:30]).strip().replace(" ", "_")
    safe_title = re.sub(r"[^\w\s\-]", "", title[:40]).strip().replace(" ", "_")
    file_prefix = f"CV_{safe_school}_{safe_title}"
    md_path = output_dir / f"{file_prefix}.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(cv_md)
    print(f"  ✓ Markdown saved: {md_path.name}")

    # 5. Generate PDF
    pdf_path = output_dir / f"{file_prefix}.pdf"
    html_path = md_to_academic_html(cv_md, title, school, output_dir / file_prefix)

    if html_path:
        pdf_ok = html_to_pdf(html_path, str(pdf_path))
        if pdf_ok:
            print(f"  ✓ PDF generated: {pdf_path.name}")
        else:
            print(f"  ⚠ PDF generation failed (HTML still available: {html_path})")

    # 6. Save per-job log
    log = {
        "job_id": job_id,
        "title": title,
        "school": school,
        "url": url,
        "status": "success",
        "md_path": str(md_path),
        "pdf_path": str(pdf_path) if pdf_ok else None,
        "cv_length_chars": len(cv_md),
        "timestamp": datetime.now().isoformat()
    }
    log_path = output_dir / f"{file_prefix}_log.json"
    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2, ensure_ascii=False)
    print(f"  ✓ Log saved: {log_path.name}")

    # 6. Notion page is NOT marked as reviewed (user manages review manually)
    print(f"  ✓ Notion page unchanged (not marked as reviewed)")

    return {
        "job_id": job_id,
        "title": title,
        "school": school,
        "status": "success",
        "md_path": str(md_path),
        "pdf_path": str(pdf_path) if pdf_path.exists() else None
    }


def main():
    parser = argparse.ArgumentParser(description="PhD CV Generator")
    parser.add_argument("--dry-run", action="store_true", help="Don't call MiniMax, just show job list")
    parser.add_argument("--job-id", help="Process only a specific Notion page ID")
    parser.add_argument("--output-dir", default=str(OUTPUT_DIR), help="Output directory")
    parser.add_argument("--limit", type=int, default=0, help="Limit number of jobs to process (0=all)")
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"PhD CV Generator — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"Output dir: {output_dir}")
    print(f"Dry run: {args.dry_run}")

    # Query Notion
    print("\nFetching unreviewed applied jobs from Notion...")
    jobs = get_unreviewed_applied_jobs()
    print(f"Found {len(jobs)} jobs")

    if not jobs:
        print("No jobs to process. Done.")
        return

    # Apply limit
    if args.limit > 0:
        jobs = jobs[:args.limit]
        print(f"Limited to {args.limit} jobs")

    # Filter if specific job ID given
    if args.job_id:
        jobs = [j for j in jobs if j["id"] == args.job_id]
        if not jobs:
            print(f"Job {args.job_id} not found or not in unreviewed applied list.")
            return

    results = []
    for i, job in enumerate(jobs, 1):
        print(f"\n[{i}/{len(jobs)}]", end=" ")
        result = generate_cv_for_job(job, output_dir, dry_run=args.dry_run)
        results.append(result)
        # Rate limit: sleep 5s between MiniMax calls
        if not args.dry_run:
            time.sleep(5)

    # Summary
    print(f"\n\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    success = [r for r in results if r["status"] == "success"]
    errors = [r for r in results if r["status"] == "error"]
    skipped = [r for r in results if r["status"] == "skipped"]
    dry_runs = [r for r in results if r["status"] == "dry_run"]

    print(f"✓ Success: {len(success)}")
    print(f"✗ Errors: {len(errors)}")
    print(f"⊘ Skipped (no URL): {len(skipped)}")
    print(f"⊘ Dry run: {len(dry_runs)}")
    for r in errors:
        print(f"  - {r['title']}: {r.get('reason', 'unknown')}")

    # Save results
    results_path = output_dir / f"results_{datetime.now().strftime('%Y%m%d_%H%M')}.json"
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print(f"\nResults saved: {results_path}")


if __name__ == "__main__":
    main()
