#!/usr/bin/env python3
"""
Upload workspace backups to GitHub Releases.
This bypasses the git push file size limit (100MB) by uploading
directly to GitHub Releases via the API.
"""
import os
import glob
import time

os.environ['HTTPS_PROXY'] = 'http://192.168.23.1:7890'
os.environ['HTTP_PROXY'] = 'http://192.168.23.1:7890'

from github import Github
from github.GithubException import UnknownObjectException

BACKUP_DIR = "/home/cap/backup"
TOKEN = "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"
REPO_NAME = "caplight/clawMemory"

def get_today_tag():
    return f"backup-{time.strftime('%Y-%m-%d')}"

def find_assets():
    """Find all backup tar.gz files"""
    patterns = [
        f"{BACKUP_DIR}/workspace-main.tar.gz",
        f"{BACKUP_DIR}/workspace-newbot.tar.gz", 
        f"{BACKUP_DIR}/workspace-wechatbot.tar.gz",
        f"{BACKUP_DIR}/scripts.tar.gz",
    ]
    assets = []
    for p in patterns:
        if os.path.exists(p):
            size_mb = os.path.getsize(p) / 1024 / 1024
            assets.append((p, os.path.basename(p), size_mb))
    return assets

def main():
    g = Github(TOKEN)
    repo = g.get_repo(REPO_NAME)
    print(f"Connected to {repo.full_name}")

    assets = find_assets()
    if not assets:
        print("No backup files found!")
        return

    print(f"\nFound {len(assets)} assets:")
    for path, name, size in assets:
        print(f"  {name}: {size:.1f} MB")

    tag = get_today_tag()
    print(f"\nTag: {tag}")

    # Find or create release
    try:
        release = repo.get_release(tag)
        print(f"Release exists: {release.tag_name}")
        # Delete existing assets
        for a in release.get_assets():
            print(f"  Deleting old asset: {a.name}")
            a.delete_asset()
    except UnknownObjectException:
        print("Creating new release...")
        release = repo.create_git_release(
            tag=tag,
            name=f"Backup {time.strftime('%Y-%m-%d')}",
            message=f"Workspace backup - {time.strftime('%Y-%m-%d %H:%M')}",
            draft=False,
            prerelease=False
        )
        print(f"Release created: {release.html_url}")

    # Upload assets
    for path, name, size in assets:
        print(f"\nUploading {name} ({size:.1f} MB)...")
        try:
            asset = release.upload_asset(path, content_type='application/gzip')
            print(f"  SUCCESS: {asset.browser_download_url}")
        except Exception as e:
            print(f"  FAILED: {e}")

    print("\n=== Done ===")
    print(f"Release: {release.html_url}")

if __name__ == "__main__":
    main()
