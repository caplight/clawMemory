#!/usr/bin/env python3
"""
Ireland work permit eligibility checker.
Checks two sources:
  1. Excel list of companies with issued work permits (2024)
  2. IrishTalents API as fallback
"""

import json, os, sys
import openpyxl
import requests
from pathlib import Path
from functools import lru_cache

# ---- Paths ----
SCRIPT_DIR = Path(__file__).parent
EXCEL_PATH = "/home/cap/script/jobTracker/permits-issued-to-companies-2024.xlsx"
EMPLOYER_JSON_PATH = "/home/cap/script/jobTracker/ireland_permit_employers.json"
API_KEY = "bf6f11017cea86030f7fbc3e281d7fcf3604fd78d7f2f44824c08bd230547a9e"
API_URL = "https://api.irishtalents.com/api/v1/companies"

# ---- Load Excel into a JSON cache for fast startup ----
def _build_excel_set() -> set[str]:
    """Load employer names from Excel, cache to JSON for speed."""
    employers = set()
    try:
        wb = openpyxl.load_workbook(EXCEL_PATH, read_only=True, data_only=True)
        ws = wb.active
        header = True
        for row in ws.iter_rows(values_only=True):
            if header:
                header = False
                continue
            name = row[0]
            if name and isinstance(name, str) and name.strip():
                employers.add(name.strip().lower())
        wb.close()
        # Cache to JSON for faster reload
        with open(EMPLOYER_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(list(employers), f, ensure_ascii=False)
        print(f"[Ireland Permits] Loaded {len(employers)} employers from Excel")
    except Exception as e:
        print(f"[Ireland Permits] Excel load error: {e}")
    return employers


# ---- Load (from cache or Excel) ----
@lru_cache(maxsize=1)
def _get_excel_employers() -> frozenset[str]:
    """Return cached frozenset of employer names from Excel."""
    # Try JSON cache first
    if os.path.exists(EMPLOYER_JSON_PATH):
        try:
            with open(EMPLOYER_JSON_PATH, encoding="utf-8") as f:
                data = json.load(f)
                employers = frozenset(s.lower() for s in data if s and s.strip())
                print(f"[Ireland Permits] Loaded {len(employers)} employers from cache")
                return employers
        except Exception:
            pass
    # Fall back to Excel
    employers = _build_excel_set()
    return frozenset(employers)


def check_excel(company: str) -> bool:
    """True if company is in the 2024 work permits Excel list."""
    if not company:
        return False
    return company.strip().lower() in _get_excel_employers()


def _fuzzy_match(query: str, name_list: list[str]) -> bool:
    """Check if query matches any name in list (case-insensitive, strip)."""
    q = query.strip().lower()
    for n in name_list:
        if n.strip().lower() == q:
            return True
        # Also partial: query inside name or name inside query
        if q in n.strip().lower() or n.strip().lower() in q:
            return True
    return False


def check_api(company: str, timeout: int = 10) -> bool:
    """
    Fallback: query IrishTalents API to see if company has work permit.
    Returns True if found in API results.
    """
    if not company or len(company.strip()) < 2:
        return False
    try:
        resp = requests.get(
            API_URL,
            params={"skip": 0, "limit": 20, "search": company.strip()},
            headers={
                "accept": "*/*",
                "content-type": "application/json",
                "origin": "https://irishtalents.com",
                "referer": "https://irishtalents.com/",
                "x-api-key": API_KEY,
                "user-agent": "Mozilla/5.0 (compatible; JobTracker/1.0)",
            },
            timeout=timeout,
        )
        if resp.status_code != 200:
            return False
        data = resp.json()
        companies = data.get("data", []) or data
        if isinstance(companies, dict):
            companies = companies.get("data", [])
        # Return True if any company name matches our query
        return _fuzzy_match(company, [c.get("name", "") for c in companies if c])
    except Exception as e:
        print(f"[Ireland API] Error: {e}", file=sys.stderr)
        return False


_ireland_permit_cache: dict[str, bool] = {}
_ireland_api_disabled = False  # Circuit breaker


def has_ireland_work_permit(company: str) -> bool:
    """
    Main entry point: check Ireland work permit eligibility.
    Checks Excel first, then API as fallback (skipped if API is already disabled).
    Circuit breaker: if API times out once, all further API calls are skipped.
    """
    if company in _ireland_permit_cache:
        return _ireland_permit_cache[company]
    if check_excel(company):
        _ireland_permit_cache[company] = True
        return True
    global _ireland_api_disabled
    if _ireland_api_disabled:
        _ireland_permit_cache[company] = False
        return False
    try:
        if check_api(company, timeout=3):
            _ireland_permit_cache[company] = True
            return True
    except Exception:
        _ireland_api_disabled = True  # Disable API after first failure
    _ireland_permit_cache[company] = False
    return False


if __name__ == "__main__":
    # CLI test
    import argparse
    parser = argparse.ArgumentParser(description="Check Ireland work permit eligibility")
    parser.add_argument("company", nargs="?", help="Company name to check")
    args = parser.parse_args()

    if args.company:
        result = has_ireland_work_permit(args.company)
        print(f"{args.company}: {'✅ ELIGIBLE' if result else '❌ NOT FOUND'}")
    else:
        # Run quick sanity check
        test_companies = ["Google", "Accenture", "Microsoft", "Unknown Corp", "IDA Ireland", "EPAM"]
        for c in test_companies:
            result = has_ireland_work_permit(c)
            print(f"  {'✅' if result else '❌'} {c}")
