"""Job deduplication logic (URL-based + title fuzzy dedup)."""

import hashlib
import re
from pathlib import Path


def _normalize_url(url: str) -> str:
    """Normalize LinkedIn URLs: strip tracking params (refId, trackingId, position, pageNum, etc.)
    LinkedIn URL format: https://[locale.]linkedin.com/jobs/view/<slug-id>?tracking_params
    We collapse all tracking-param variants to the same base URL.
    """
    url = url.strip()
    # Strip query string tracking params from LinkedIn job URLs
    # Pattern: https://[locale.]linkedin.com/jobs/view/<slug-id>?<anything>
    m = re.match(r'(?i)^(https://[\w.]+\.linkedin\.com/jobs/view/[^?]+)', url)
    if m:
        return m.group(1)
    return url


def generate_job_id(job: dict) -> str:
    """Generate a unique ID for a job based on URL or title+company+location."""
    url = job.get("url", "").strip()
    if url:
        normalized = _normalize_url(url)
        return hashlib.md5(normalized.encode()).hexdigest()[:12]
    key = f"{job.get('title', '')}-{job.get('company', '')}-{job.get('location', '')}"
    return hashlib.md5(key.encode()).hexdigest()[:12]


def _normalize_title(title: str) -> str:
    """Lowercase, strip punctuation for fuzzy title matching."""
    return re.sub(r"[^a-z0-9 ]", "", title.lower()).strip()


def deduplicate_jobs(jobs: list[dict]) -> list[dict]:
    """Remove duplicate jobs.

    Pass 1: deduplicate by URL (exact).
    Pass 2: deduplicate by normalized title, keeping the best source
            (linkedin > indeed > glassdoor > other).
    """
    SOURCE_RANK = {"linkedin": 0, "indeed": 1, "glassdoor": 2, "builtin": 3, "wellfound": 4, "jsearch": 5}

    # Pass 1: URL dedup (using normalized URL to collapse tracking-param variants)
    seen_urls: set[str] = set()
    url_unique: list[dict] = []
    for job in jobs:
        raw_url = job.get("url", "").strip()
        normalized = _normalize_url(raw_url)
        if normalized not in seen_urls:
            seen_urls.add(normalized)
            # Store both raw and normalized for later use
            job['_normalized_url'] = normalized
            url_unique.append(job)

    # Pass 2: title dedup — keep best-source version per unique title
    title_map: dict[str, dict] = {}
    for job in url_unique:
        key = _normalize_title(job.get("title", ""))
        if not key:
            continue
        if key not in title_map:
            title_map[key] = job
        else:
            existing_rank = SOURCE_RANK.get(title_map[key].get("source", ""), 99)
            new_rank = SOURCE_RANK.get(job.get("source", ""), 99)
            if new_rank < existing_rank:
                title_map[key] = job

    return list(title_map.values())
