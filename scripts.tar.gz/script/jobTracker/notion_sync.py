#!/usr/bin/env python3
"""
notion_sync.py — Sync scored jobs above threshold to Notion.
Creates a new Notion database with full schema if NOTION_JOB_DB_ID not set.
"""

import json
import sys
import os
import time
import pymysql
import requests
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common.config import load_config

CONFIG_PATH = "/home/cap/script/jobTracker/config.json"
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", "root2026pass"),
    "database": "job_tracker",
    "charset": "utf8mb4",
}
NOTION_API_KEY = os.environ.get(
    "NOTION_API_KEY",
    "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"
)
NOTION_HEADERS = {
    "Authorization": f"Bearer {NOTION_API_KEY}",
    "Notion-Version": "2022-06-28",
    "Content-Type": "application/json",
}


def notion_text(text: str) -> dict:
    return {"type": "text", "text": {"content": text[:2000]}}


def notion_url(url: str | None) -> dict:
    return {"type": "url", "url": url or None}


SOURCE_DISPLAY = {
    "linkedin": "LinkedIn",
    "indeed": "Indeed",
    "jobspy": "JobSpy",
    "jsearch": "JSearch",
    "smartproxy": "SmartProxy",
    "other": "Other",
}


NOTION_DB_PROPERTIES = {
    "Title":            {"title": {}},
    "Company":          {"rich_text": {}},
    "Location":         {"rich_text": {}},
    "URL":              {"url": {}},
    "Salary":           {"rich_text": {}},
    "Remote":           {"checkbox": {}},
    "IND Recognised Sponsor (NL Work Visa)": {"checkbox": {}},
    "Ireland Work Permit": {"checkbox": {}},
    "Employment Type":  {"rich_text": {}},
    "Posted Date":      {"date": {}},
    "Source":           {"select": {"options": [
        {"name": "LinkedIn", "color": "blue"},
        {"name": "Indeed", "color": "orange"},
        {"name": "JobSpy", "color": "blue"},
        {"name": "JSearch", "color": "green"},
        {"name": "SmartProxy", "color": "purple"},
        {"name": "Other", "color": "gray"},
    ]}},
    "Match Score":      {"number": {"format": "number"}},
    "Keyword Score":    {"number": {"format": "number"}},
    "Semantic Score":   {"number": {"format": "number"}},
    "Match Reason":     {"rich_text": {}},
    # Category breakdown
    "Technical Skills": {"number": {"format": "number"}},
    "Experience":       {"number": {"format": "number"}},
    "AI Agent":          {"number": {"format": "number"}},
    "Architecture":      {"number": {"format": "number"}},
    "Impact":            {"number": {"format": "number"}},
    "Education":         {"number": {"format": "number"}},
    # Analysis
    "Strengths":        {"rich_text": {}},
    "Gaps":              {"rich_text": {}},
    "Resume Suggestions":{"rich_text": {}},
    "ATS Present":       {"rich_text": {}},
    "ATS Missing":       {"rich_text": {}},
    # Status
    "Hiring Decision":  {"select": {"options": [
        {"name": "Strong Interview", "color": "green"},
        {"name": "Interview",        "color": "blue"},
        {"name": "Consider",          "color": "yellow"},
        {"name": "Reject",            "color": "red"},
        {"name": "Pending",           "color": "gray"},
        {"name": "Unevaluable",       "color": "brown"},
    ]}},
    "Applied":          {"checkbox": {}},
    "Status":           {"select": {"options": [
        {"name": "New",      "color": "green"},
        {"name": "Reviewed", "color": "yellow"},
        {"name": "Applied",  "color": "blue"},
        {"name": "Rejected", "color": "red"},
    ]}},
}


def create_notion_database(parent_page_id: str, title: str = "Job Tracker - Wei Zhu") -> str:
    payload = {
        "parent": {"type": "page_id", "page_id": parent_page_id},
        "title": [{"type": "text", "text": {"content": title}}],
        "properties": NOTION_DB_PROPERTIES,
        "children": [],
    }
    resp = requests.post("https://api.notion.com/v1/databases", headers=NOTION_HEADERS, json=payload)
    if resp.status_code != 200:
        print(f"[Notion] Create DB error: {resp.status_code} {resp.text}", file=sys.stderr)
        sys.exit(1)
    db = resp.json()
    print(f"[Notion] Created database: {db['id']}")
    return db["id"]


def notion_rich_text_list(items: list) -> list:
    """Convert a list of strings to Notion rich_text array."""
    text = ", ".join(items) if items else "-"
    return [{"type": "text", "text": {"content": text[:2000]}}]


def sync_jobs_to_notion():
    config = load_config(CONFIG_PATH)
    notion_db_id = os.environ.get("NOTION_JOB_DB_ID", "") or config.get("notion_database_id", "")
    if not notion_db_id:
        print("[Notion] NOTION_JOB_DB_ID not set. Run with --create-db to create a new database.")
        return 0
    threshold = config.get("scoring", {}).get("score_threshold", 50)

    conn = pymysql.connect(**MYSQL_CONFIG)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
        SELECT * FROM jobs
        WHERE match_score IS NOT NULL
          AND match_score >= %s
          AND (notion_page_id IS NULL OR notion_page_id = '')
        ORDER BY match_score DESC
        LIMIT 50
    """, (threshold,))
    jobs = cursor.fetchall()
    conn.close()

    if not jobs:
        print("[Notion] No new jobs to sync")
        return 0

    print(f"[Notion] Syncing {len(jobs)} jobs to {notion_db_id}")
    synced = 0

    for job in jobs:
        # Convert types for JSON serialization
        posted_raw = job["posted_date"]
        if posted_raw and str(posted_raw) not in ("0000-00-00", "None"):
            posted = str(posted_raw)
        else:
            posted = None
        match_score = float(job["match_score"]) if job["match_score"] is not None else 0.0
        keyword_score = float(job["keyword_score"]) if job["keyword_score"] is not None else 0.0
        semantic_score = float(job["semantic_score"]) if job["semantic_score"] is not None else 0.0
        technical_skills = float(job["technical_skills_score"] or 0)
        experience = float(job["experience_score"] or 0)
        ai_agent = float(job["ai_agent_score"] or 0)
        architecture = float(job["architecture_score"] or 0)
        impact = float(job["impact_score"] or 0)
        education = float(job["education_score"] or 0)

        # Parse ATS keywords
        try:
            ats_present = json.loads(job["ats_keywords_present"]) if job["ats_keywords_present"] else []
            ats_missing = json.loads(job["ats_keywords_missing"]) if job["ats_keywords_missing"] else []
        except Exception:
            ats_present, ats_missing = [], []

        # Hiring decision display
        decision_map = {
            "strong_interview": "Strong Interview",
            "interview": "Interview",
            "consider": "Consider",
            "reject": "Reject",
            "pending": "Pending",
            "unevaluable": "Unevaluable",
        }
        decision_display = decision_map.get(job["hiring_decision"] or "", "Consider")

        # Strengths / gaps (truncate each to 500 chars)
        def join_list(items, sep="; "):
            if not items:
                return "-"
            return sep.join(items)[:500]

        try:
            strengths = json.loads(job["strengths"]) if job["strengths"] else []
            gaps = json.loads(job["gaps"]) if job["gaps"] else []
            suggestions = json.loads(job["resume_suggestions"]) if job["resume_suggestions"] else []
        except Exception:
            strengths, gaps, suggestions = [], [], []

        payload = {
            "parent": {"database_id": notion_db_id},
            "properties": {
                "Title":            {"title": [notion_text(job["title"])]},
                "Company":          {"rich_text": [notion_text(job["company"] or "")]},
                "Location":         {"rich_text": [notion_text(job["location"] or "")]},
                "URL":              notion_url(job["url"]),
                "Salary":           {"rich_text": [notion_text(job["salary"] or "-")]},
                "Remote":           {"checkbox": bool(job["remote"])},
                "IND Recognised Sponsor (NL Work Visa)": {"checkbox": bool(job.get("ind_visa_sponsor", 0))},
                "Ireland Work Permit": {"checkbox": bool(job.get("ireland_work_permit", 0))},
                "Employment Type":  {"rich_text": [notion_text(job["employment_type"] or "-")]},
                "Posted Date":      {"date": {"start": posted}} if posted else {"date": None},
                "Source":           {"select": {"name": SOURCE_DISPLAY.get(job["source"], "Other")}},
                "Match Score":      {"number": match_score},
                "Keyword Score":    {"number": keyword_score},
                "Semantic Score":   {"number": semantic_score},
                "Match Reason":     {"rich_text": [notion_text(job["match_reason"] or "")]},
                "Technical Skills": {"number": technical_skills},
                "Experience":       {"number": experience},
                "AI Agent":         {"number": ai_agent},
                "Architecture":     {"number": architecture},
                "Impact":           {"number": impact},
                "Education":        {"number": education},
                "Strengths":        {"rich_text": notion_rich_text_list(strengths)},
                "Gaps":             {"rich_text": notion_rich_text_list(gaps)},
                "Resume Suggestions":{"rich_text": notion_rich_text_list(suggestions)},
                "ATS Present":      {"rich_text": [notion_text(", ".join(ats_present[:15]))]},
                "ATS Missing":      {"rich_text": [notion_text(", ".join(ats_missing[:15]))]},
                "Hiring Decision":  {"select": {"name": decision_display}},
                "Status":           {"select": {"name": "New"}},
            },
        }

        # Retry logic for connection errors
        max_retries = 3
        retry_delay = 2
        last_error = None
        for attempt in range(max_retries):
            try:
                resp = requests.post("https://api.notion.com/v1/pages", headers=NOTION_HEADERS, json=payload)
                if resp.status_code == 200:
                    page = resp.json()
                    page_id = page["id"]
                    conn2 = pymysql.connect(**MYSQL_CONFIG)
                    cur2 = conn2.cursor()
                    cur2.execute("UPDATE jobs SET notion_page_id=%s WHERE id=%s", (page_id, job["id"]))
                    conn2.commit()
                    conn2.close()
                    synced += 1
                    print(f"  [✓] {job['title'][:50]} | score={job['match_score']} | {decision_display}")
                    last_error = None
                    break
                elif resp.status_code == 429:
                    # Rate limited — retry after delay
                    retry_after = int(resp.headers.get("Retry-After", retry_delay * (attempt + 1)))
                    print(f"  [!] Rate limited, retrying in {retry_after}s... (attempt {attempt+1}/{max_retries})")
                    time.sleep(retry_after)
                    last_error = f"429: {resp.text[:100]}"
                    continue
                else:
                    print(f"  [✗] {job['title'][:50]}: {resp.status_code} {resp.text[:100]}")
                    last_error = f"{resp.status_code}: {resp.text[:100]}"
                    break
            except (ConnectionResetError, ConnectionRefusedError, ConnectionError) as e:
                last_error = e
                if attempt < max_retries - 1:
                    wait = retry_delay * (2 ** attempt)
                    print(f"  [!] Connection error, retrying in {wait}s... (attempt {attempt+1}/{max_retries})")
                    time.sleep(wait)
                else:
                    print(f"  [✗] {job['title'][:50]}: Connection error after {max_retries} retries: {e}")
            except Exception as e:
                print(f"  [✗] Error: {e}")
                last_error = e
                break

        if last_error and isinstance(last_error, (ConnectionResetError, ConnectionRefusedError, ConnectionError)):
            # Fallback: log to MySQL for manual retry later
            print(f"  [!] Skipped job saved for retry: {job['title'][:50]}")

    print(f"[Notion] Synced {synced}/{len(jobs)} jobs")
    return synced


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--create-db", help="Parent Notion page_id to create database under")
    args = parser.parse_args()

    if args.create_db:
        db_id = create_notion_database(args.create_db)
        print(f"\nCreated database ID: {db_id}")
        print(f"Add to config.json: \"notion_database_id\": \"{db_id}\"")
        print(f"Or set: export NOTION_JOB_DB_ID={db_id}")
    else:
        synced = sync_jobs_to_notion()
        print(f"Synced {synced} jobs to Notion")
