#!/usr/bin/env python3
"""
补抓 LinkedIn/Indeed 职位 description
LinkedIn: Playwright session (优先) -> SmartProxy (备援)
Indeed: SmartProxy -> scrapling
"""
import sys, re, time, json as _json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path
import os

import pymysql
from bs4 import BeautifulSoup

try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_OK = True
except Exception:
    PLAYWRIGHT_OK = False

try:
    from scrapling import Fetcher
except Exception:
    Fetcher = None

MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root2026pass",
    "database": "job_tracker",
    "charset": "utf8mb4",
}

PROXY = {'server': 'http://192.168.23.1:7890'}
SESSION_FILE = '/home/cap/script/jobTracker/linkedin_session.json'
UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
SMARTPROXY_AUTH = 'Basic c21hcnQtbzkyend4bGM5NHpkOmtEb1pqWFBmUmN2VEZQZmI='

MAX_WORKERS = 3
REQUEST_TIMEOUT = 20
MAX_RETRIES = 3

VALID_URL_PATTERNS = [
    "linkedin.com/jobs/view/",
    "indeed.com/viewjob",
    "indeed.com/job/",
]

def _is_valid_job_url(url):
    return any(p in str(url) for p in VALID_URL_PATTERNS)

def _get_linkedin_search_query(url):
    """从 LinkedIn URL 提取搜索关键词。"""
    slug = url.split("/jobs/view/")[-1] if "/jobs/view/" in url else ""
    slug = slug.split("?")[0]
    parts = slug.split("-at-")
    if len(parts) >= 2:
        title_part = parts[0].replace("-", " ")
        company_part = parts[1].split("-")[0].replace("-", " ")
        return title_part + " " + company_part
    return slug.replace("-", " ")

def _fetch_via_linkedin_session(url):
    """用 Playwright + LinkedIn session cookie 抓取 description。"""
    if not os.path.exists(SESSION_FILE):
        print("[LI] No session file")
        return None
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, proxy=PROXY)
            context = browser.new_context(
                locale="en-US",
                proxy=PROXY,
                user_agent=UA,
            )
            state = _json.loads(open(SESSION_FILE).read())
            context.add_cookies(state['cookies'])
            page = context.new_page()
            # 不再预检验 session，直接搜 job
            query = _get_linkedin_search_query(url)
            if not query:
                print("[LI] No query from URL")
                browser.close()
                return None
            search_url = "https://www.linkedin.com/jobs/search/?keywords=" + query.replace(" ", "+")
            page.goto(search_url, timeout=20000)
            time.sleep(3)
            page.keyboard.press('Escape')
            time.sleep(1)
            # 检查是否 sign-in wall
            if "login" in page.url or "checkpoint" in page.url:
                print("[LI] Session invalid/expired")
                browser.close()
                return None
            # 检查是否有 job 结果
            job_links = page.locator("a[href*=jobs/view/]")
            count = job_links.count()
            if count == 0:
                print("[LI] No jobs found for: " + query)
                browser.close()
                return None
            print("[LI] Found " + str(count) + " jobs for: " + query)
            job_links.first.click()
            time.sleep(4)
            if "login" in page.url or "checkpoint" in page.url:
                print("[LI] Session expired on detail page")
                browser.close()
                return None
            try:
                desc_el = page.locator(".description__text--rich").first
                desc = desc_el.inner_text(timeout=8000)
                if desc and len(desc) > 50:
                    print("[LI] OK len=" + str(len(desc)))
                    browser.close()
                    return desc[:8000]
            except Exception as e:
                print("[LI] Desc error: " + str(e)[:60])
            browser.close()
            return None
    except Exception as e:
        print("[LI] Error: " + str(e)[:80])
        return None

def fetch_description(job):
    """抓取单个职位的 description。"""
    job_id, url = job
    if not url or not _is_valid_job_url(url):
        return (job_id, url, None)
    # LinkedIn: 先试 Playwright session
    if "linkedin.com" in url and PLAYWRIGHT_OK:
        desc = _fetch_via_linkedin_session(url)
        if desc:
            return (job_id, url, desc)
    # SmartProxy (含 451 降级)
    desc = _fetch_smartproxy(url)
    if desc:
        return (job_id, url, desc)
    # scrapling 兜底
    if Fetcher:
        desc = _fetch_via_scrapling(url)
        if desc:
            return (job_id, url, desc)
    return (job_id, url, None)

def _fetch_smartproxy(url):
    """通过 SmartProxy 抓取，451 直接跳过（proxy 无法处理 CN 域名）。"""
    import requests as _req
    geo = "US" if "indeed.com" in url else "NL"
    payload = {
        "geo": geo,
        "locale": "en-US",
        "js_render": True,
        "format": ["html"],
        "context": {"url": url},
        "source": "uni_scraper",
    }
    for attempt in range(MAX_RETRIES):
        try:
            resp = _req.post(
                "https://scraper.smartproxy.org/v1/query",
                headers={
                    "Authorization": SMARTPROXY_AUTH,
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=REQUEST_TIMEOUT,
            )
            # 451 = geographic restriction (CN domain)，直接跳过
            if resp.status_code == 451:
                print("[SP] 451 skip: " + url[:60])
                return None
            if resp.status_code in (429,):
                time.sleep((attempt + 1) * 5)
                continue
            if resp.status_code != 200:
                return None
            desc = _parse_description(resp.text)
            if desc:
                return desc
            if attempt < MAX_RETRIES - 1:
                time.sleep(2)
        except Exception:
            if attempt < MAX_RETRIES - 1:
                time.sleep(2)
            continue
    return None

def _fetch_via_scrapling(url):
    if Fetcher is None:
        return None
    try:
        page = Fetcher.get(url, timeout=REQUEST_TIMEOUT)
        return _parse_description(str(page.html_content))
    except Exception:
        return None

def _parse_description(html):
    """从 HTML 提取职位描述文本。"""
    soup = BeautifulSoup(html, 'html.parser')
    for cls in ["description__text--rich", "show-more-less-html"]:
        elem = soup.find('div', class_=cls) or soup.find('section', class_=cls)
        if elem:
            text = elem.get_text(separator=" ", strip=True)
            text = " ".join(text.split())
            if len(text) > 50:
                return text[:8000]
    elem = soup.find("div", class_=lambda x: x and "description" in x if x else False)
    if elem:
        text = elem.get_text(separator=" ", strip=True)
        text = " ".join(text.split())
        if len(text) > 50:
            return text[:8000]
    for elem in soup.find_all("div", {"id": "jobDescriptionText"}):
        text = elem.get_text(separator=" ", strip=True)
        text = " ".join(text.split())
        if len(text) > 50:
            return text[:8000]
    elem = soup.find("div", class_="jobsearch-JobComponent")
    if elem:
        text = elem.get_text(separator=" ", strip=True)
        text = " ".join(text.split())
        if len(text) > 50:
            return text[:8000]
    return None

def main():
    today_str = date.today().isoformat()
    conn = pymysql.connect(**MYSQL_CONFIG)
    cur = conn.cursor()
    cur.execute(
        "SELECT id, url FROM jobs "
        "WHERE source IN ('linkedin', 'indeed') "
        "AND (description IS NULL OR description = '' ) "
        "AND DATE(scraped_at) >= DATE_SUB(CURDATE(), INTERVAL 2 DAY) "
        "LIMIT 200"
    )
    all_jobs = [(row[0], row[1]) for row in cur.fetchall()]
    jobs = [(jid, url) for jid, url in all_jobs if _is_valid_job_url(url)]
    skipped = len(all_jobs) - len(jobs)
    print(f"[{today_str}] Found {len(jobs)} jobs (+ {skipped} skipped)")
    if not jobs:
        conn.close()
        return
    updated = 0
    batch = []
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(fetch_description, job): job for job in jobs}
        for future in as_completed(futures):
            result = future.result()
            if result and result[2]:
                job_id, url, desc = result
                batch.append((desc, job_id))
                updated += 1
                print(f"[{updated}] job_id={job_id}: {desc[:60]}...")
            if len(batch) >= 20:
                cur.executemany(
                    "UPDATE jobs SET description=%s, match_score=NULL WHERE id=%s",
                    batch
                )
                conn.commit()
                batch.clear()
    if batch:
        cur.executemany(
            "UPDATE jobs SET description=%s, match_score=NULL WHERE id=%s",
            batch
        )
        conn.commit()
    conn.close()
    print(f"Done: {updated}/{len(jobs)} descriptions fetched")

if __name__ == '__main__':
    main()