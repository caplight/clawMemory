-- JobTracker: job postings from JobSpy + JSearch
CREATE DATABASE IF NOT EXISTS job_tracker;
USE job_tracker;

CREATE TABLE IF NOT EXISTS jobs (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(500) NOT NULL,
    source          VARCHAR(50) NOT NULL COMMENT 'linkedin | indeed | jsearch | other',
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    url             VARCHAR(1000) DEFAULT NULL,
    company         VARCHAR(500) DEFAULT NULL,
    location        VARCHAR(500) DEFAULT NULL,
    description     TEXT DEFAULT NULL,
    salary          VARCHAR(200) DEFAULT NULL,
    employment_type VARCHAR(100) DEFAULT NULL,
    remote          TINYINT(1) DEFAULT 0,
    ind_visa_sponsor TINYINT(1) DEFAULT 0,
    ireland_work_permit TINYINT(1) DEFAULT 0,
    posted_date     DATE DEFAULT NULL,
    scraped_at      DATETIME DEFAULT CURRENT_TIMESTAMP,

    -- Scoring
    match_score             DECIMAL(5,2) DEFAULT NULL COMMENT '总分 0-100',
    keyword_score           DECIMAL(5,2) DEFAULT NULL COMMENT '关键词评分 0-100',
    semantic_score          DECIMAL(5,2) DEFAULT NULL COMMENT '语义评分 0-100',
    match_reason            TEXT DEFAULT NULL,

    -- Category breakdown
    technical_skills_score  DECIMAL(5,2) DEFAULT NULL,
    experience_score        DECIMAL(5,2) DEFAULT NULL,
    ai_agent_score          DECIMAL(5,2) DEFAULT NULL,
    architecture_score      DECIMAL(5,2) DEFAULT NULL,
    impact_score            DECIMAL(5,2) DEFAULT NULL,
    education_score         DECIMAL(5,2) DEFAULT NULL,

    -- Analysis
    strengths               TEXT DEFAULT NULL,
    gaps                    TEXT DEFAULT NULL,
    resume_suggestions      TEXT DEFAULT NULL,
    hiring_decision         VARCHAR(50) DEFAULT NULL COMMENT 'reject | consider | interview | strong_interview',
    ats_keywords_present    TEXT DEFAULT NULL COMMENT 'JSON array',
    ats_keywords_missing    TEXT DEFAULT NULL COMMENT 'JSON array',

    notion_page_id          VARCHAR(200) DEFAULT NULL,
    created_at              DATETIME DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uk_url (url(500)),
    INDEX idx_source (source),
    INDEX idx_posted (posted_date),
    INDEX idx_score (match_score),
    INDEX idx_is_read (is_read),
    INDEX idx_hiring_decision (hiring_decision)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Note: description, ind_visa_sponsor, ireland_work_permit columns already exist in CREATE TABLE above.
-- These ALTER TABLE statements are removed (MySQL does not support ADD COLUMN IF NOT EXISTS
-- and columns were already created by the CREATE TABLE statement above).
