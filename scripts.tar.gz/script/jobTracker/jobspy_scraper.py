#!/usr/bin/env python3
"""
JobSpy Job Scraper for Job Tracker.
Searches LinkedIn via python-jobspy (no API key).
Supports multiple locations (Netherlands, Ireland, etc.) per keyword.
Output: list of normalized job dicts.

Patches applied:
- f_SB2=1: Forces LinkedIn to sort by date descending (newest first)
  (Without this, anonymous API returns results sorted by "relevance" which
   often filters out very recent postings)
- Optional Li_AT cookie injection: Uses authenticated session to get
  the same results as the logged-in UI.
"""

import json
import sys
import math
import random
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse, urlunparse

sys.path.insert(0, str(Path(__file__).parent))

from common.config import load_config
from common.dedup import deduplicate_jobs, generate_job_id

DOMAIN_TO_SITE = {
    "linkedin.com": "linkedin",
    "indeed.com": "indeed",
    "glassdoor.com": "glassdoor",
    "zip_recruiter.com": "zip_recruiter",
    "ziprecruiter.com": "zip_recruiter",
}
DEFAULT_SITES = ["linkedin"]

TIME_RANGE_TO_HOURS = {
    "day": 24,
    "week": 168,
    "month": 720,
    "year": 8760,
}

# Global cookie store — set from config before scraping starts
_LINKEDIN_COOKIE = None

# ----------------------------------------------------------------------
# Monkey-patch: inject f_SB2=1 + optional Li_AT auth
# into JobSpy's LinkedIn scraper so anonymous API returns recent posts.
# ----------------------------------------------------------------------
def _apply_jobspy_patches():
    """
    Patches LinkedIn.scrape to:
    1. Force f_SB2=1  (sort by date desc, newest first)
    2. Inject Li_AT cookie for authenticated requests (if provided)
    Must be called BEFORE any scrape_fn() invocation.
    """
    try:
        from jobspy.linkedin import LinkedIn as _LinkedIn
        from jobspy.linkedin.util import job_type_code
        from jobspy.model import JobResponse, ScraperInput
        from jobspy.linkedin import log  # module-level logger from jobspy
        from bs4 import BeautifulSoup
    except Exception as e:
        print(f"[JobSpy Patch] Could not import jobspy modules: {e}")
        return

    # Save original __init__ and scrape
    _orig_init = _LinkedIn.__init__
    _orig_scrape = _LinkedIn.scrape

    def _patched_init(self, proxies=None, ca_cert=None, user_agent=None):
        _orig_init(self, proxies=proxies, ca_cert=ca_cert, user_agent=user_agent)
        # Inject full cookie string if provided (may contain li_at + PerimeterX + others)
        cookie_str = _LINKEDIN_COOKIE
        if cookie_str:
            # Parse and set all cookies from the full cookie string
            for part in cookie_str.split(";"):
                part = part.strip()
                if "=" in part:
                    name, _, value = part.partition("=")
                    name = name.strip()
                    value = value.strip().strip('"')
                    if name and value:
                        self.session.cookies.set(name, value, domain=".linkedin.com")
            # Extract csrf-token from li_at for API calls
            import re
            m = re.search(r'li_at=([A-Za-z0-9_-]+)', cookie_str)
            if m:
                self.session.headers.update({"Csrf-Token": m.group(1)[-16:]})

    def _patched_scrape(self, scraper_input: ScraperInput) -> JobResponse:
        """
        Patched LinkedIn.scrape — identical to original with ONE change:
        params["f_SB2"] = 1 is always added (sort by date desc).
        """
        self.scraper_input = scraper_input
        job_list = []
        seen_ids = set()
        start = scraper_input.offset // 10 * 10 if scraper_input.offset else 0
        request_count = 0
        seconds_old = (
            scraper_input.hours_old * 3600 if scraper_input.hours_old else None
        )
        continue_search = (
            lambda: len(job_list) < scraper_input.results_wanted and start < 1000
        )
        while continue_search():
            request_count += 1
            log.info(
                f"search page: {request_count} / {math.ceil(scraper_input.results_wanted / 10)}"
            )
            params = {
                "keywords": scraper_input.search_term,
                "location": scraper_input.location,
                "distance": scraper_input.distance,
                "f_WT": 2 if scraper_input.is_remote else None,
                "f_JT": (
                    job_type_code(scraper_input.job_type)
                    if scraper_input.job_type
                    else None
                ),
                "pageNum": 0,
                "start": start,
                "f_AL": "true" if scraper_input.easy_apply else None,
                "f_C": (
                    ",".join(map(str, scraper_input.linkedin_company_ids))
                    if scraper_input.linkedin_company_ids
                    else None
                ),
            }
            if seconds_old is not None:
                params["f_TPR"] = f"r{seconds_old}"

            # ---- PATCH: force date-sort so recent posts appear anonymously ----
            params["f_SB2"] = 1  # Sort by date desc (newest first)

            params = {k: v for k, v in params.items() if v is not None}
            try:
                response = self.session.get(
                    f"{self.base_url}/jobs-guest/jobs/api/seeMoreJobPostings/search?",
                    params=params,
                    timeout=10,
                )
                if response.status_code not in range(200, 400):
                    if response.status_code == 429:
                        err = (
                            "429 Response - Blocked by LinkedIn for too many requests"
                        )
                    else:
                        err = f"LinkedIn response status code {response.status_code}"
                        err += f" - {response.text[:200]}"
                    log.error(err)
                    return JobResponse(jobs=job_list)
            except Exception as e:
                if "Proxy responded with" in str(e):
                    log.error("LinkedIn: Bad proxy")
                else:
                    log.error(f"LinkedIn: {str(e)}")
                return JobResponse(jobs=job_list)

            soup = BeautifulSoup(response.text, "html.parser")
            job_cards = soup.find_all("div", class_="base-search-card")
            if len(job_cards) == 0:
                return JobResponse(jobs=job_list)

            for job_card in job_cards:
                href_tag = job_card.find("a", class_="base-card__full-link")
                if href_tag and "href" in href_tag.attrs:
                    href = href_tag.attrs["href"].split("?")[0]
                    job_id = href.split("-")[-1]

                    if job_id in seen_ids:
                        continue
                    seen_ids.add(job_id)

                    try:
                        fetch_desc = scraper_input.linkedin_fetch_description
                        job_post = self._process_job(job_card, job_id, fetch_desc)
                        if job_post:
                            job_list.append(job_post)
                        if not continue_search():
                            break
                    except Exception as e:
                        from jobspy.exception import LinkedInException
                        raise LinkedInException(str(e))

            if continue_search():
                time.sleep(random.uniform(self.delay, self.delay + self.band_delay))
                start += len(job_list)

        job_list = job_list[: scraper_input.results_wanted]
        return JobResponse(jobs=job_list)

    _LinkedIn.__init__ = _patched_init
    _LinkedIn.scrape = _patched_scrape
    print("[JobSpy Patch] f_SB2=1 + Li_AT injection patched into LinkedIn.scrape")


# Apply patches ONCE at module load
_apply_jobspy_patches()


def _jobspy_import():
    try:
        from jobspy import scrape_jobs
        return scrape_jobs
    except ImportError:
        raise RuntimeError(
            "python-jobspy not installed. Run: pip install python-jobspy"
        )


NL_LOCATIONS = ["amsterdam", "rotterdam", "the hague", "utrecht", "groningen", "maastricht", "delft", "eindhoven", "tilburg", "amersfoort", "netherlands", "holland"]
IE_LOCATIONS = ["dublin", "cork", "galway", "limerick", "waterford", "kilkenny", "maynooth", "ireland"]

def _domains_to_sites(domains):
    sites = []
    for d in domains:
        site = DOMAIN_TO_SITE.get(d)
        if not site:
            for key, val in DOMAIN_TO_SITE.items():
                if d.startswith(key):
                    site = val
                    break
        if site and site not in sites:
            sites.append(site)
    return sites or DEFAULT_SITES


def _location_to_country_indeed(location: str) -> str:
    """Map a location string to the appropriate country_indeed value for JobSpy."""
    loc_lower = location.lower().strip()
    for nl_loc in NL_LOCATIONS:
        if nl_loc in loc_lower or loc_lower in nl_loc:
            return "netherlands"
    for ie_loc in IE_LOCATIONS:
        if ie_loc in loc_lower or loc_lower in ie_loc:
            return "ireland"
    return "usa"


def _format_salary(row) -> str:
    try:
        min_amt = row.get("min_amount")
        max_amt = row.get("max_amount")
        interval = row.get("interval") or ""
        currency = row.get("currency") or "USD"
        if min_amt and max_amt:
            return f"${int(min_amt):,}–${int(max_amt):,} {interval}".strip()
        elif min_amt:
            return f"${int(min_amt):,}+ {interval}".strip()
        elif max_amt:
            return f"up to ${int(max_amt):,} {interval}".strip()
    except Exception:
        pass
    return ""


def _str(val) -> str:
    if val is None:
        return ""
    if isinstance(val, float) and math.isnan(val):
        return ""
    return str(val)


def _summarize_errors(errors: list[str], limit: int = 3) -> str:
    if not errors:
        return ""
    sample = errors[:limit]
    remainder = len(errors) - len(sample)
    summary = " | ".join(sample)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary


def normalize_jobspy_row(row: dict) -> dict:
    url = _str(row.get("job_url") or row.get("job_url_direct"))
    title = _str(row.get("title"))
    company = _str(row.get("company"))
    location = _str(row.get("location"))
    description = _str(row.get("description"))
    site = _str(row.get("site")) or "linkedin"
    posted_date = row.get("date_posted")

    if posted_date and hasattr(posted_date, "isoformat"):
        posted_date = posted_date.isoformat()
    elif posted_date:
        posted_date = str(posted_date)
    else:
        posted_date = ""

    is_remote_flag = row.get("is_remote")
    remote = bool(is_remote_flag) or "remote" in (title + " " + location).lower()

    job = {
        "title": title,
        "company": company,
        "location": location,
        "description": description,
        "url": url,
        "posted_date": posted_date,
        "salary": _format_salary(row),
        "employment_type": _str(row.get("job_type")),
        "remote": remote,
        "source": site,
        "scraped_at": datetime.now().isoformat(),
    }
    job["id"] = generate_job_id(job)
    return job


def scrape_jobs(
    config: dict,
    keywords: list[str] | None = None,
    location: str | None = None,
    max_workers: int = 3,
    return_details: bool = False,
) -> list[dict] | tuple[list[dict], dict]:
    """Search jobs using JobSpy with parallel requests across keywords × locations."""
    import concurrent.futures
    scrape_fn = _jobspy_import()
    search_cfg = config.get("search", {})
    keywords_list = keywords or search_cfg.get("keywords", [])
    # If caller passes a single location string (e.g. from CLI), use it alone;
    # otherwise fall back to the config list.
    loc = location or search_cfg.get("location", "")
    locations = [loc] if loc else search_cfg.get("locations", [])
    time_range = search_cfg.get("time_range", "week")
    hours_old = TIME_RANGE_TO_HOURS.get(time_range, 168)
    results_wanted = search_cfg.get("max_results_per_query_jobspy", 20)
    domains = search_cfg.get("job_domains", [])
    sites = _domains_to_sites(domains)
    proxy = search_cfg.get("proxy", None)

    global _LINKEDIN_COOKIE
    _LINKEDIN_COOKIE = search_cfg.get("linkedin_cookie", None)
    if _LINKEDIN_COOKIE:
        print(f"[JobSpy] Using LinkedIn authenticated session (Li_AT cookie present)")
    else:
        print(f"[JobSpy] No Li_AT cookie — using anonymous session")

    print(f"[JobSpy] Sites: {sites} | Time range: {time_range} ({hours_old}h) | Results/query: {results_wanted}")
    if proxy:
        print(f"[JobSpy] Proxy: {proxy}")
    print(f"[JobSpy] Locations: {locations} | Workers: {max_workers}")

    tasks = [
        (kw, ql)
        for kw in keywords_list
        for ql in locations
        if ql
    ]
    print(f"[JobSpy] Total tasks: {len(tasks)} (keywords × locations)")

    if not tasks:
        print("[JobSpy] No keyword/location tasks configured")
        details = {"task_count": 0, "error_count": 0, "errors": []}
        return ([], details) if return_details else []

    def _fetch(kw_loc):
        kw, query_loc = kw_loc
        # Pick the correct Indeed country for this location
        country = _location_to_country_indeed(query_loc)
        error_message = None
        try:
            df = scrape_fn(
                site_name=["indeed"],
                search_term=kw,
                location=query_loc,
                results_wanted=results_wanted,
                hours_old=hours_old,
                country_indeed=country,
                linkedin_fetch_description=True,
                verbose=0,
                proxy=proxy,
            )
            rows = df.to_dict(orient="records") if df is not None and len(df) > 0 else []
        except Exception as e:
            error_message = f"'{kw}' @ '{query_loc}': {e}"
            print(f"[JobSpy] Error for {error_message}", file=sys.stderr)
            rows = []
        normalized = [normalize_jobspy_row(r) for r in rows]
        return kw, query_loc, normalized, error_message

    all_jobs = []
    errors = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_kwloc = {executor.submit(_fetch, t): t for t in tasks}
        for future in concurrent.futures.as_completed(future_to_kwloc):
            kw, query_loc = future_to_kwloc[future]
            try:
                kw, query_loc, normalized, error_message = future.result()
            except Exception as e:
                error_message = f"'{kw}' @ '{query_loc}': {e}"
                print(f"[JobSpy] Error for {error_message}", file=sys.stderr)
                normalized = []
            all_jobs.extend(normalized)
            print(f"[JobSpy] ✓ '{kw}' @ '{query_loc}' → {len(normalized)} postings")
            if error_message:
                errors.append(error_message)

    all_jobs = deduplicate_jobs(all_jobs)
    all_jobs.sort(key=lambda j: j.get("posted_date", ""), reverse=True)
    print(f"[JobSpy] Total after dedup: {len(all_jobs)}")
    details = {
        "task_count": len(tasks),
        "error_count": len(errors),
        "errors": errors,
        "error_summary": _summarize_errors(errors),
    }
    if return_details:
        return all_jobs, details
    return all_jobs


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Search jobs via JobSpy")
    parser.add_argument("--config", default="/home/cap/script/jobTracker/config.json")
    parser.add_argument("--keywords", nargs="+")
    parser.add_argument("--location")
    parser.add_argument("--output", "-o")
    args = parser.parse_args()

    config = load_config(args.config)
    jobs = scrape_jobs(config, keywords=args.keywords, location=args.location)

    output = json.dumps(jobs, indent=2, default=str)
    if args.output:
        with open(args.output, "w") as f:
            f.write(output)
        print(f"Saved {len(jobs)} jobs to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[JobSpy] Fatal error: {e}", file=sys.stderr)
        sys.exit(1)
