#!/usr/bin/env python3
"""
LinkedIn Jobs Scraper using Playwright.
Logs in with credentials, navigates to jobs search, scrolls to load results,
extracts job listings.

Session is persisted to linkedin_session.json so we don't re-login every run.
"""

import json
import sys
import time
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

sys.path.insert(0, str(Path(__file__).parent))

from common.config import load_config
from common.dedup import deduplicate_jobs, generate_job_id

try:
    from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout
    PLAYWRIGHT_IMPORT_ERROR = None
except ImportError as e:
    sync_playwright = None
    PlaywrightTimeout = TimeoutError
    PLAYWRIGHT_IMPORT_ERROR = e

LINKEDIN_JOBS_URL = "https://www.linkedin.com/jobs/search/"
SESSION_FILE = "/home/cap/script/jobTracker/linkedin_session.json"
PROXY = {'server': 'http://192.168.23.1:7890'}


def _require_playwright():
    if sync_playwright is None:
        raise RuntimeError(
            "playwright not installed. Run: pip install playwright && "
            "python -m playwright install chromium"
        ) from PLAYWRIGHT_IMPORT_ERROR


def _summarize_errors(errors: list[str], limit: int = 3) -> str:
    if not errors:
        return ""
    sample = errors[:limit]
    remainder = len(errors) - len(sample)
    summary = " | ".join(sample)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary


def load_session_file():
    f = Path(SESSION_FILE)
    if f.exists():
        try:
            return json.loads(f.read_text())
        except Exception:
            pass
    return None


def save_session_file(data):
    Path(SESSION_FILE).write_text(json.dumps(data, indent=2))


def get_stored_credentials(config: dict) -> tuple[str, str]:
    """Extract LinkedIn credentials from config."""
    creds = config.get("linkedin", {})
    username = creds.get("username") or creds.get("email")
    password = creds.get("password")
    return username, password


def login_and_get_cookies(playwright, config: dict) -> dict:
    """
    Logs into LinkedIn using username/password.
    Saves cookies/context to SESSION_FILE so subsequent runs can reuse session.
    Returns context storage state dict.
    """
    username, password = get_stored_credentials(config)
    if not username or not password:
        raise ValueError("LinkedIn credentials not found in config.json under 'linkedin.{username, password}'")

    print(f"[LinkedIn] Logging in as {username} ...")
    browser = playwright.chromium.launch(headless=True, proxy=PROXY)
    context = browser.new_context(
        proxy=PROXY,
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
        locale="en-US",
        viewport={"width": 1280, "height": 800},
    )
    page = context.new_page()

    # Go to login page
    page.goto("https://www.linkedin.com/login", timeout=30000, wait_until="domcontentloaded")
    page.wait_for_selector("#username", timeout=15000)
    time.sleep(1)  # Let JS hydrate the form

    # Fill username
    page.fill("#username", username)
    time.sleep(0.5)
    # Fill password
    page.fill("#password", password)
    time.sleep(0.5)
    # Click sign in
    page.click('button[type="submit"]')

    # Wait for redirect after login
    try:
        page.wait_for_load_state("domcontentloaded", timeout=20000)
        time.sleep(2)
    except PlaywrightTimeout:
        pass

    current_url = page.url
    print(f"[LinkedIn] After login URL: {current_url}")

    # Check for checkpoint (CAPTCHA / phone verification)
    if "checkpoint" in current_url or "feed" not in current_url:
        print("[LinkedIn] ⚠️  Checkpoint/CAPTCHA detected. Please solve manually in the browser.")
        print("[LinkedIn] Waiting 60s for you to solve...")
        # Save context so user can try to reload manually
        state = context.storage_state()
        save_session_file(state)
        browser.close()
        raise RuntimeError("CAPTCHA/checkpoint detected — please run with --reauth to re-authenticate")

    # Save cookies for next time
    state = context.storage_state()
    save_session_file(state)
    print(f"[LinkedIn] ✓ Logged in. Session saved to {SESSION_FILE}")
    browser.close()
    return state


def search_jobs(
    config: dict,
    keywords: list[str] | None = None,
    location: str | None = None,
    hours_old: int = 24,
    max_results: int = 50,
    return_details: bool = False,
) -> list[dict] | tuple[list[dict], dict]:
    """
    Searches LinkedIn jobs using Playwright with real browser.
    Uses persisted session from SESSION_FILE if available.
    """
    _require_playwright()
    search_cfg = config.get("search", {})
    keywords_list = keywords or search_cfg.get("keywords", [])
    locations = search_cfg.get("locations", [])
    if location:
        locations = [location]
    if not locations:
        locations = ["Netherlands"]

    def _new_context(playwright, storage_state=None):
        browser = playwright.chromium.launch(headless=True, proxy=PROXY)
        context = browser.new_context(
            proxy=PROXY,
            storage_state=storage_state,
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
            locale="en-US",
            viewport={"width": 1280, "height": 800},
        )
        return browser, context

    tasks = [(kw, loc) for loc in locations for kw in keywords_list if kw and loc]
    if not tasks:
        print("[LinkedIn] No keyword/location tasks configured")
        details = {"task_count": 0, "error_count": 0, "errors": []}
        return ([], details) if return_details else []

    errors = []
    with sync_playwright() as p:
        # Try to load existing session first
        stored = load_session_file()
        context = None
        browser = None
        if stored:
            try:
                print("[LinkedIn] Reusing stored session...")
                browser, context = _new_context(p, storage_state=stored)
                page = context.new_page()
                page.goto("https://www.linkedin.com/feed", timeout=15000)
                page.wait_for_load_state("networkidle", timeout=10000)
                if "checkpoint" in page.url or "login" in page.url:
                    print("[LinkedIn] Session expired — re-logging in...")
                    context.close()
                    browser.close()
                    context = None
                    browser = None
                    stored = None
                else:
                    print("[LinkedIn] ✓ Session still valid")
                    context.close()
                    browser.close()
                    context = None
                    browser = None
            except Exception as e:
                print(f"[LinkedIn] Session reuse failed: {e}")
                if context:
                    context.close()
                    context = None
                if browser:
                    browser.close()
                    browser = None
                stored = None

        if stored:
            browser, context = _new_context(p, storage_state=stored)
        else:
            # Login fresh
            state = login_and_get_cookies(p, config)
            browser, context = _new_context(p, storage_state=state)

        all_jobs = []
        for loc in locations:
            for kw in keywords_list:
                if not kw or not loc:
                    continue
                try:
                    jobs = _scrape_keyword_location(context, kw, loc, hours_old, max_results)
                except Exception as e:
                    jobs = []
                    errors.append(f"'{kw}' @ '{loc}': {e}")
                    print(f"[LinkedIn] Error for '{kw}' @ '{loc}': {e}", file=sys.stderr)
                all_jobs.extend(jobs)
                print(f"[LinkedIn] '{kw}' @ '{loc}' → {len(jobs)} jobs")

        context.close()
        browser.close()

    all_jobs = deduplicate_jobs(all_jobs)
    all_jobs.sort(key=lambda j: j.get("posted_date", ""), reverse=True)
    print(f"[LinkedIn] Total after dedup: {len(all_jobs)}")
    details = {
        "task_count": len(tasks),
        "error_count": len(errors),
        "errors": errors,
        "error_summary": _summarize_errors(errors),
    }
    if return_details:
        return all_jobs, details
    return all_jobs


def _scrape_keyword_location(context, keyword: str, location: str, hours_old: int, max_results: int) -> list[dict]:
    """
    Navigates to LinkedIn jobs search for a keyword+location, scrolls to load
    results, and extracts job cards.
    """
    page = context.new_page()

    # Build URL with filters
    # f_TPR=r{hours_old * 3600} = time filter
    seconds_old = hours_old * 3600
    url = (
        f"{LINKEDIN_JOBS_URL}?keywords={quote_plus(keyword)}"
        f"&location={quote_plus(location)}"
        f"&f_TPR=r{seconds_old}"
        f"&f_SB2=1"  # Sort by date
        f"&sortBy=DD"
    )
    print(f"[LinkedIn] Navigating to: {url}")
    page.goto(url, timeout=30000)
    page.wait_for_load_state("networkidle", timeout=15000)
    time.sleep(2)

    # Close popup if any
    try:
        page.click('[aria-label="Dismiss"]', timeout=3000)
    except Exception:
        pass

    # Scroll to load more jobs (LinkedIn uses infinite scroll)
    jobs_collected = 0
    scroll_attempts = 0
    max_scroll_attempts = 15

    while scroll_attempts < max_scroll_attempts and jobs_collected < max_results:
        # Get current job cards
        cards = page.query_selector_all(".job-card-container")
        new_count = len(cards)
        if new_count > jobs_collected:
            jobs_collected = new_count
            scroll_attempts = 0
            print(f"  [LinkedIn] Loaded {jobs_collected} job cards...")
        else:
            scroll_attempts += 1

        # Scroll down
        page.evaluate("window.scrollBy(0, 600)")
        time.sleep(1.5)

        # Also try clicking "See more jobs" button if present
        try:
            see_more = page.query_selector("button:has-text('See more jobs')")
            if see_more and see_more.is_visible():
                see_more.click()
                time.sleep(2)
        except Exception:
            pass

    print(f"  [LinkedIn] Total job cards found: {jobs_collected}")

    # Parse job cards
    jobs = []
    cards = page.query_selector_all(".job-card-container")
    for card in cards[:max_results]:
        try:
            job = _parse_job_card(card)
            if job and job.get("title") and job.get("url"):
                jobs.append(job)
        except Exception as e:
            print(f"  [LinkedIn] Error parsing card: {e}")

    page.close()
    return jobs


def _parse_job_card(card) -> dict | None:
    """Extracts job data from a LinkedIn job card element."""
    try:
        # Job title
        title_el = card.query_selector(".job-card-container__link--job-card")
        title = title_el.inner_text().strip() if title_el else ""
        url = title_el.get_attribute("href") if title_el else ""
        if url and not url.startswith("http"):
            url = "https://www.linkedin.com" + url

        # Company name
        company_el = card.query_selector(".job-card-container__meta-info-list li:first-child")
        company = company_el.inner_text().strip() if company_el else ""

        # Location
        loc_el = card.query_selector(".job-card-container__meta-info-list li:last-child")
        location = loc_el.inner_text().strip() if loc_el else ""

        # Posted date
        date_el = card.query_selector("time")
        posted_date = ""
        if date_el:
            posted_date = date_el.get_attribute("datetime") or ""
            if not posted_date:
                posted_date = date_el.inner_text().strip()

        job = {
            "title": title,
            "company": company,
            "location": location,
            "description": "",
            "url": url,
            "posted_date": posted_date,
            "salary": "",
            "employment_type": "",
            "remote": "remote" in (title + " " + location).lower(),
            "source": "linkedin",
            "scraped_at": datetime.now().isoformat(),
        }
        job["id"] = generate_job_id(job)
        return job
    except Exception:
        return None


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Scrape LinkedIn jobs via Playwright")
    parser.add_argument("--config", default="/home/cap/script/jobTracker/config.json")
    parser.add_argument("--keywords", nargs="+")
    parser.add_argument("--location")
    parser.add_argument("--hours", type=int, default=24)
    parser.add_argument("--max-results", type=int, default=50)
    parser.add_argument("--reauth", action="store_true", help="Force re-login")
    parser.add_argument("--output", "-o")
    args = parser.parse_args()

    config = load_config(args.config)

    if args.reauth:
        Path(SESSION_FILE).unlink(missing_ok=True)
        print("[LinkedIn] Cleared session file — will re-authenticate")

    jobs = search_jobs(
        config,
        keywords=args.keywords,
        location=args.location,
        hours_old=args.hours,
        max_results=args.max_results,
    )

    output = json.dumps(jobs, indent=2, default=str)
    if args.output:
        with open(args.output, "w") as f:
            f.write(output)
        print(f"Saved {len(jobs)} jobs to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[LinkedIn] Fatal error: {e}", file=sys.stderr)
        sys.exit(1)
