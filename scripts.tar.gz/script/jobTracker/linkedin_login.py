#!/usr/bin/env python3
import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright

SESSION_FILE = Path("/home/cap/script/jobTracker/linkedin_session.json")
EMAIL = "caplight98@gmail.com"
PASSWORD = "Dearlover1!"
PROXY = {"server": "http://192.168.23.1:7890"}

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True)
    context = browser.new_context(
        locale="en-US",
        geolocation={"latitude": 52.3676, "longitude": 4.9041},
        permissions=["geolocation"],
        extra_http_headers={"Accept-Language": "en-US,en;q=0.9"},
        proxy=PROXY,
    )
    page = context.new_page()
    print("[1/3] Navigating to LinkedIn login...")
    page.goto("https://www.linkedin.com/login", wait_until="load", timeout=30000)
    time.sleep(2)
    print("[2/3] Filling credentials...")
    page.fill("#username", EMAIL)
    page.fill("#password", PASSWORD)
    btn = page.query_selector("button[type=submit]")
    if btn:
        btn.click()
    else:
        page.click("[type=submit]")
    try:
        page.wait_for_url("**/feed/**", timeout=30000)
        print("[+] Login success: " + page.url)
    except Exception as e:
        current = page.url
        print("[!] Not redirected to feed, URL: " + current)
        if "checkpoint" in current or "auth" in current:
            print("[!] 2FA required...")
            page.wait_for_url("**/feed/**", timeout=120000)
            print("[+] 2FA passed!")
    time.sleep(2)
    state = context.storage_state()
    valid = [c for c in state.get("cookies", []) if "linkedin.com" in c.get("domain", "") and "linkedin.cn" not in c.get("domain", "")]
    state["cookies"] = valid
    with open(SESSION_FILE, "w") as f:
        json.dump(state, f)
    print("[+] Session saved: " + str(len(valid)) + " cookies")
    page2 = context.new_page()
    try:
        resp = page2.goto(
            "https://www.linkedin.com/jobs/view/senior-full-stack-engineer-ai-platform-agents-at-miro-4400448370",
            wait_until="domcontentloaded",
            timeout=20000
        )
        time.sleep(3)
        url = page2.url
        title = page2.title()
        print("    Status: " + str(resp.status if resp else "none"))
        print("    URL: " + url)
        print("    Title: " + title)
        if "linkedin.com/jobs/view" in url and len(title) > 5:
            print("[+] SUCCESS!")
        else:
            print("[!] Failed")
    except Exception as e:
        print("[!] Error: " + str(e))
    finally:
        page2.close()
    browser.close()
