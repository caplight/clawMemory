#!/usr/bin/env python3
"""
run_search.py — Unified search entry for Job Tracker.
Runs:
  1. SmartProxy Web Scraper API  → LinkedIn jobs (bypasses PerimeterX)
  2. JobSpy/Indeed (no proxy)    → Indeed jobs (secondary source)
  3. JSearch (every 2 days)       → Google Jobs aggregator (tertiary)
Merges results and saves to MySQL.
"""

import json
import sys
import os
import re
import pymysql
from datetime import datetime, date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from common.config import load_config
from common.dedup import deduplicate_jobs
from common.ireland_permits import has_ireland_work_permit

CONFIG_PATH = "/home/cap/script/jobTracker/config.json"
IND_EMPLOYER_LIST_PATH = "/home/cap/script/jobTracker/ind_nl_employers.json"

# Load IND NL Recognised Sponsors list (for work visa eligibility)
_ind_employers: set[str] = set()
def _load_ind_employers():
    global _ind_employers
    if not _ind_employers:
        try:
            with open(IND_EMPLOYER_LIST_PATH, encoding="utf-8") as f:
                _ind_employers = set(json.load(f))
            print(f"[IND] Loaded {len(_ind_employers)} Recognised Sponsors (NL work visa)")
        except Exception as e:
            print(f"[IND] Could not load employer list: {e}")
_load_ind_employers()

def _is_ind_visa_sponsor(company: str) -> bool:
    if not company or not _ind_employers:
        return False
    return company.strip() in _ind_employers

MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", "root2026pass"),
    "database": "job_tracker",
    "charset": "utf8mb4",
}
JSEARCH_STATE_FILE = "/home/cap/script/jobTracker/.jsearch_last_run"
DEFAULT_STATUS_FILE = "/tmp/jobtracker_scraper_status.json"
MYSQL_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
MYSQL_DATETIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$")


def _format_error(error: BaseException) -> str:
    if isinstance(error, SystemExit):
        code = getattr(error, "code", None)
        return f"SystemExit({code})"
    return str(error) or error.__class__.__name__


def _summarize_errors(errors: list[str], limit: int = 3) -> str:
    if not errors:
        return ""
    sample = errors[:limit]
    remainder = len(errors) - len(sample)
    summary = " | ".join(sample)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary


def _write_status_file(status_file: str, status_payload: dict):
    path = Path(status_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(status_payload, indent=2, ensure_ascii=False), encoding="utf-8")


def _build_scraper_status(
    key: str,
    name: str,
    result_count: int = 0,
    details: dict | None = None,
    error: str | None = None,
    skipped_message: str | None = None,
    rate_limited: bool = False,
) -> dict:
    details = details or {}
    errors = []
    if error:
        errors.append(error)
    for detail_error in details.get("errors", []):
        if detail_error and detail_error not in errors:
            errors.append(detail_error)

    task_count = int(details.get("task_count", 0) or 0)
    success_tasks = max(0, task_count - len(errors))

    if rate_limited:
        status = "rate_limited"
    elif skipped_message:
        status = "skipped"
    elif errors and success_tasks == 0:
        status = "error"
    elif errors:
        status = "partial"
    elif int(result_count or 0) == 0:
        status = "empty"
    else:
        status = "success"

    return {
        "key": key,
        "name": name,
        "status": status,
        "result_count": int(result_count or 0),
        "task_count": task_count,
        "errors": errors,
        "error_summary": _summarize_errors(errors),
        "message": skipped_message or details.get("message", ""),
    }


def _jsearch_skip_message(skip_jsearch: bool) -> str:
    if skip_jsearch:
        return "Skipped (--skip-jsearch)"

    days_since = 999
    if os.path.exists(JSEARCH_STATE_FILE):
        try:
            last = date.fromisoformat(Path(JSEARCH_STATE_FILE).read_text().strip())
            days_since = (date.today() - last).days
        except Exception:
            pass
    return f"Skipped (last ran {days_since}d ago, next in {max(0, 2 - days_since)}d)"


def _normalize_mysql_date(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()

    text = str(value).strip()
    if not text:
        return None

    candidate = text[:10]
    if MYSQL_DATE_RE.match(candidate):
        try:
            date.fromisoformat(candidate)
            return candidate
        except ValueError:
            return None
    return None


def _normalize_mysql_datetime(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return f"{value.isoformat()} 00:00:00"

    text = str(value).strip()
    if not text:
        return None

    normalized = text.replace("T", " ")
    if normalized.endswith("Z"):
        normalized = normalized[:-1]

    candidate = normalized[:19]
    if MYSQL_DATETIME_RE.match(candidate):
        try:
            datetime.strptime(candidate, "%Y-%m-%d %H:%M:%S")
            return candidate
        except ValueError:
            return None

    date_candidate = normalized[:10]
    if MYSQL_DATE_RE.match(date_candidate):
        try:
            date.fromisoformat(date_candidate)
            return f"{date_candidate} 00:00:00"
        except ValueError:
            return None
    return None


def _warn_dropped_mysql_value(field_name: str, value, job: dict):
    text = str(value).strip() if value is not None else ""
    if not text:
        return

    identifier = job.get("url") or job.get("title") or "<untitled>"
    print(
        f"[DB] Invalid {field_name} for {identifier}: {text!r}; storing NULL instead",
        file=sys.stderr,
    )


def save_jobs_to_mysql(jobs: list[dict]) -> int:
    """Save jobs to MySQL. Returns number of new jobs inserted.
    Also flags IND Recognised Sponsor (NL) and Ireland work permit eligibility."""
    conn = pymysql.connect(**MYSQL_CONFIG)
    new_count = 0
    insert_errors: list[str] = []
    try:
        cursor = conn.cursor()
        for job in jobs:
            company = (job.get("company") or "").strip()
            description = (job.get("description") or "").strip()
            job_url = job.get("url")
            visa_flag = 1 if _is_ind_visa_sponsor(company) else 0
            ireland_flag = 1 if has_ireland_work_permit(company) else 0
            posted_date = _normalize_mysql_date(job.get("posted_date"))
            scraped_at = _normalize_mysql_datetime(job.get("scraped_at"))

            if job.get("posted_date") is not None and posted_date is None:
                _warn_dropped_mysql_value("posted_date", job.get("posted_date"), job)
            if job.get("scraped_at") is not None and scraped_at is None:
                _warn_dropped_mysql_value("scraped_at", job.get("scraped_at"), job)

            try:
                cursor.execute("""
                    INSERT IGNORE INTO jobs
                    (title, source, url, company, location, description, salary, employment_type,
                     remote, posted_date, scraped_at, ind_visa_sponsor, ireland_work_permit, is_read)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0)
                """, (
                    job.get("title"),
                    job.get("source"),
                    job_url,
                    company,
                    job.get("location"),
                    description,
                    job.get("salary"),
                    job.get("employment_type"),
                    int(job.get("remote", False)),
                    posted_date,
                    scraped_at,
                    visa_flag,
                    ireland_flag,
                ))
                if cursor.rowcount > 0:
                    new_count += 1
                else:
                    updates = []
                    params: list[str] = []
                    if description:
                        updates.append(
                            "description = CASE WHEN description IS NULL OR description='' THEN %s ELSE description END"
                        )
                        params.append(description)
                    if visa_flag:
                        updates.append("ind_visa_sponsor=1")
                    if ireland_flag:
                        updates.append("ireland_work_permit=1")
                    if updates and job_url:
                        params.append(job_url)
                        cursor.execute(
                            f"UPDATE jobs SET {', '.join(updates)} WHERE url=%s",
                            tuple(params),
                        )
            except Exception as e:
                error_message = f"{job.get('title') or '<untitled>'}: {e}"
                insert_errors.append(error_message)
                print(f"[DB] Insert error: {error_message}", file=sys.stderr)

        conn.commit()
    finally:
        conn.close()

    if insert_errors:
        raise RuntimeError(
            f"MySQL save had {len(insert_errors)} errors: {_summarize_errors(insert_errors)}"
        )
    return new_count


def should_run_jsearch() -> bool:
    """Check if JSearch should run (every 2 days)."""
    if not os.path.exists(JSEARCH_STATE_FILE):
        return True
    try:
        last = date.fromisoformat(Path(JSEARCH_STATE_FILE).read_text(encoding="utf-8").strip())
        return (date.today() - last).days >= 2
    except Exception:
        return True


def main(
    skip_jsearch: bool = False,
    skip_smartproxy: bool = False,
    skip_indeed: bool = False,
    status_file: str = DEFAULT_STATUS_FILE,
):
    scraped_file = "/tmp/jobtracker_scraped.json"
    new_count = 0
    all_jobs: list[dict] = []
    run_status = {
        "report_date": date.today().isoformat(),
        "started_at": datetime.now().isoformat(),
        "completed_at": None,
        "success": False,
        "scrapers": [],
        "pipeline_errors": [],
        "totals": {
            "scraped_after_dedup": 0,
            "new_jobs_inserted": 0,
        },
    }

    try:
        config = load_config(CONFIG_PATH)

        # Step 1: SmartProxy → LinkedIn jobs (replaces blocked JobSpy LinkedIn)
        if not skip_smartproxy:
            print(f"[{datetime.now()}] === SmartProxy/LinkedIn Run ===")
            try:
                from smartproxy_scraper import scrape_jobs as smartproxy_scrape

                smartproxy_jobs, smartproxy_details = smartproxy_scrape(
                    config,
                    hours_old=24,
                    max_workers=3,
                    return_details=True,
                )
                run_status["scrapers"].append(
                    _build_scraper_status(
                        "smartproxy",
                        "SmartProxy/LinkedIn",
                        result_count=len(smartproxy_jobs),
                        details=smartproxy_details,
                    )
                )
                all_jobs.extend(smartproxy_jobs)
                print(f"[SmartProxy] Got {len(smartproxy_jobs)} LinkedIn jobs")
            except BaseException as e:
                if isinstance(e, KeyboardInterrupt):
                    raise
                error_message = _format_error(e)
                run_status["scrapers"].append(
                    _build_scraper_status(
                        "smartproxy",
                        "SmartProxy/LinkedIn",
                        error=error_message,
                    )
                )
                print(
                    f"[SmartProxy] Failed: {error_message} — continuing without LinkedIn data",
                    file=sys.stderr,
                )
        else:
            message = "Skipped (--skip-smartproxy)"
            print(f"[SmartProxy] {message}")
            run_status["scrapers"].append(
                _build_scraper_status(
                    "smartproxy",
                    "SmartProxy/LinkedIn",
                    skipped_message=message,
                )
            )

        # Step 2: JobSpy/Indeed (no proxy) — secondary source
        if not skip_indeed:
            print(f"[{datetime.now()}] === JobSpy/Indeed Run ===")
            try:
                from jobspy_scraper import scrape_jobs as jobspy_scrape

                jobspy_jobs, jobspy_details = jobspy_scrape(
                    config,
                    max_workers=3,
                    return_details=True,
                )
                run_status["scrapers"].append(
                    _build_scraper_status(
                        "jobspy",
                        "JobSpy/Indeed",
                        result_count=len(jobspy_jobs),
                        details=jobspy_details,
                    )
                )
                all_jobs.extend(jobspy_jobs)
                print(f"[JobSpy] Got {len(jobspy_jobs)} Indeed jobs")
            except BaseException as e:
                if isinstance(e, KeyboardInterrupt):
                    raise
                error_message = _format_error(e)
                run_status["scrapers"].append(
                    _build_scraper_status(
                        "jobspy",
                        "JobSpy/Indeed",
                        error=error_message,
                    )
                )
                print(f"[JobSpy] Failed: {error_message}", file=sys.stderr)
        else:
            message = "Skipped (--skip-indeed)"
            print(f"[JobSpy] {message}")
            run_status["scrapers"].append(
                _build_scraper_status(
                    "jobspy",
                    "JobSpy/Indeed",
                    skipped_message=message,
                )
            )

        # Deduplicate
        all_jobs = deduplicate_jobs(all_jobs)
        print(f"[Dedup] Total after merge: {len(all_jobs)}")

        # Step 3: JSearch (every 2 days, unless skipped)
        if not skip_jsearch and should_run_jsearch():
            print(f"[{datetime.now()}] === JSearch Run (every-2-day) ===")
            try:
                from jsearch_scraper import scrape_jobs as jsearch_scrape

                jsearch_jobs, jsearch_details = jsearch_scrape(
                    config,
                    return_details=True,
                )
                run_status["scrapers"].append(
                    _build_scraper_status(
                        "jsearch",
                        "JSearch",
                        result_count=len(jsearch_jobs),
                        details=jsearch_details,
                    )
                )
                all_jobs = deduplicate_jobs(all_jobs + jsearch_jobs)
                Path(JSEARCH_STATE_FILE).write_text(date.today().isoformat(), encoding="utf-8")
                print(f"[JSearch] Got {len(jsearch_jobs)} jobs")
            except BaseException as e:
                if isinstance(e, KeyboardInterrupt):
                    raise
                error_message = _format_error(e)
                is_rate_limit = "429" in error_message or "quota" in error_message.lower() or "rate limit" in error_message.lower()
                if is_rate_limit:
                    # Rate limit — not a failure, just notify and continue
                    run_status["scrapers"].append(
                        _build_scraper_status(
                            "jsearch",
                            "JSearch",
                            rate_limited=True,
                            details={"error_summary": error_message[:200]},
                        )
                    )
                    print(f"[JSearch] Rate limited: {error_message}", file=sys.stderr)
                else:
                    run_status["scrapers"].append(
                        _build_scraper_status(
                            "jsearch",
                            "JSearch",
                            error=error_message,
                        )
                    )
                    print(f"[JSearch] Failed: {error_message}", file=sys.stderr)
        else:
            message = _jsearch_skip_message(skip_jsearch)
            print(f"[JSearch] {message}")
            run_status["scrapers"].append(
                _build_scraper_status(
                    "jsearch",
                    "JSearch",
                    skipped_message=message,
                )
            )

        # Save to MySQL
        new_count = save_jobs_to_mysql(all_jobs)
        print(f"[DB] Inserted {new_count} new jobs (total scraped: {len(all_jobs)})")

        # Save scraped JSON for next step (scoring)
        with open(scraped_file, "w", encoding="utf-8") as f:
            json.dump(all_jobs, f, indent=2, default=str)
        print(f"Saved {len(all_jobs)} jobs to {scraped_file}")

        run_status["success"] = all(
            scraper["status"] in {"success", "empty", "skipped"}
            for scraper in run_status["scrapers"]
        )
        return new_count, len(all_jobs)
    except BaseException as e:
        error_message = _format_error(e)
        run_status["pipeline_errors"].append(error_message)
        print(f"[run_search] Fatal error: {error_message}", file=sys.stderr)
        raise
    finally:
        run_status["completed_at"] = datetime.now().isoformat()
        run_status["totals"]["scraped_after_dedup"] = len(all_jobs)
        run_status["totals"]["new_jobs_inserted"] = new_count
        try:
            _write_status_file(status_file, run_status)
            print(f"[run_search] Wrote scraper status to {status_file}")
        except Exception as e:
            print(f"[run_search] Could not write status file: {_format_error(e)}", file=sys.stderr)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-jsearch", action="store_true", help="Skip JSearch even if due")
    parser.add_argument("--skip-smartproxy", action="store_true", help="Skip SmartProxy/LinkedIn")
    parser.add_argument("--skip-indeed", action="store_true", help="Skip JobSpy/Indeed")
    parser.add_argument("--status-file", default=DEFAULT_STATUS_FILE, help="Path to write scraper status JSON")
    args = parser.parse_args()
    try:
        new_count, total = main(
            skip_jsearch=args.skip_jsearch,
            skip_smartproxy=args.skip_smartproxy,
            skip_indeed=args.skip_indeed,
            status_file=args.status_file,
        )
        print(f"\nResult: {new_count} new, {total} total")
    except Exception:
        sys.exit(1)
