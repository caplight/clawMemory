#!/usr/bin/env python3
"""
send_feishu.py — Feishu notification for Job Tracker.
Always sends a full report: overall stats, per-scraper status, top jobs, errors.
"""

import json
import sys
import os
import pymysql
from datetime import datetime, date
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).parent))
from common.config import load_config

CONFIG_PATH = "/home/cap/script/jobTracker/config.json"
DEFAULT_STATUS_FILE = "/tmp/jobtracker_scraper_status.json"
SCRAPED_AT_DATE_SQL = "LEFT(COALESCE(CAST(scraped_at AS CHAR), ''), 10) = %s"
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", "root2026pass"),
    "database": "job_tracker",
    "charset": "utf8mb4",
}


def _empty_stats() -> dict:
    return {
        "total_today": 0,
        "scored": 0,
        "above_thresh": 0,
        "unscored": 0,
        "avg_score": None,
        "interview": 0,
        "consider": 0,
        "reject": 0,
        "pending": 0,
        "unevaluable": 0,
        "top_jobs": [],
        "db_total": 0,
        "source_dist": {},
    }


def _unique_lines(*groups) -> list[str]:
    seen = set()
    lines = []
    for group in groups:
        if not group:
            continue
        if isinstance(group, str):
            candidates = [line.strip() for line in group.splitlines() if line.strip()]
        else:
            candidates = [str(line).strip() for line in group if str(line).strip()]
        for candidate in candidates:
            if candidate not in seen:
                seen.add(candidate)
                lines.append(candidate)
    return lines


def _safe_load_config() -> dict:
    try:
        return load_config(CONFIG_PATH)
    except BaseException as e:
        print(f"[Feishu] Could not load config: {e}", file=sys.stderr)
        return {}


def _scraper_display_name(scraper: dict) -> str:
    return scraper.get("name") or scraper.get("key") or "Unknown scraper"


def _load_status_context(status_file: str | None) -> dict:
    context = {
        "scrapers": [],
        "pipeline_errors": [],
        "totals": {},
        "load_errors": [],
    }
    if not status_file:
        return context

    path = Path(status_file)
    if not path.exists():
        context["load_errors"] = [f"Scraper status file not found: {status_file}"]
        return context

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        context["scrapers"] = payload.get("scrapers", []) or []
        context["pipeline_errors"] = _unique_lines(payload.get("pipeline_errors", []))
        context["totals"] = payload.get("totals", {}) or {}
    except Exception as e:
        context["load_errors"] = [f"Could not read scraper status file: {e}"]
    return context


def _query_report_stats(report_date: str, threshold: int) -> dict:
    stats = _empty_stats()
    conn = pymysql.connect(**MYSQL_CONFIG)
    try:
        cursor = conn.cursor(pymysql.cursors.DictCursor)

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM jobs WHERE {SCRAPED_AT_DATE_SQL}",
            (report_date,),
        )
        stats["total_today"] = cursor.fetchone()["cnt"]

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM jobs WHERE {SCRAPED_AT_DATE_SQL} AND match_score IS NOT NULL",
            (report_date,),
        )
        stats["scored"] = cursor.fetchone()["cnt"]

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM jobs WHERE {SCRAPED_AT_DATE_SQL} AND match_score >= %s",
            (report_date, threshold),
        )
        stats["above_thresh"] = cursor.fetchone()["cnt"]

        cursor.execute(
            f"SELECT COUNT(*) as cnt FROM jobs WHERE {SCRAPED_AT_DATE_SQL} AND match_score IS NULL",
            (report_date,),
        )
        stats["unscored"] = cursor.fetchone()["cnt"]

        cursor.execute(
            "SELECT ROUND(AVG(match_score), 1) as avg_score "
            f"FROM jobs WHERE {SCRAPED_AT_DATE_SQL} AND match_score IS NOT NULL",
            (report_date,),
        )
        avg_score_row = cursor.fetchone()
        stats["avg_score"] = avg_score_row["avg_score"] if avg_score_row else None

        cursor.execute(
            "SELECT hiring_decision, COUNT(*) as cnt "
            f"FROM jobs WHERE {SCRAPED_AT_DATE_SQL} AND match_score IS NOT NULL "
            "GROUP BY hiring_decision",
            (report_date,),
        )
        dist = {row["hiring_decision"]: row["cnt"] for row in cursor.fetchall()}
        stats["interview"] = dist.get("interview", 0) + dist.get("strong_interview", 0)
        stats["consider"] = dist.get("consider", 0)
        stats["reject"] = dist.get("reject", 0)
        stats["pending"] = dist.get("pending", 0)
        stats["unevaluable"] = dist.get("unevaluable", 0)

        cursor.execute(
            "SELECT title, company, location, salary, source, match_score, "
            "       keyword_score, semantic_score, url, hiring_decision, "
            "       ind_visa_sponsor, ireland_work_permit "
            "FROM jobs "
            f"WHERE {SCRAPED_AT_DATE_SQL} AND match_score >= %s "
            "ORDER BY match_score DESC LIMIT 10",
            (report_date, threshold),
        )
        stats["top_jobs"] = cursor.fetchall()

        cursor.execute("SELECT COUNT(*) as cnt FROM jobs")
        stats["db_total"] = cursor.fetchone()["cnt"]

        cursor.execute(
            "SELECT source, COUNT(*) as cnt "
            f"FROM jobs WHERE {SCRAPED_AT_DATE_SQL} "
            "GROUP BY source",
            (report_date,),
        )
        stats["source_dist"] = {row["source"]: row["cnt"] for row in cursor.fetchall()}
    finally:
        conn.close()

    return stats


def _status_emoji(status: str) -> str:
    return {
        "success": "✅",
        "empty": "📭",
        "partial": "⚠️",
        "error": "❌",
        "skipped": "⏭️",
        "rate_limited": "⚠️",
    }.get(status, "•")


def _status_label(status: str) -> str:
    return {
        "success": "正常",
        "empty": "0 data",
        "partial": "部分失败",
        "error": "失败",
        "skipped": "跳过",
        "rate_limited": "配额用尽",
    }.get(status, status or "unknown")


def _format_scraper_block(scrapers: list[dict]) -> str:
    if not scrapers:
        return "本次未提供爬虫状态。"

    lines = []
    for scraper in scrapers:
        status = scraper.get("status", "unknown")
        name = _scraper_display_name(scraper)
        result_count = int(scraper.get("result_count", 0) or 0)
        task_count = int(scraper.get("task_count", 0) or 0)
        line = f"- {_status_emoji(status)} **{name}**: **{result_count}** 条 | {_status_label(status)}"
        if task_count:
            line += f" | {task_count} tasks"
        if scraper.get("message"):
            line += f"\n> {scraper['message']}"
        if status == "rate_limited" and scraper.get("error_summary"):
            line += f"\n> {scraper['error_summary'][:500]}"
        elif scraper.get("error_summary"):
            line += f"\n> 错误: {scraper['error_summary'][:500]}"
        lines.append(line)
    return "\n".join(lines)


def _format_empty_scraper_summary(scrapers: list[dict]) -> str:
    empty_scrapers = [
        _scraper_display_name(scraper)
        for scraper in scrapers
        if scraper.get("status") == "empty"
    ]
    if not empty_scrapers:
        return ""
    return "**📭 空结果爬虫：** " + "、".join(empty_scrapers)


def _format_run_totals(status_context: dict) -> str:
    totals = status_context.get("totals", {}) or {}
    pieces = []
    if "scraped_after_dedup" in totals:
        pieces.append(f"去重后 **{totals['scraped_after_dedup']}** 条")
    if "new_jobs_inserted" in totals:
        pieces.append(f"新入库 **{totals['new_jobs_inserted']}** 条")
    return " | ".join(pieces)


def _build_fallback_report(
    report_date: str | None = None,
    error: str | None = None,
    status_file: str = DEFAULT_STATUS_FILE,
) -> dict:
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    date_label = report_date or "今天"
    status_context = _load_status_context(status_file)
    errors = _unique_lines(
        error,
        status_context.get("pipeline_errors", []),
        status_context.get("load_errors", []),
    )

    elements = [{"tag": "markdown", "content": f"**推送时间：** {now}"}]
    elements.append(
        {"tag": "markdown", "content": f"**🕷️ 爬虫状态**\n{_format_scraper_block(status_context.get('scrapers', []))}"}
    )
    empty_scraper_summary = _format_empty_scraper_summary(status_context.get("scrapers", []))
    if empty_scraper_summary:
        elements.append({"tag": "markdown", "content": empty_scraper_summary})
    run_totals = _format_run_totals(status_context)
    if run_totals:
        elements.append({"tag": "markdown", "content": f"**🧮 本次运行：** {run_totals}"})
    if errors:
        elements.append(
            {"tag": "markdown", "content": "**⚠️ 运行异常**\n" + "\n".join(f"- {line[:500]}" for line in errors)}
        )

    return {
        "msg_type": "interactive",
        "card": {
            "header": {
                "title": {"tag": "plain_text", "content": f"⚠️ Job Tracker — {date_label} 报告降级发送"},
                "template": "red",
            },
            "elements": elements,
        },
    }


def build_report(
    report_date: str = None,
    error: str = None,
    status_file: str = DEFAULT_STATUS_FILE,
) -> dict:
    """
    Build a Feishu card message with full stats for a given date.
    report_date: YYYY-MM-DD format, defaults to today.
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    scoring_cfg = _safe_load_config().get("scoring", {})
    threshold = scoring_cfg.get("score_threshold", 50)
    date_str = report_date or date.today().isoformat()
    date_label = report_date or "今天"
    status_context = _load_status_context(status_file)

    stats_error = None
    try:
        stats = _query_report_stats(date_str, threshold)
    except Exception as e:
        stats = _empty_stats()
        stats_error = f"Database stats unavailable: {e}"

    all_errors = _unique_lines(
        error,
        status_context.get("pipeline_errors", []),
        status_context.get("load_errors", []),
        [stats_error] if stats_error else [],
    )

    scrapers = status_context.get("scrapers", [])
    active_scrapers = [scraper for scraper in scrapers if scraper.get("status") != "skipped"]
    all_active_scrapers_empty = bool(active_scrapers) and all(
        scraper.get("status") == "empty" for scraper in active_scrapers
    )
    has_scraper_issues = any(scraper.get("status") in {"partial", "error"} for scraper in scrapers)
    source_dist = stats.get("source_dist", {}) or {}
    source_str = " | ".join(f"{key} {value}条" for key, value in source_dist.items()) or "-"

    if all_errors or has_scraper_issues:
        title = f"⚠️ Job Tracker — {date_label} 已完成（含异常）"
        template = "red"
    elif stats["total_today"] == 0 and all_active_scrapers_empty:
        title = f"📭 Job Tracker — {date_label} 爬虫返回 0 条"
        template = "grey"
    elif stats["total_today"] == 0:
        title = f"📭 Job Tracker — {date_label} 无新增职位"
        template = "grey"
    else:
        title = f"✅ Job Tracker — {date_label} 新增 {stats['total_today']} 条"
        template = "green" if stats["above_thresh"] > 0 else "grey"

    content = [{"tag": "markdown", "content": f"**推送时间：** {now}"}]

    content.append(
        {"tag": "markdown", "content": f"**🕷️ 爬虫状态**\n{_format_scraper_block(scrapers)}"}
    )
    empty_scraper_summary = _format_empty_scraper_summary(scrapers)
    if empty_scraper_summary:
        content.append({"tag": "markdown", "content": empty_scraper_summary})

    run_totals = _format_run_totals(status_context)
    if run_totals:
        content.append({"tag": "markdown", "content": f"**🧮 本次运行：** {run_totals}"})

    if all_errors:
        content.append(
            {"tag": "markdown", "content": "**⚠️ 运行异常**\n" + "\n".join(f"- {line[:500]}" for line in all_errors)}
        )

    if stats["total_today"] == 0:
        content.extend(
            [
                {"tag": "markdown", "content": f"**📊 总体数据（{date_label}）** 今日入库 **0** 条"},
                {"tag": "markdown", "content": f"**📡 数据来源：** {source_str}"},
                {"tag": "markdown", "content": f"**数据库累计：** {stats['db_total']} 条职位"},
            ]
        )
    else:
        content.extend(
            [
                {"tag": "markdown", "content": f"**📊 总体数据（{date_label}）**"},
                {
                    "tag": "markdown",
                    "content": (
                        f"入库 **{stats['total_today']}** 条 "
                        f"| 已评分 **{stats['scored']}** 条 "
                        f"| 平均分 **{stats['avg_score'] if stats['avg_score'] is not None else 'N/A'}** "
                        f"| ≥{threshold}分 **{stats['above_thresh']}** 条\n"
                        f"⚠️ 无法抓取description的职位已归类（见分布）"
                    ),
                },
                {
                    "tag": "markdown",
                    "content": (
                        f"**📋 评分分布：** 🔥 interview **{stats['interview']}** "
                        f"| ✅ consider **{stats['consider']}** "
                        f"| ❌ reject **{stats['reject']}** "
                        f"| ⏳ pending **{stats['pending']}** "
                        f"| 🚫 unevaluable **{stats['unevaluable']}**"
                    ),
                },
                {"tag": "markdown", "content": f"**📡 数据来源：** {source_str}"},
            ]
        )

        top_jobs = stats.get("top_jobs", [])
        if top_jobs:
            job_blocks = []
            decision_emoji = {
                "strong_interview": "🔥",
                "interview": "✅",
                "consider": "⚠️",
                "reject": "❌",
            }
            for i, job in enumerate(top_jobs, 1):
                score = job["match_score"]
                title_short = (job["title"][:45] + "…") if len(job["title"]) > 45 else job["title"]
                kw = job["keyword_score"]
                sem = job["semantic_score"]
                decision = job.get("hiring_decision", "-")
                decision_mark = decision_emoji.get(decision, "⚠️")
                visa_tags = ""
                if job.get("ind_visa_sponsor"):
                    visa_tags += " 🇨🇳NL"
                if job.get("ireland_work_permit"):
                    visa_tags += " 🇮🇪IE"
                location = job["location"] or "-"
                salary = job["salary"] or "-"
                url_short = job.get("url") or ""
                if len(url_short) > 75:
                    url_short = url_short[:75] + "…"
                job_blocks.append(
                    {
                        "tag": "markdown",
                        "content": (
                            f"**{i}. {decision_mark} {title_short}**\n"
                            f"> 🏢 {job['company']} | 📍 {location} | 💰 {salary}\n"
                            f"> 🎯 **{score}**分 (KW:{kw} + SEM:{sem}){visa_tags}\n"
                            f"> 🔗 {url_short}"
                        ),
                    }
                )
            content.append({"tag": "markdown", "content": "**🏆 Top 10 高分职位**"})
            content.extend(job_blocks)
        else:
            content.append({"tag": "markdown", "content": f"*无 ≥{threshold}分职位*"})

    return {
        "msg_type": "interactive",
        "card": {
            "header": {"title": {"tag": "plain_text", "content": title}, "template": template},
            "elements": content,
        },
    }


def send_feishu(
    report_date: str = None,
    error: str = None,
    status_file: str = DEFAULT_STATUS_FILE,
):
    config = _safe_load_config()
    webhook = os.environ.get("FEISHU_WEBHOOK", "") or config.get("feishu_webhook", "")
    if not webhook:
        print("[Feishu] No webhook configured")
        return False

    try:
        payload = build_report(report_date, error, status_file=status_file)
    except BaseException as e:
        print(f"[Feishu] Report build error: {e}", file=sys.stderr)
        payload = _build_fallback_report(
            report_date=report_date,
            error=f"{error or ''}\nReport build error: {e}".strip(),
            status_file=status_file,
        )

    try:
        response = requests.post(webhook, json=payload, timeout=20)
        response.raise_for_status()
        try:
            resp = response.json()
        except ValueError:
            print(f"[Feishu] Unexpected response: {response.text[:500]}", file=sys.stderr)
            return False

        if resp.get("StatusCode") == 0 or resp.get("code") == 0:
            print(f"[Feishu] Sent report for {report_date or 'today'}")
            return True
        else:
            print(f"[Feishu] Send failed: {resp}", file=sys.stderr)
            return False
    except Exception as e:
        print(f"[Feishu] Error: {e}", file=sys.stderr)
        return False


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--date", default=None, help="Report date (YYYY-MM-DD), defaults to today")
    parser.add_argument("--error", default=None, help="Error message to report")
    parser.add_argument("--status-file", default=DEFAULT_STATUS_FILE, help="Scraper status JSON path")
    args = parser.parse_args()
    sys.exit(0 if send_feishu(report_date=args.date, error=args.error, status_file=args.status_file) else 1)
