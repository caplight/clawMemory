#!/usr/bin/env python3
"""
JSearch Job Scraper for Job Tracker.
Searches via RapidAPI JSearch API (Google Jobs aggregator).
Requires: JSEARCH_API_KEY in config.json
"""

import json
import sys
from datetime import datetime
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).parent))

from common.config import load_config
from common.dedup import deduplicate_jobs, generate_job_id

JSEARCH_URL = "https://jsearch.p.rapidapi.com/search"
JSEARCH_HOST = "jsearch.p.rapidapi.com"

def _summarize_errors(errors: list[str], limit: int = 3) -> str:
    if not errors:
        return ""
    sample = errors[:limit]
    remainder = len(errors) - len(sample)
    summary = " | ".join(sample)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary


def _format_salary(job: dict) -> str:
    try:
        min_s = job.get("job_min_salary")
        max_s = job.get("job_max_salary")
        period = (job.get("job_salary_period") or "").lower()
        period_label = {"year": "yr", "hour": "hr", "month": "mo"}.get(period, period)
        if min_s and max_s:
            return f"${int(min_s):,}–${int(max_s):,} {period_label}".strip()
        elif min_s:
            return f"${int(min_s):,}+ {period_label}".strip()
        elif max_s:
            return f"up to ${int(max_s):,} {period_label}".strip()
    except Exception:
        pass
    return ""


def _location(job: dict) -> str:
    parts = [job.get("job_city") or "", job.get("job_state") or ""]
    loc = ", ".join(p for p in parts if p)
    if not loc:
        loc = job.get("job_country") or ""
    return loc


CITY_TO_COUNTRY = {
    # Netherlands (NL)
    "amsterdam": "nl", "rotterdam": "nl", "the hague": "nl", "utrecht": "nl",
    "eindhoven": "nl", "tilburg": "nl", "groningen": "nl", "almere": "nl",
    "netherlands": "nl", "holland": "nl",
    # Ireland (IE)
    "dublin": "ie", "cork": "ie", "galway": "ie", "limerick": "ie",
    "waterford": "ie", "maynooth": "ie", "ireland": "ie",
    # United States (US)
    "new york": "us", "san francisco": "us", "los angeles": "us",
    "seattle": "us", "boston": "us", "austin": "us",
    # United Kingdom (GB)
    "london": "gb", "manchester": "gb", "birmingham": "gb", "edinburgh": "gb",
}


def _city_to_country(location_str: str) -> str:
    """Map a location/city string to ISO 3166-1 alpha-2 country code."""
    loc_lower = location_str.lower().strip()
    return CITY_TO_COUNTRY.get(loc_lower, "us")  # default to US if unknown


def normalize_jsearch_result(job: dict) -> dict:
    title = job.get("job_title") or ""
    company = job.get("employer_name") or ""
    description = job.get("job_description") or ""
    url = job.get("job_apply_link") or job.get("job_google_link") or ""
    posted_date = job.get("job_posted_at_datetime_utc") or ""
    remote = bool(job.get("job_is_remote")) or "remote" in (title + " " + description).lower()
    employment_type = (job.get("job_employment_type") or "").lower().replace("_", " ")
    source = (job.get("job_publisher") or "jsearch").lower()

    result = {
        "title": title,
        "company": company,
        "location": _location(job),
        "description": description,
        "url": url,
        "posted_date": posted_date,
        "salary": _format_salary(job),
        "employment_type": employment_type,
        "remote": remote,
        "source": "jsearch",
        "scraped_at": datetime.now().isoformat(),
    }
    result["id"] = generate_job_id(result)
    return result


def search_jobs(
    api_key: str,
    query: str,
    num_results: int = 10,
    date_posted: str = "today",
    country: str = "us",
    language: str = "en",
    return_errors: bool = False,
) -> list[dict] | tuple[list[dict], list[str]]:
    headers = {
        "X-RapidAPI-Key": api_key,
        "X-RapidAPI-Host": JSEARCH_HOST,
    }
    params = {
        "query": query,
        "page": "1",
        "num_pages": "1",
        "date_posted": date_posted,
        "country": country,
        "language": language,
    }

    all_data: list[dict] = []
    errors: list[str] = []
    pages_needed = max(1, (num_results + 9) // 10)

    with requests.Session() as client:
        for page in range(1, pages_needed + 1):
            params["page"] = str(page)
            try:
                resp = client.get(JSEARCH_URL, headers=headers, params=params, timeout=30)
                if resp.status_code != 200:
                    error_message = f"API error {resp.status_code}: {resp.text[:200]}"
                    errors.append(error_message)
                    print(f"[JSearch] {error_message}", file=sys.stderr)
                    break
                data = resp.json().get("data") or []
                all_data.extend(data)
                if len(data) < 10:
                    break
            except Exception as e:
                error_message = f"Request error: {e}"
                errors.append(error_message)
                print(f"[JSearch] {error_message}", file=sys.stderr)
                break

    result = all_data[:num_results]
    if return_errors:
        return result, errors
    return result


def scrape_jobs(
    config: dict,
    keywords: list[str] | None = None,
    location: str | None = None,
    return_details: bool = False,
) -> list[dict] | tuple[list[dict], dict]:
    api_key = config.get("jsearch_api_key", "")
    if not api_key:
        raise RuntimeError("jsearch_api_key not configured")

    search_cfg = config.get("search", {})
    keywords_list = keywords or search_cfg.get("keywords", [])
    loc = location or search_cfg.get("location", "")
    time_range = search_cfg.get("time_range", "week")
    date_posted = "today"
    num_results = search_cfg.get("max_results_per_query_jsearch", 10)

    print(f"[JSearch] Date: {date_posted} | Results/keyword: {num_results}")

    all_jobs = []
    if location:
        locations = [location]
    else:
        locations = search_cfg.get("locations", []) or [loc]
    tasks = [(kw, query_loc) for kw in keywords_list for query_loc in locations if query_loc]
    errors = []

    if not tasks:
        print("[JSearch] No keyword/location tasks configured")
        details = {"task_count": 0, "error_count": 0, "errors": []}
        return ([], details) if return_details else []

    for kw, query_loc in tasks:
        query = f"{kw} {query_loc}".strip()
        print(f"[JSearch] Query: {query}")
        country_code = _city_to_country(query_loc)
        raw, query_errors = search_jobs(
            api_key,
            query,
            num_results,
            date_posted,
            country=country_code,
            language="en",
            return_errors=True,
        )
        normalized = [normalize_jsearch_result(r) for r in raw]
        all_jobs.extend(normalized)
        print(f"[JSearch] Found {len(normalized)} postings for '{kw}' @ '{query_loc}'")
        for query_error in query_errors:
            errors.append(f"'{kw}' @ '{query_loc}': {query_error}")

    all_jobs = deduplicate_jobs(all_jobs)
    all_jobs.sort(key=lambda j: j.get("posted_date", ""), reverse=True)
    print(f"[JSearch] Total after dedup: {len(all_jobs)}")
    details = {
        "task_count": len(tasks),
        "error_count": len(errors),
        "errors": errors,
        "error_summary": _summarize_errors(errors),
    }
    if return_details:
        return all_jobs, details
    return all_jobs


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Search jobs via JSearch (RapidAPI)")
    parser.add_argument("--config", default="/home/cap/script/jobTracker/config.json")
    parser.add_argument("--keywords", nargs="+")
    parser.add_argument("--location")
    parser.add_argument("--output", "-o")
    args = parser.parse_args()

    config = load_config(args.config)
    jobs = scrape_jobs(config, keywords=args.keywords, location=args.location)

    output = json.dumps(jobs, indent=2, default=str)
    if args.output:
        with open(args.output, "w") as f:
            f.write(output)
        print(f"Saved {len(jobs)} jobs to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[JSearch] Fatal error: {e}", file=sys.stderr)
        sys.exit(1)
