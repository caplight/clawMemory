#!/usr/bin/env python3
import json, time
from pathlib import Path
from playwright.sync_api import sync_playwright
SESSION_FILE = Path('/home/cap/script/jobTracker/linkedin_session.json')
EMAIL = 'caplight98@gmail.com'
PASSWORD = 'Dearlover1!'
PROXY = {'server': 'http://192.168.23.1:7890'}

def load_session(context):
    if SESSION_FILE.exists():
        with open(SESSION_FILE) as f:
            state = json.load(f)
        ctx = context or browser.new_context(locale='en-US', proxy=PROXY)
        # Only keep linkedin.com cookies
        valid = [c for c in state.get('cookies', []) if 'linkedin.com' in c.get('domain', '')]
        ctx.add_cookies(valid)
        return ctx
    return context

def save_session(context):
    state = context.storage_state()
    valid = [c for c in state.get('cookies', []) if 'linkedin.com' in c.get('domain', '')]
    state['cookies'] = valid
    with open(SESSION_FILE, 'w') as f:
        json.dump(state, f)
    print('[OK] Saved ' + str(len(valid)) + ' cookies')
    return valid

print('[1/5] Starting...')
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, proxy=PROXY)
    context = browser.new_context(locale='en-US', proxy=PROXY)

    # Try loading existing session first
    load_session(context)
    page = context.new_page()
    page.goto('https://www.linkedin.com/feed', timeout=30000)
    time.sleep(2)
    url = page.url
    print('[2/5] Feed URL: ' + url)

    if 'checkpoint' in url or 'login' in url:
        print('[3/5] Session invalid, need fresh login...')
        page.close()
        context = browser.new_context(locale='en-US', proxy=PROXY)
        page = context.new_page()
        page.goto('https://www.linkedin.com/login', wait_until='load', timeout=30000)
        time.sleep(2)
        print('[4/5] Current: ' + page.url)
        try:
            page.wait_for_selector('#username', timeout=5000)
            page.fill('#username', EMAIL)
            page.fill('#password', PASSWORD)
            page.click('button[type=submit]')
            page.wait_for_url('**/feed/**', timeout=30000)
            print('[OK] Logged in: ' + page.url)
        except Exception as e:
            print('[!!] Login error: ' + str(e)[:100])
            print('[!!] Current URL: ' + page.url)
    else:
        print('[OK] Session still valid, already logged in!')

    print('[5/5] Saving session...')
    valid = save_session(context)
    print('li_at present:', any(c['name'] == 'li_at' for c in valid))
    browser.close()
