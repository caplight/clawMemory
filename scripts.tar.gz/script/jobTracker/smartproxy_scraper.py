#!/usr/bin/env python3
"""
SmartProxy Web Scraper API scraper for Job Tracker.
Uses SmartProxy's uni_scraper to bypass PerimeterX on LinkedIn.
"""

import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import quote_plus

import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)  # for verify=False on proxy
from bs4 import BeautifulSoup

sys.path.insert(0, str(Path(__file__).parent))
from common.config import load_config
from common.dedup import deduplicate_jobs, generate_job_id

BRIGHT_DATA_BASE_USER = "brd-customer-hl_0179506e-zone-claw_unlocker"
BRIGHT_DATA_PASS = "j2dlcp08e4as"
BRIGHT_DATA_HOST = "brd.superproxy.io"
BRIGHT_DATA_PORT = 33335


def _location_to_country_code(location: str) -> str:
    """Map location name to Bright Data country code for proxy username suffix."""
    loc_lower = location.lower()
    if any(x in loc_lower for x in ["netherlands", "holland", "amsterdam", "rotterdam", "utrecht", "eindhoven"]):
        return "nl"
    if any(x in loc_lower for x in ["ireland", "dublin", "cork", "galway"]):
        return "ie"
    return ""  # auto-select best country


def _build_proxy_url(country_code: str = "") -> str:
    """Build Bright Data proxy URL with optional country targeting."""
    user = BRIGHT_DATA_BASE_USER
    if country_code:
        user += f"-country-{country_code}"
    return f"http://{user}:{BRIGHT_DATA_PASS}@{BRIGHT_DATA_HOST}:{BRIGHT_DATA_PORT}"


def _summarize_errors(errors: list[str], limit: int = 3) -> str:
    if not errors:
        return ""
    sample = errors[:limit]
    remainder = len(errors) - len(sample)
    summary = " | ".join(sample)
    if remainder > 0:
        summary += f" | +{remainder} more"
    return summary


def build_linkedin_jobs_url(keyword: str, location: str, hours_old: int = 24, start: int = 0) -> str:
    """Build a LinkedIn jobs search URL with filters."""
    keyword_enc = quote_plus(keyword)
    location_enc = quote_plus(location)
    # Build URL matching the working SmartProxy curl format
    # js_render=false approach is more reliable (no browser fingerprinting needed)
    # NOTE: geoId in URL + SmartProxy geo param works when js_render=false
    return (
        f"https://www.linkedin.com/jobs/search/?"
        f"keywords={keyword_enc}&location={location_enc}&f_TPR=r{hours_old * 3600}"
        f"&start={start}"
    )


def scrape_linkedin_api(
    api_key: str,
    keyword: str,
    location: str,
    hours_old: int = 24,
    max_results: int = 50,
    return_error: bool = False,
) -> list[dict] | tuple[list[dict], str | None]:
    """
    Use Bright Data Unlocker to fetch LinkedIn jobs page HTML,
    then parse out job cards.
    """
    url = build_linkedin_jobs_url(keyword, location, hours_old)
    country_code = _location_to_country_code(location)
    proxies = {
        "http": _build_proxy_url(country_code),
        "https": _build_proxy_url(country_code),
    }
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
        ),
        "Accept": (
            "text/html,application/xhtml+xml,application/xml;q=0.9,"
            "image/avif,image/webp,image/apng,*/*;q=0.8"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
    }

    try:
        resp = requests.get(
            url,
            headers=headers,
            proxies=proxies,
            timeout=60,
            verify=False,  # Bright Data proxy uses self-signed cert
        )
    except requests.RequestException as e:
        error_message = f"Proxy request failed: {e}"
        print(f"[SmartProxy] {error_message}", file=sys.stderr)
        if return_error:
            return [], error_message
        return []

    if resp.status_code != 200:
        error_message = f"API error {resp.status_code}: {resp.text[:200]}"
        print(f"[SmartProxy] {error_message}", file=sys.stderr)
        if return_error:
            return [], error_message
        return []

    html = resp.text

    # Check for PerimeterX challenge
    error_message = None
    lower_html = html.lower()
    if (
        "protechts.net" in lower_html
        or "humanthirdpartyiframe" in lower_html
        or "perimeterx" in lower_html
        or "_pxcaptcha" in lower_html
        or "_pxvid" in lower_html
        or "please verify you are a human" in lower_html
        or "press and hold" in lower_html
    ):
        error_message = f"PerimeterX challenge still present for {location}"
        print(f"[SmartProxy] {error_message}", file=sys.stderr)

    jobs = parse_linkedin_html(html, keyword, location)[:max_results]
    if return_error:
        return jobs, error_message
    return jobs


def parse_linkedin_html(html: str, keyword: str, location: str) -> list[dict]:
    """Parse LinkedIn jobs search HTML and extract job data."""
    soup = BeautifulSoup(html, "html.parser")
    # LinkedIn uses Tailwind class names - find all cards with base-search-card
    job_cards = soup.find_all("div", class_=lambda c: c and "base-search-card" in c)
    print(f"[SmartProxy] Found {len(job_cards)} job cards in HTML")

    jobs = []
    seen_urls = set()
    for card in job_cards:
        try:
            # Title and URL - find the link inside the card
            link_el = card.find("a", class_=lambda c: c and "base-card__full-link" in c)
            if not link_el:
                link_el = card.find("a", href=True)
            title = ""
            url = ""
            if link_el:
                title = link_el.get_text(strip=True)
                url = link_el.get("href", "")
            if not title:
                continue
            if url and not url.startswith("http"):
                url = "https://www.linkedin.com" + url

            if url in seen_urls:
                continue
            seen_urls.add(url)

            # Company - inside h4 with base-search-card__subtitle
            company_el = card.find("h4", class_=lambda c: c and "subtitle" in c)
            company = company_el.get_text(strip=True) if company_el else ""

            # Location
            loc_el = card.find("span", class_=lambda c: c and "location" in c)
            loc = loc_el.get_text(strip=True) if loc_el else location

            # Posted date
            time_el = card.find("time")
            posted_date = ""
            if time_el:
                posted_date = time_el.get("datetime", "") or time_el.get_text(strip=True)

            job = {
                "title": title,
                "company": company,
                "location": loc or location,
                "description": "",
                "url": url,
                "posted_date": posted_date,
                "salary": "",
                "employment_type": "",
                "remote": "remote" in (title + " " + loc).lower(),
                "source": "linkedin",
                "scraped_at": datetime.now().isoformat(),
            }
            job["id"] = generate_job_id(job)
            jobs.append(job)
        except Exception as e:
            print(f"[SmartProxy] Error parsing card: {e}")
            continue

    return jobs


def scrape_jobs(
    config: dict,
    keywords: list[str] | None = None,
    location: str | None = None,
    hours_old: int = 24,
    max_workers: int = 3,
    return_details: bool = False,
) -> list[dict] | tuple[list[dict], dict]:
    """
    Main entry point for SmartProxy scraping.
    Uses ThreadPoolExecutor to parallelise requests across keywords x locations.
    """
    import concurrent.futures
    search_cfg = config.get("search", {})
    keywords_list = keywords or search_cfg.get("keywords", [])
    if location:
        locations = [location]
    else:
        locations = search_cfg.get("locations", []) or [search_cfg.get("location", "") or "Netherlands"]
    api_key = config.get("smartproxy_api_key", "")

    total_tasks = len(keywords_list) * len(locations)
    print(f"[SmartProxy] Scraping {total_tasks} (keywords×locations) with {max_workers} workers")

    # Build flat task list
    tasks = [(kw, loc) for kw in keywords_list for loc in locations if kw and loc]

    if not tasks:
        print("[SmartProxy] No keyword/location tasks configured")
        details = {"task_count": 0, "error_count": 0, "errors": []}
        return ([], details) if return_details else []

    def _fetch(kw_loc):
        kw, loc = kw_loc
        jobs, error_message = scrape_linkedin_api(
            api_key,
            kw,
            loc,
            hours_old=hours_old,
            return_error=True,
        )
        return jobs, error_message

    all_jobs = []
    errors = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_kwloc = {executor.submit(_fetch, t): t for t in tasks}
        for future in concurrent.futures.as_completed(future_to_kwloc):
            kw, loc = future_to_kwloc[future]
            try:
                jobs, error_message = future.result()
                all_jobs.extend(jobs)
                print(f"[SmartProxy] ✓ '{kw}' @ '{loc}' → {len(jobs)} jobs")
                if error_message:
                    errors.append(f"'{kw}' @ '{loc}': {error_message}")
            except Exception as e:
                error_message = f"'{kw}' @ '{loc}': {e}"
                errors.append(error_message)
                print(f"[SmartProxy] ✗ {error_message}", file=sys.stderr)

    all_jobs = deduplicate_jobs(all_jobs)
    all_jobs.sort(key=lambda j: j.get("posted_date", ""), reverse=True)
    print(f"[SmartProxy] Total after dedup: {len(all_jobs)}")
    details = {
        "task_count": len(tasks),
        "error_count": len(errors),
        "errors": errors,
        "error_summary": _summarize_errors(errors),
    }
    if return_details:
        return all_jobs, details
    return all_jobs


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Scrape LinkedIn jobs via SmartProxy Web Scraper API")
    parser.add_argument("--config", default="/home/cap/script/jobTracker/config.json")
    parser.add_argument("--keywords", nargs="+")
    parser.add_argument("--location")
    parser.add_argument("--hours", type=int, default=24)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--output", "-o")
    args = parser.parse_args()

    config = load_config(args.config)
    jobs = scrape_jobs(config, keywords=args.keywords, location=args.location, hours_old=args.hours, max_workers=args.workers)

    output = json.dumps(jobs, indent=2, default=str)
    if args.output:
        with open(args.output, "w") as f:
            f.write(output)
        print(f"Saved {len(jobs)} jobs to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[SmartProxy] Fatal error: {e}", file=sys.stderr)
        sys.exit(1)
