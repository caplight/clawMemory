#!/bin/bash
# daily_job_hunt.sh — Job Tracker 定时任务入口
# JobSpy: 每天 17:00 和 21:30 各跑一次
# JSearch: 每 2 天跑一次（由 run_search.py 控制状态文件）
# 流程: init_db → run_search → fix_descriptions → score_jobs → notion_sync → feishu
set -euo pipefail

SCRIPT_DIR="/home/cap/script/jobTracker"
PYTHON="/usr/bin/python3"
TODAY=$(date +%Y-%m-%d)
STATUS_FILE="/tmp/jobtracker_scraper_status.json"
LOG_FILE="/home/cap/logs/job_tracker.log"
LOCK_FILE="/home/cap/logs/job_tracker.lock"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG_FILE"; }

append_error() {
    PIPELINE_ERRORS+=("$1")
    log "$1"
}

send_final_feishu() {
    local exit_code="${1:-0}"
    local error_text=""

    if [ "$FEISHU_SENT" -eq 1 ]; then
        rm -f "$LOCK_FILE"
        return
    fi
    FEISHU_SENT=1

    if [ "$exit_code" -ne 0 ]; then
        append_error "[Shell] daily_job_hunt.sh exited with code $exit_code"
    fi

    if [ "${#PIPELINE_ERRORS[@]}" -gt 0 ]; then
        error_text="$(printf '%s\n' "${PIPELINE_ERRORS[@]}")"
    fi

    log "[Step 5] Sending Feishu notification..."
    if [ -n "$error_text" ]; then
        if ! "$PYTHON" "$SCRIPT_DIR/send_feishu.py" --date "$TODAY" --status-file "$STATUS_FILE" --error "$error_text" 2>&1 | tee -a "$LOG_FILE"; then
            log "[Step 5] Feishu send error"
        fi
    else
        if ! "$PYTHON" "$SCRIPT_DIR/send_feishu.py" --date "$TODAY" --status-file "$STATUS_FILE" 2>&1 | tee -a "$LOG_FILE"; then
            log "[Step 5] Feishu send error"
        fi
    fi

    rm -f "$LOCK_FILE"
}

# Ensure log dir exists
mkdir -p "$(dirname "$LOG_FILE")"

# Prevent concurrent runs
if [ -f "$LOCK_FILE" ]; then
    PID=$(cat "$LOCK_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        log "Already running (PID $PID), skipping."
        exit 0
    fi
    log "Stale lock file, removing."
fi
echo $$ > "$LOCK_FILE"
PIPELINE_ERRORS=()
FEISHU_SENT=0
trap 'send_final_feishu $?' EXIT
rm -f "$STATUS_FILE"

log "========================================"
log "Job Tracker run starting..."

# Step 1: Init MySQL table
log "[Step 1] Initializing MySQL table..."
if mysql -u root -proot2026pass < "$SCRIPT_DIR/init_db.sql" 2>&1 | tee -a "$LOG_FILE"; then
    log "[Step 1] MySQL table ready"
else
    append_error "[Step 1] MySQL table init failed"
fi

# Step 2: Scrape + dedup + save to MySQL
# Pass --skip-jsearch if JSearch was already run today (21:30 slot)
RUN_SEARCH_ARGS=(--status-file "$STATUS_FILE")
if [[ "${1:-}" == "--skip-jsearch" ]]; then
    RUN_SEARCH_ARGS+=(--skip-jsearch)
    log "[Step 2] Running JobSpy only (JSearch skipped for this slot)"
fi

TOTAL_COUNT=0
if ! "$PYTHON" "$SCRIPT_DIR/run_search.py" "${RUN_SEARCH_ARGS[@]}" 2>&1 | tee -a "$LOG_FILE"; then
    append_error "[Step 2] run_search.py failed"
fi

# Get counts
NEW_COUNT=$(mysql -u root -proot2026pass job_tracker -N -e \
    "SELECT COUNT(*) FROM jobs WHERE DATE(scraped_at)='$TODAY';" 2>/dev/null || echo 0)
TOTAL_COUNT=$(mysql -u root -proot2026pass job_tracker -N -e \
    "SELECT COUNT(*) FROM jobs;" 2>/dev/null || echo 0)
log "[Step 2] Scraped: new_today=$NEW_COUNT, total=$TOTAL_COUNT"

# Step 2b: Fix LinkedIn/Indeed job descriptions that came back NULL
FIXED_COUNT=0
if "$PYTHON" "$SCRIPT_DIR/fix_descriptions.py" 2>&1 | tee -a "$LOG_FILE"; then
    FIXED_COUNT=$(mysql -u root -proot2026pass job_tracker -N -e \
        "SELECT COUNT(*) FROM jobs WHERE DATE(scraped_at)='$TODAY' AND description IS NOT NULL AND description!='' AND match_score IS NULL;" 2>/dev/null || echo 0)
    log "[Step 2b] Descriptions fixed: $FIXED_COUNT jobs ready for re-scoring"
else
    append_error "[Step 2b] fix_descriptions.py failed"
fi

# Step 3: Score unscored jobs
log "[Step 3] Scoring jobs..."
SCORED_COUNT=0
ABOVE_COUNT=0
if ! "$PYTHON" "$SCRIPT_DIR/score_jobs.py" 2>&1 | tee -a "$LOG_FILE"; then
    append_error "[Step 3] score_jobs.py failed"
fi
SCORED_COUNT=$(mysql -u root -proot2026pass job_tracker -N -e \
    "SELECT COUNT(*) FROM jobs WHERE match_score IS NOT NULL AND DATE(scraped_at)='$TODAY';" 2>/dev/null || echo 0)
ABOVE_COUNT=$(mysql -u root -proot2026pass job_tracker -N -e \
    "SELECT COUNT(*) FROM jobs WHERE match_score IS NOT NULL AND match_score>=50 AND DATE(scraped_at)='$TODAY';" 2>/dev/null || echo 0)
log "[Step 3] Scored: $SCORED_COUNT today, $ABOVE_COUNT above threshold today"

# Step 4: Sync to Notion
log "[Step 4] Syncing to Notion..."
if ! "$PYTHON" "$SCRIPT_DIR/notion_sync.py" 2>&1 | tee -a "$LOG_FILE"; then
    append_error "[Step 4] notion_sync.py failed"
fi

log "========================================"
log "Job Tracker run completed."
