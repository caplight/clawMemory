#!/usr/bin/env python3
"""
score_jobs.py — Full-profile scoring for Job Tracker.
Uses resume content directly + job description in prompt.
Outputs structured analysis: overall score, category breakdown, strengths, gaps,
resume suggestions, hiring decision, ATS keyword analysis.
"""

import json
import re
import sys
import os
import re
import PyPDF2
import pymysql
import requests
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, str(Path(__file__).parent))
from common.config import load_config

CONFIG_PATH = "/home/cap/script/jobTracker/config.json"
MYSQL_CONFIG = {
    "host": os.environ.get("MYSQL_HOST", "localhost"),
    "user": os.environ.get("MYSQL_USER", "root"),
    "password": os.environ.get("MYSQL_PASSWORD", "root2026pass"),
    "database": "job_tracker",
    "charset": "utf8mb4",
}
MINIMAX_API_KEY = os.environ.get(
    "MINIMAX_API_KEY",
    "sk-cp-fQZxgx_WiWnu46I4AEHhprLAhHEVlr6_7s9vsTrX5Z-1rdhKPzo_8q-KrDdvlv_VhIgmMS3b7OK80MiM-4-f9Ni7PJx-p_98nqJUMRSaUrIpKge8rDTx-RE"
)
MINIMAX_API_BASE = os.environ.get("MINIMAX_API_BASE", "https://api.minimaxi.com/v1")
MINIMAX_MODEL    = os.environ.get("MINIMAX_MODEL", "MiniMax-M2.7")

# ============================================================
# Resume Loading
# ============================================================
def load_resume_text(resume_path: str) -> str:
    path = Path(resume_path).expanduser()
    if not path.exists():
        print(f"[scoring] Resume not found: {path}", file=sys.stderr)
        return ""
    suffix = path.suffix.lower()
    try:
        if suffix == '.pdf':
            text = []
            with open(path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    text.append(page.extract_text() or '')
            return ' '.join(text)
        elif suffix == '.docx':
            from docx import Document
            doc = Document(str(path))
            return ' '.join(p.text for p in doc.paragraphs)
        else:
            return path.read_text(errors='ignore')
    except Exception as e:
        print(f"[scoring] Could not read resume: {e}", file=sys.stderr)
        return ""


# ============================================================
# Keyword Scoring (weight=0.6)
# ============================================================
_RESUME_KEYWORDS = [
    'rag', 'langchain', 'lora', 'fine-tuning', 'knowledge graph', 'neo4j',
    'llm', 'gpt', 'deepseek', 'nlp', 'transformer', 'hugging face',
    'cuda', 'pytorch', 'tensorflow', 'machine learning', 'ai',
    'chatbot', 'agent', 'ai agent', 'agentic',
    'kafka', 'flink', 'clickhouse', 'redis', 'rabbitmq', 'elasticsearch',
    'etl', 'data pipeline', 'data engineer', 'data architecture',
    'kubernetes', 'eks', 'docker', 'helm', 'prometheus', 'aws', 'ec2', 's3',
    'distributed systems', 'microservices', 'cloud-native',
    'react', 'angular', 'typescript', 'node.js', 'frontend', 'front-end',
    'python', 'go', 'golang', 'java',
    'real-time analytics', 'real-time', 'streaming', 'edge computing',
    'scrum master', 'agile', 'jira',
    'carrier', 'hvac', 'diagnostics', 'predictive maintenance',
    'digital twin', 'digital twin',
    'big data', 'data analytics', 'statistics',
]

_BONUS_RULES = [
    (['ai engineer', 'agent engineer', 'ai architect', 'data engineer',
      'ml engineer', 'software engineer', 'backend engineer',
      'cloud engineer', 'devops', 'sre', 'platform engineer'], 15),
    (['distributed systems', 'real-time', 'streaming', 'kafka', 'flink', 'clickhouse'], 10),
    (['rag', 'knowledge graph', 'neo4j', 'llm', 'gpt', 'deepseek', 'hugging face'], 10),
    (['agent', 'ai agent', 'agentic'], 10),
    (['kubernetes', 'docker', 'aws', 'cloud-native', 'microservices'], 8),
    (['digital twin', 'predictive maintenance', 'fault detection', 'anomaly detection'], 8),
    (['remote', 'hybrid'], 5),
]


def keyword_score_job(job: dict, resume_keywords: list[str]) -> tuple[int, str]:
    text = (job.get('title', '') or '') + ' ' + (job.get('description', '') or '') + ' ' + (job.get('company', '') or '')
    text_lower = text.lower()
    score = 0
    matches = []
    for kw in resume_keywords:
        # Word-boundary match: ensures 'rag' does NOT match 'encourage', 'go' does NOT match 'golang'
        if re.search(r'\b' + re.escape(kw) + r'\b', text_lower):
            score += 5
            matches.append(kw)
    for keywords, pts in _BONUS_RULES:
        if any(re.search(r'\b' + re.escape(kw) + r'\b', text_lower) for kw in keywords):
            score += pts
    score = min(score, 100)
    reason = f"Matches: {', '.join(matches[:8])}" if matches else 'General fit'
    return score, reason


# ============================================================
# Full Profile Semantic Scoring (weight=0.4)
# Uses resume content directly + job description in prompt
# ============================================================
SEMANTIC_PROMPT_TEMPLATE = """You are a senior technical recruiter with 10+ years of experience hiring for software engineering, AI/ML, and AI agent development roles. You have worked closely with hiring managers and understand how resumes are screened, shortlisted, and evaluated in real-world hiring pipelines.

Your task is to evaluate a candidate's resume against a given Job Description (JD).

## Input
Candidate Resume:
{resume}

## Job Description (JD):
Title: {title}
Company: {company}
Description: {description}

## Instructions

### 1. Overall Match Score (0-100)
Give a single score representing how well the candidate matches the JD.
Calibrate strictly (70 = borderline interview, 80+ = strong candidate, 90+ = top-tier).

### 2. Category Breakdown (each 0-100)
Evaluate and score:
- Technical Skills Match
- Relevant Experience
- AI / Agent Development Expertise (if applicable)
- System Design / Architecture
- Impact & Achievements
- Education & Background

### 3. Strengths
List 4-6 key strengths directly aligned with the JD. Be specific.

### 4. Gaps / Weaknesses
Identify missing or weak areas relative to the JD.

### 5. Resume Optimization Suggestions
Provide actionable improvements: bullet rewriting, missing keywords, positioning advice.

### 6. Hiring Decision Simulation
Choose: Reject / Consider / Interview / Strong Interview
Briefly justify from a recruiter's perspective.

### 7. ATS Keyword Match Analysis
Extract top 10-15 keywords from the JD, check if present in resume.

## Output Format
Return ONLY valid JSON with this exact structure — no markdown, no extra text:
{{
  "overall_score": <0-100 integer>,
  "technical_skills": <0-100 integer>,
  "experience": <0-100 integer>,
  "ai_agent": <0-100 integer>,
  "architecture": <0-100 integer>,
  "impact": <0-100 integer>,
  "education": <0-100 integer>,
  "strengths": ["strength1", "strength2", "..."],
  "gaps": ["gap1", "gap2", "..."],
  "resume_suggestions": ["suggestion1", "suggestion2", "..."],
  "hiring_decision": "reject|consider|interview|strong_interview",
  "ats_present": ["keyword1", "keyword2", "..."],
  "ats_missing": ["jd_keyword1", "jd_keyword2", "..."]
}}
"""


def semantic_score_job(job: dict, resume_text: str) -> dict:
    """Returns full structured dict from LLM."""
    desc = (job.get('description', '') or '')[:4000] or 'No description available.'
    prompt = SEMANTIC_PROMPT_TEMPLATE.format(
        resume=resume_text,
        title=job.get('title', ''),
        company=job.get('company', ''),
        description=desc,
    )

    try:
        resp = requests.post(
            f"{MINIMAX_API_BASE}/chat/completions",
            headers={
                "Authorization": f"Bearer {MINIMAX_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": MINIMAX_MODEL,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 1500,
                "temperature": 0.1,
            },
            timeout=120,
        )
        raw = resp.json().get("choices", [{}])[0].get("message", {}).get("content", "")

        # Extract JSON block
        m = re.search(r'\{[\s\S]*\}', raw)
        if not m:
            print(f"[Semantic] No JSON found in response: {raw[:200]}", file=sys.stderr)
            return _default_semantic_result()
        text = m.group(0)
        data = json.loads(text)
        return {
            "overall_score": int(data.get("overall_score", 50)),
            "technical_skills": int(data.get("technical_skills", 50)),
            "experience": int(data.get("experience", 50)),
            "ai_agent": int(data.get("ai_agent", 50)),
            "architecture": int(data.get("architecture", 50)),
            "impact": int(data.get("impact", 50)),
            "education": int(data.get("education", 50)),
            "strengths": data.get("strengths", []),
            "gaps": data.get("gaps", []),
            "resume_suggestions": data.get("resume_suggestions", []),
            "hiring_decision": data.get("hiring_decision", "consider"),
            "ats_present": data.get("ats_present", []),
            "ats_missing": data.get("ats_missing", []),
        }
    except json.JSONDecodeError as e:
        print(f"[Semantic] JSON parse error: {e} | raw: {raw[:200]}", file=sys.stderr)
        return _default_semantic_result()
    except Exception as e:
        print(f"[Semantic] Error: {e}", file=sys.stderr)
        return _default_semantic_result()


def _default_semantic_result() -> dict:
    return {
        "overall_score": 50, "technical_skills": 50, "experience": 50,
        "ai_agent": 50, "architecture": 50, "impact": 50, "education": 50,
        "strengths": [], "gaps": [], "resume_suggestions": [],
        "hiring_decision": "consider", "ats_present": [], "ats_missing": [],
    }


MAX_WORKERS = 3          # 并发评分线程数
SCORING_BATCH_SIZE = 60   # 每次从 DB 取多少条出来评分
def score_all_jobs():
    config = load_config(CONFIG_PATH)
    scoring_cfg = config.get("scoring", {})
    kw_weight = scoring_cfg.get("keyword_weight", 0.6)
    sem_weight = scoring_cfg.get("semantic_weight", 0.4)
    threshold = scoring_cfg.get("score_threshold", 50)

    resume_path = config.get("resume_path", "")
    resume_text = load_resume_text(resume_path)
    if not resume_text:
        print("[Scoring] Resume empty, aborting", file=sys.stderr)
        return 0, 0

    resume_keywords = [k for k in _RESUME_KEYWORDS if k in resume_text.lower()]
    print(f"[Scoring] Resume: {len(resume_text)} chars, {len(resume_keywords)} keywords matched")

    # Load unscored jobs
    conn = pymysql.connect(**MYSQL_CONFIG)
    cursor = conn.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM jobs WHERE match_score IS NULL AND is_read=0 ORDER BY scraped_at DESC LIMIT %s", (SCORING_BATCH_SIZE,))
    jobs = cursor.fetchall()
    conn.close()

    if not jobs:
        print("[Scoring] No unscored jobs")
        return 0, 0

    print(f"[Scoring] Scoring {len(jobs)} jobs with {MAX_WORKERS} workers (kw_weight={kw_weight}, sem_weight={sem_weight})")

    def score_one_job(args):
        i, job = args

        # Handle NULL description: classify by source/URL instead of scoring
        desc = job.get('description') or ''
        if not desc:
            source = job.get('source', '')
            url = job.get('url') or ''
            # 判断是否为明确的职位URL（不是公司页面）
            # LinkedIn /jobs/view/ = 职位详情页
            # LinkedIn /company/ = 公司主页，不算职位
            is_linkedin_job = ('/jobs/view/' in url)
            is_indeed_job = (source == 'indeed')
            is_indeed_job_posting = is_indeed_job and ('viewjob' in url and '/jobs/view/' not in url)

            if is_linkedin_job:
                # LinkedIn职位详情页：即使description抓不到，同步到Notion人工审核
                decision = 'consider'
                reason = 'LinkedIn职位详情页，description抓不到，需人工审核'
                match_score = 50  # 刚好过阈值，sync到Notion
                kw_score = 0
                sem_score = 0
            elif is_indeed_job_posting:
                # Indeed职位详情页：即使description抓不到，同步到Notion人工审核
                decision = 'consider'
                reason = 'Indeed职位详情页，description抓不到，需人工审核'
                match_score = 50  # 刚好过阈值，sync到Notion
                kw_score = 0
                sem_score = 0
            elif is_indeed_job:
                # Indeed但非职位详情页（可能是公司页）
                decision = 'pending'
                reason = 'Indeed源但非职位页，description抓不到，暂列待定'
                match_score = 0
                kw_score = 0
                sem_score = 0
            else:
                decision = 'unevaluable'
                reason = '公司页URL，description抓不到，无法评估'
                match_score = 0
                kw_score = 0
                sem_score = 0

            print(f"  [{i+1}/{len(jobs)}] {job['title'][:50]} | {reason}")
            conn2 = pymysql.connect(**MYSQL_CONFIG)
            cur2 = conn2.cursor()
            cur2.execute("""
                UPDATE jobs SET
                    match_score=%s, keyword_score=%s, semantic_score=%s,
                    match_reason=%s, hiring_decision=%s, is_read=1
                WHERE id=%s
            """, (match_score, kw_score, sem_score, reason, decision, job['id']))
            conn2.commit()
            conn2.close()
            return None  # MUST return None so as_completed unpacking doesn't fail

        kw_score, kw_reason = keyword_score_job(job, resume_keywords)
        sem = semantic_score_job(job, resume_text)
        final_score = round(kw_score * kw_weight + sem["overall_score"] * sem_weight, 2)
        match_reason = f"[KW:{kw_score}×{kw_weight}={round(kw_score*kw_weight,1)}][SEM:{sem['overall_score']}×{sem_weight}={round(sem['overall_score']*sem_weight,1)}] {kw_reason}"
        print(f"  [{i+1}/{len(jobs)}] {job['title'][:50]} | kw={kw_score} sem={sem['overall_score']} final={final_score} | {sem['hiring_decision']}")
        conn2 = pymysql.connect(**MYSQL_CONFIG)
        cur2 = conn2.cursor()
        cur2.execute("""
            UPDATE jobs SET
                match_score=%s, keyword_score=%s, semantic_score=%s, match_reason=%s,
                technical_skills_score=%s, experience_score=%s, ai_agent_score=%s,
                architecture_score=%s, impact_score=%s, education_score=%s,
                strengths=%s, gaps=%s, resume_suggestions=%s,
                hiring_decision=%s, ats_keywords_present=%s, ats_keywords_missing=%s,
                is_read=1
            WHERE id=%s
        """, (
            final_score, kw_score, sem["overall_score"], match_reason,
            sem["technical_skills"], sem["experience"], sem["ai_agent"],
            sem["architecture"], sem["impact"], sem["education"],
            json.dumps(sem["strengths"], ensure_ascii=False),
            json.dumps(sem["gaps"], ensure_ascii=False),
            json.dumps(sem["resume_suggestions"], ensure_ascii=False),
            sem["hiring_decision"],
            json.dumps(sem["ats_present"], ensure_ascii=False),
            json.dumps(sem["ats_missing"], ensure_ascii=False),
            job["id"],
        ))
        conn2.commit()
        conn2.close()
        return job["id"], final_score

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(score_one_job, (i, job)): i for i, job in enumerate(jobs)}
        for future in as_completed(futures):
            try:
                result = future.result()
                if result is None:
                    continue  # pending/unevaluable job, already handled in score_one_job
                job_id, score = result
            except Exception as e:
                print(f"  [!] Error scoring job: {e}", file=sys.stderr)

    return len(jobs), threshold


if __name__ == "__main__":
    scored, threshold = score_all_jobs()
    print(f"\nResult: {scored} scored")
