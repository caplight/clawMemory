#!/usr/bin/env python3
"""Maynooth University PhD Job Scraper using Playwright

CoreHR eRecruitment: Job IDs are embedded in JavaScript calls like:
  javascript:viewTheJobSpec('041103')
  
We extract these IDs and navigate to job detail pages.
"""

import os
import re
from datetime import datetime
from typing import List, Tuple, Optional

from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout
import pymysql

DB_CONFIG = {
    'host': os.environ.get('MYSQL_HOST', 'localhost'),
    'user': os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', ''),
    'database': os.environ.get('MYSQL_DATABASE', 'phd_jobs')
}

KEYWORDS = [
    'ai', 'machine learning', 'deep learning', 'agent', 'computer science', 'edge',
    'iot', 'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
    'embedded', 'neural', 'foundation model', 'generative ai', 'causal',
    'explainable ai', 'software', 'data science', 'quantum', 'robot', 'cognitive'
]

SOURCE = 'maynoothuniversity.ie'
COREHR_SEARCH = 'https://my.corehr.com/pls/nuimrecruit/erq_search_version_4.search_form?p_company=1&p_internal_external=E'
# Job spec detail URL - extracted from JavaScript:viewTheJobSpec function
JOBSPEC_URL = 'https://my.corehr.com/pls/nuimrecruit/erq_jobspec_version_4.display_form?p_company=1&p_internal_external=E&p_display_in_irish=N&p_process_type=&p_applicant_no=&p_form_profile_detail=&p_display_apply_ind=Y&p_refresh_search=Y&p_recruitment_id={job_id}'


def save_job(title, url, employer, published, deadline, full_text):
    conn = None
    try:
        conn = pymysql.connect(**DB_CONFIG, autocommit=True)
        cursor = conn.cursor()
        if len(full_text) > 3000:
            full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
        cursor.execute(
            "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (title, SOURCE, url, employer, published, deadline, full_text)
        )
        cursor.close()
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()


def matches_keywords(text: str) -> bool:
    if not text:
        return False
    return any(kw.lower() in text.lower() for kw in KEYWORDS)


def is_postdoc(title: str) -> bool:
    return bool(re.search(r"\bpostdoc\b", title, re.I))


def parse_date(s: str) -> Optional[str]:
    if not s:
        return None
    for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%B %d, %Y', '%d-%b-%Y', '%d %B %Y']:
        try:
            return datetime.strptime(s.strip(), fmt).strftime('%Y-%m-%d')
        except:
            pass
    return None


def extract_deadline(text: str) -> Optional[str]:
    patterns = [
        r'Closing\s*Date[:\s]*([\d\-\/\w\s]+?)(?:\n|$)',
        r'Deadline[:\s]*([\d\-\/\w\s]+?)(?:\n|$)',
        r'Apply\s*by[:\s]*([\d\-\/\w\s]+?)(?:\n|$)',
        r'(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4})',
    ]
    for pat in patterns:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            d = parse_date(m.group(1).strip())
            if d:
                return d
    return None


def run_search_and_get_job_ids(page) -> List[str]:
    """Submit search and extract job IDs from JavaScript calls."""
    # Click search button
    page.click('a.erq_small_button')
    page.wait_for_load_state('networkidle', timeout=20000)
    
    # Extract job IDs from javascript:viewTheJobSpec('ID') calls
    html = page.content()
    job_ids = re.findall(r"javascript:viewTheJobSpec\('(\d+)'\)\"", html)
    # Deduplicate
    return list(dict.fromkeys(job_ids))


def fetch_job_detail(browser, job_id: str) -> Tuple[Optional[str], str, Optional[str]]:
    """Fetch job detail page and return (title, full_text, deadline)."""
    job_url = JOBSPEC_URL.format(job_id=job_id)
    try:
        detail_page = browser.new_page()
        detail_page.goto(job_url, wait_until='domcontentloaded', timeout=15000)
        detail_page.wait_for_timeout(500)  # Brief wait for JS rendering
        
        # Extract title from "Job Title :" pattern in table
        body_text = detail_page.inner_text('body') if detail_page.query_selector('body') else ''
        title = None
        m = re.search(r'Job Title\s*[:.]\s*([^\n\t]+)', body_text)
        if m:
            title = m.group(1).strip()
        
        if not title:
            # Fallback to page title
            title = detail_page.title()
            if title:
                title = re.sub(r'\s*-\s*Maynooth.*$', '', title).strip()
        
        if not title:
            # Last resort: regex on HTML
            html = detail_page.content()
            m = re.search(r'Job Title\s*[:.]\s*([^<>"]+)', html)
            if m:
                title = m.group(1).strip()
        
        # Clean up title
        if title:
            title = re.sub(r'\s*-\s*Maynooth.*$', '', title).strip()
        
        # Extract deadline from "Closing Date :" pattern
        deadline = None
        dm = re.search(r'Closing\s*Date\s*[:.]\s*([\d\-\w\s]+?)(?:\n|$)', body_text)
        if dm:
            deadline = parse_date(dm.group(1).strip())
        
        # Full text - use body text
        full_text = body_text
        
        detail_page.close()
        return title, full_text, deadline
    except Exception as e:
        print(f"  Error fetching job {job_id}: {e}")
        return None, '', None


def scrape() -> Tuple[int, int]:
    found = 0
    saved = 0

    print(f"[Maynooth] Starting Playwright browser...")

    with sync_playwright() as p:
        try:
            browser = p.chromium.launch(
                headless=True,
                args=['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
            )

            context = browser.new_context(
                user_agent='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            )

            page = context.new_page()
            page.set_default_timeout(30000)

            # Step 1: Load search form
            print(f"  Loading CoreHR search form...")
            page.goto(COREHR_SEARCH, wait_until='domcontentloaded')
            page.wait_for_timeout(1000)

            # Step 2: Search for Research positions
            print(f"  Searching for Research positions...")
            select_el = page.query_selector('select[name="p_competition_type"]')
            if select_el:
                select_el.select_option('RES')
            
            research_ids = run_search_and_get_job_ids(page)
            print(f"  Found {len(research_ids)} Research job IDs: {research_ids}")

            # Step 3: Also get all jobs
            print(f"  Searching for ALL positions...")
            # Go back to form
            page.goto(COREHR_SEARCH, wait_until='domcontentloaded')
            page.wait_for_timeout(1000)
            
            all_ids = run_search_and_get_job_ids(page)
            print(f"  Found {len(all_ids)} total job IDs")

            # Combine and deduplicate
            all_job_ids = list(dict.fromkeys(research_ids + all_ids))
            print(f"  Total unique job IDs: {len(all_job_ids)}")

            # Step 4: Process each job
            for job_id in all_job_ids:
                job_url = JOBSPEC_URL.format(job_id=job_id)
                
                # Fetch detail
                title, full_text, deadline = fetch_job_detail(browser, job_id)
                if not title:
                    print(f"  SKIP (no title): {job_id}")
                    continue

                title = re.sub(r'\s*-\s*Maynooth.*$', '', title).strip()

                if is_postdoc(title):
                    print(f"  SKIP (postdoc): {title[:60]}")
                    continue

                if not matches_keywords(title + ' ' + full_text):
                    print(f"  SKIP (no kw): {title[:60]}")
                    continue

                found += 1

                if save_job(title, job_url, 'Maynooth University', None, deadline, full_text):
                    saved += 1
                    print(f"  SAVED: {title[:70]}")
                else:
                    print(f"  FAILED: {title[:70]}")

            page.close()
            context.close()
            browser.close()

        except Exception as e:
            print(f"  [Maynooth] Playwright error: {e}")
            import traceback
            traceback.print_exc()

    print(f"[Maynooth] Done. Found {found}, saved {saved}")
    return found, saved


if __name__ == '__main__':
    scrape()
