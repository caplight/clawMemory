#!/usr/bin/env python3
"""Maynooth University PhD Job Scraper - uses pinchtab for JS-rendered pages"""

import os
import re
import subprocess
import time
from datetime import datetime

import requests
from bs4 import BeautifulSoup
import pymysql

DB_CONFIG = {
    'host': os.environ.get('MYSQL_HOST', 'localhost'),
    'user': os.environ.get('MYSQL_USER', 'root'),
    'password': os.environ.get('MYSQL_PASSWORD', ''),
    'database': os.environ.get('MYSQL_DATABASE', 'phd_jobs')
}

KEYWORDS = [
    'ai', 'machine learning', 'deep learning', 'agent', 'computer science', 'edge',
    'iot', 'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
    'embedded', 'neural', 'foundation model', 'generative ai', 'causal',
    'explainable ai', 'software', 'data science', 'quantum', 'robot', 'cognitive'
]

SOURCE = 'maynoothuniversity.ie'
HEADERS = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'}

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)
PINCHTAB_TOKEN = os.environ.get('PINCHTAB_TOKEN', '16f5906eb44c584e3d7a7ff1a6569281abc1b2b5e0411f03')
PINCHTAB_URL = 'http://localhost:9867'

def pinchtab_get(url, output_file):
    """Fetch a URL using pinchtab (StealthyFetcher) and save to file."""
    try:
        result = subprocess.run(
            ['scrapling', 'extract', 'stealthy-fetch', url, output_file],
            capture_output=True, text=True, timeout=30
        )
        return result.returncode == 0
    except Exception as e:
        print(f"  [pinchtab] Error: {e}")
        return False

def save_job(title, url, employer, published, deadline, full_text):
    conn = None
    try:
        conn = pymysql.connect(**DB_CONFIG, autocommit=True)
        cursor = conn.cursor()
        if len(full_text) > 3000:
            full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
        cursor.execute(
            "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s)",
            (title, SOURCE, url, employer, published, deadline, full_text)
        )
        cursor.close()
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def matches_keywords(text):
    if not text:
        return False
    return any(kw.lower() in text.lower() for kw in KEYWORDS)

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def parse_date(s):
    if not s:
        return None
    for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%B %d, %Y', '%d-%b-%Y']:
        try:
            return datetime.strptime(s.strip(), fmt).date()
        except:
            pass
    return None

def scrape():
    found = 0
    saved = 0
    
    # Try main vacancies page first, then CoreHR
    # Try main vacancies page first, then CoreHR
    base_url = 'https://www.maynoothuniversity.ie/human-resources/vacancies'
    output_file = '/tmp/maynooth_pinchtab.html'
    
    print(f"[Maynooth] Fetching {base_url} via pinchtab...")
    
    # Use pinchtab/scrapling to get the JS-rendered page
    success = pinchtab_get(base_url, output_file)
    
    if not success or not os.path.exists(output_file):
        print(f"[Maynooth] pinchtab failed, falling back to direct request...")
        resp = requests.get(base_url, headers=HEADERS, timeout=15)
        print(f"[Maynooth] Direct request: {resp.status_code}")
        html_content = resp.text
    else:
        with open(output_file) as f:
            html_content = f.read()
        print(f"[Maynooth] Got {len(html_content)} bytes via pinchtab")
    
    soup = BeautifulSoup(html_content, 'html.parser')
    job_links = []
    
    for a in soup.find_all('a', href=True):
        href = a['href']
        # Match actual job/PhD vacancy links
        if any(k in href.lower() for k in ['vacancy', 'job', 'position', '/phd-', 'researcher']):
            if len(a.get_text(strip=True)) > 5:
                if href.startswith('http'):
                    job_links.append(href)
                elif href.startswith('/'):
                    job_links.append('https://www.maynoothuniversity.ie' + href)
    
    job_links = list(set(job_links))
    print(f"[Maynooth] Found {len(job_links)} potential job links")
    
    for url in job_links:
        try:
            time.sleep(0.5)
            jresp = requests.get(url, headers=HEADERS, timeout=15)
            if jresp.status_code != 200:
                continue
            
            jsoup = BeautifulSoup(jresp.text, 'html.parser')
            # Try og:title first
            meta = jsoup.find('meta', attrs={'name': 'og:title'}) or jsoup.find('meta', attrs={'property': 'og:title'})
            if meta:
                title = meta.get('content', '').strip()
            else:
                title_tag = jsoup.find('h1') or jsoup.find('h2') or jsoup.find('title')
                title = title_tag.get_text(strip=True) if title_tag else ''
            
            text_content = jsoup.get_text(separator=' ', strip=True)
            
            if is_postdoc(title):
                continue
            
            # Check keywords against both title AND full text
            if not matches_keywords(title + ' ' + text_content):
                continue
            deadline = None
            for pat in [r'Closing\s*Date[:\s]*([\d\-\/\w\s]+)', r'Deadline[:\s]*([\d\-\/\w\s]+)']:
                m = re.search(pat, text_content, re.IGNORECASE)
                if m and not deadline:
                    deadline = parse_date(m.group(1))
            
            if save_job(title, url, 'Maynooth University', None, deadline, text_content):
                saved += 1
                print(f"  SAVED: {title[:60]}")
            else:
                print(f"  SKIPPED/ERROR: {title[:60]}")
                
        except Exception as e:
            print(f"  Error fetching {url}: {e}")
    
    print(f"[Maynooth] Done. Found {found}, saved {saved}")
    return found, saved

if __name__ == '__main__':
    scrape()
