#!/usr/bin/env python3
"""Trinity College Dublin PhD Job Scraper - CS Department

The TCD School of CS page (tcd.ie/scss/vacancies/) has PhD opportunities embedded
as HTML accordion sections (NOT separate detail pages). Jobs appear as:
  - <h3 class="accordion__title"><button>PhD in AI Engineering</button></h3>
  - <div class="accordion__panel">...description + PDF link...</div>

We parse these sections directly from the list page.
"""

import os
import re
import time

import requests
from bs4 import BeautifulSoup
import pymysql

SOURCE = 'tcd.ie'
LIST_URL = 'https://www.tcd.ie/scss/vacancies/'

KEYWORDS = ['ai', 'machine learning', 'deep learning', 'agent', 'computer science', 'edge',
            'iot', 'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
            'embedded', 'neural', 'foundation model', 'generative ai', 'causal',
            'explainable ai', 'software', 'data science', 'quantum', 'robot', 'cognitive']

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def save_job(title, url, employer, published=None, deadline=None, full_text=""):
    conn = None
    try:
        conn = pymysql.connect(
            host=os.environ.get('MYSQL_HOST', 'localhost'),
            user=os.environ.get('MYSQL_USER', 'root'),
            password=os.environ.get('MYSQL_PASSWORD', ''),
            database=os.environ.get('MYSQL_DATABASE', 'phd_jobs'),
            autocommit=True
        )
        with conn.cursor() as cur:
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            cur.execute(
                "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                (title, SOURCE, url, employer, published, deadline, full_text)
            )
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def title_matches_keywords(title):
    t = title.lower()
    return any(kw in t for kw in KEYWORDS)

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def parse_date(s):
    if not s:
        return None
    for fmt in ['%Y-%m-%d', '%d/%m/%Y', '%d-%b-%Y', '%B %d, %Y']:
        try:
            return time.strftime('%Y-%m-%d', time.strptime(s.strip(), fmt))
        except:
            pass
    return None

def scrape():
    print(f"Scraping TCD CS (PhD accordion parser)...")
    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'}
    
    jobs_found = 0
    jobs_saved = 0
    
    try:
        resp = requests.get(LIST_URL, headers=headers, timeout=15)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        # TCD PhD jobs are in accordion sections under <h3 class="accordion__title">
        # Each section contains a <button> with the PhD title and a sibling <div class="accordion__panel">
        accordion_titles = soup.find_all('h3', class_='accordion__title')
        print(f"  Found {len(accordion_titles)} accordion sections")
        
        for title_block in accordion_titles:
            # Get job title from <button> inside <h3>
            button = title_block.find('button')
            if not button:
                continue
            raw_title = button.get_text(strip=True)
            
            # Skip non-PhD sections
            if 'phd' not in raw_title.lower() and not title_matches_keywords(raw_title):
                print(f"  SKIP (no keyword): {raw_title[:60]}")
                continue
            
            if is_postdoc(raw_title):
                print(f"  SKIP (postdoc): {raw_title[:60]}")
                continue
            
            # Get the panel div (sibling to h3)
            panel = title_block.find_next_sibling('div', class_='accordion__panel')
            if not panel:
                continue
            
            # Find PDF link in the panel
            pdf_links = panel.find_all('a', href=True)
            job_url = None
            for a in pdf_links:
                href = a['href']
                if href.endswith('.pdf') and '/pdf' in href.lower():
                    if href.startswith('/'):
                        job_url = 'https://www.tcd.ie' + href
                    else:
                        job_url = href
                    break
            
            if not job_url:
                # Try any href that looks like a detail page
                for a in pdf_links:
                    href = a['href']
                    if 'phd' in href.lower() or '/vacancies/' in href:
                        if href.startswith('/'):
                            job_url = 'https://www.tcd.ie' + href
                        else:
                            job_url = href
                        break
            
            # Use the list URL as fallback (TCD doesn't always have a detail page)
            if not job_url:
                job_url = LIST_URL + '#' + raw_title.replace(' ', '-')
            
            # Extract text content from panel
            full_text = panel.get_text(separator=' ', strip=True)
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            
            # Try to find deadline in panel text
            deadline = None
            deadline_patterns = [
                r'Deadline[:\s]*([\d]+[-\/][\d]+[-\/][\d]+)',
                r'Closing\s*Date[:\s]*([\d]+[-\/][\d]+[-\/][\d]+)',
                r'(\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4})',
            ]
            for pat in deadline_patterns:
                m = re.search(pat, full_text, re.IGNORECASE)
                if m:
                    deadline = parse_date(m.group(1))
                    if deadline:
                        break
            
            jobs_found += 1
            title = raw_title
            employer = 'Trinity College Dublin'
            
            if save_job(title, job_url, employer, None, deadline, full_text):
                jobs_saved += 1
                print(f"  SAVED: {title[:60]}")
            else:
                print(f"  FAILED: {title[:60]}")
                
    except Exception as e:
        print(f"  Error on list page: {e}")
    
    print(f"  => Total found: {jobs_found}, Saved: {jobs_saved}")
    return jobs_found, jobs_saved

if __name__ == '__main__':
    scrape()
