#!/usr/bin/env python3
"""University of Galway PhD Job Scraper"""

import os
import re
import time

import requests
from bs4 import BeautifulSoup
import pymysql

SOURCE = 'universityofgalway.ie'
LIST_URLS = [
    'https://www.universityofgalway.ie/human-resources/recruitment-and-selection/current-vacancies/',
    'https://www.universityofgalway.ie/about-us/jobs/research/',
]

KEYWORDS = ['ai', 'machine learning', 'deep learning', 'agent', 'computer science', 'edge',
            'iot', 'orchestrator', 'orchestration', 'autonomous', 'distributed systems',
            'embedded', 'neural', 'foundation model', 'generative ai', 'causal',
            'explainable ai', 'software', 'data science', 'quantum', 'robot', 'cognitive']

POSTDOC_RE = re.compile(r"\bpostdoc\b", re.I)

def save_job(title, url, employer, published=None, deadline=None, full_text=""):
    conn = None
    try:
        conn = pymysql.connect(
            host=os.environ.get('MYSQL_HOST', 'localhost'),
            user=os.environ.get('MYSQL_USER', 'root'),
            password=os.environ.get('MYSQL_PASSWORD', ''),
            database=os.environ.get('MYSQL_DATABASE', 'phd_jobs'),
            autocommit=True
        )
        with conn.cursor() as cur:
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            cur.execute(
                "INSERT INTO jobs (title, source, url, employer, published, deadline, full_text) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                (title, SOURCE, url, employer, published, deadline, full_text)
            )
        return True
    except Exception as e:
        print(f"  [DB ERROR] {e}")
        return False
    finally:
        if conn:
            conn.close()

def title_matches_keywords(title):
    t = title.lower()
    return any(kw in t for kw in KEYWORDS)

def is_postdoc(title):
    return bool(POSTDOC_RE.search(title))

def scrape():
    print(f"Scraping University of Galway...")
    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'}
    
    all_jobs = {}
    
    for list_url in LIST_URLS:
        try:
            resp = requests.get(list_url, headers=headers, timeout=15)
            if resp.status_code == 429:
                retry_after = resp.headers.get("Retry-After", "60")
                print(f"  [WARN] Rate limited, waiting {retry_after}s...")
                time.sleep(int(retry_after))
                continue
            resp.raise_for_status()
            soup = BeautifulSoup(resp.text, 'html.parser')
            
            for a in soup.find_all('a', href=True):
                href = a.get('href', '')
                if any(k in href.lower() for k in ['phd', 'postdoc', 'research', 'vacancy']):
                    if href.startswith('/'):
                        full_url = 'https://www.universityofgalway.ie' + href
                    elif href.startswith('http'):
                        full_url = href
                    else:
                        continue
                    title_text = a.get_text(strip=True)
                    if title_text and len(title_text) > 10:
                        all_jobs[full_url] = title_text
            
            time.sleep(0.5)
        except Exception as e:
            print(f"  Error fetching {list_url}: {e}")
    
    print(f"  Found {len(all_jobs)} job URLs")
    
    saved = 0
    for url, title in all_jobs.items():
        print(f"  Processing: {title[:60]}...")
        time.sleep(0.3)
        try:
            dr = requests.get(url, headers=headers, timeout=15)
            if dr.status_code == 429:
                retry_after = dr.headers.get("Retry-After", "60")
                print(f"  [WARN] Rate limited, waiting {retry_after}s...")
                time.sleep(int(retry_after))
                continue
            if not dr.status_code == 200:
                continue
            dsoup = BeautifulSoup(dr.text, 'html.parser')
            
            if is_postdoc(title) or not title_matches_keywords(title):
                print(f"    SKIP")
                continue
            
            employer = 'University of Galway'
            published = None
            deadline = None
            full_text = dsoup.get_text(separator=' ', strip=True)
            if len(full_text) > 3000:
                full_text = full_text[:3000].rsplit(" ", 1)[0] + "..."
            
            if save_job(title, url, employer, published, deadline, full_text):
                saved += 1
                print(f"    SAVED")
        except Exception as e:
            print(f"    ERROR: {e}")
    
    print(f"  Total saved: {saved}")

if __name__ == '__main__':
    scrape()
