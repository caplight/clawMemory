# MEMORY.md - Long-Term Memory

## 关于 WechatBot

此为独立的 WechatBot 实例，workspace 隔离，不与主煤煤共享记忆。
