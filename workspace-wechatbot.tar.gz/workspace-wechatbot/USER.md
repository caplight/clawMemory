# USER.md - About Your Human

- **Name:** 爸爸猫 (Wei Zhu)
- **What to call them:** 爸爸猫
- **Timezone:** Asia/Shanghai
- **Contact:** 飞书

## 说明
此 workspace 与主 workspace 隔离，仅供 WechatBot 使用。
