# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

---

Add whatever helps you do your job. This is your cheat sheet.

## Codex CLI（newbot workspace）
- **版本：** codex-cli 0.57.0
- **配置：** `~/.codex/config.toml`
- **运行命令：**
```bash
source ~/.profile && unset OPENAI_API_KEY && unset OPENAI_BASE_URL && \
  codex exec --profile m27 -C /home/cap/projects --skip-git-repo-check '任务描述'
```
- **关键：** 必须清除 `OPENAI_API_KEY`，否则走 OpenAI 而非 MiniMax
- **模型：** `MiniMax-M2.7`，provider `minimax`
- **base_url：** `https://api.minimaxi.com/v1`

## 携程机票监控配置

**脚本**：`/root/.openclaw/workspace-newbot/scripts/ctrip_flights_hook.py`

**Cookie失效时的处理**：
1. 妈妈猫在携程特价机票页面按F12打开Network
2. 找到`fuzzySearch`请求，右键 → Copy → Copy as cURL
3. 把完整的curl命令发给煤煤
4. 煤煤从curl中提取新的Cookie和相关header更新脚本

**当前监控国家**：全中国(≤1500)、马来西亚、日本、韩国、泰国、新加坡(均≤2500)
**查询条件**：上海出发，4.30或5.1出发，5-6天往返
