#!/usr/bin/env python3
"""
飞书群候选人自动登记脚本 v5
规则：
- MINIMAX：PDF附件 + 同发送人的文本消息（岗位-城市格式）= 一条完整记录
- KOL：PDF附件 + 同发送人的KOL模板文本 = 一条完整记录
- 字节跳动：PDF附件 + 同发送人的"城市+字节BD"文本 = 一条完整记录
- HTML格式（无标准城市+字节BD格式）→ 报错误，人工处理
- 去重（姓名+项目+岗位相同算重复）
- 按推荐日期升序，紧凑写入
- 只处理今天发送的消息
"""
import json, re, os
from datetime import date, datetime, timezone, timedelta

SPREADSHEET_TOKEN = "ZxDKsepz5hzm8PtcNcUcrKUwnfe"
SHEET_ID = "00872f"
LOG_FILE = "/root/.openclaw/workspace-newbot/scripts/.register_log_v5"
LAST_FILES = {
    "oc_550fe92c1598eccdd9de308157eda095": "/root/.openclaw/workspace-newbot/scripts/.last_msg_douyin",
    "oc_978d6a0c1b28c3eb9d5496031a33e479": "/root/.openclaw/workspace-newbot/scripts/.last_msg_zhaopin",
}

MEMBERS = {
    "ou_fff9103206dfc5695fbcee4be212769e": "张本超",
    "ou_7e3c9b258c00ced92ad49afd39f04711": "李睿冰",
    "ou_4e9f8a6b14be53802581bcec16375022": "赵航",
    "ou_4803cd7260b528c0a3b34a134c544c52": "蒙雪君",
    "ou_7efb58679bb3bfcb60f7745082b158f5": "李锐",
    "ou_a53f0c139c017aab4fd4717bae5bc76b": "张本育",
    "ou_1262b7d53486b73dd91f51ee7b751da1": "罗晓婉",
    "ou_981ba595436335d2e8d79b8466d950e0": "刘川旗",
    "ou_66a368e50ca3621b454a442a8a05e8ce": "李远",
}

MINIMAX_POSITIONS = {
    "海外广告视频投放": "海外广告投放视频设计师",
    "海外广告投放视频制作": "海外广告投放视频设计师",
    "AI对话-安全攻防": "AI对话-安全攻防",
    "AI创意视频制作": "AI创意视频制作",
    "AI视频模版设计师": "AI视频模版设计师",
    "测试工程师": "测试工程师",
    "创意策划-信息流方向": "创意策划-信息流方向",
    "广告投放视频设计师": "广告投放视频设计师",
    "国内安全-BPO交付运营": "国内安全-BPO交付运营",
    "国内安全-审核运营": "国内安全-审核运营",
    "海外广告投放视频设计师": "海外广告投放视频设计师",
    "开发者内容创作": "开发者内容创作",
    "前端工程师": "前端工程师",
    "视频创意内容设计师": "视频创意内容设计师",
    "视频内容AI数据标注师": "视频内容AI数据标注师",
    "用户体验-客服": "用户体验-客服",
}

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def get_token():
    import urllib.request
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        data=json.dumps({"app_id": "cli_a9343ba5a3a2dbd6", "app_secret": "ckjjFzhjZGqR7fXkyIm8ZdIAAoSBjUyN"}).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())["tenant_access_token"]

def date_serial(d): return (d - date(1899, 12, 30)).days
def today_serial(): return date_serial(date.today())

def msg_to_date(create_time_ms):
    try:
        ts = int(create_time_ms) / 1000
        return datetime.fromtimestamp(ts, tz=timezone.utc).astimezone(timezone(timedelta(hours=8))).date()
    except: return date.today()

def extract_text(raw):
    try:
        p = json.loads(raw)
        if isinstance(p, dict) and "text" in p: return p["text"]
    except: pass
    return ""

# ---- 解析器 ----

def parse_douyin(clean_text, sender_id):
    """字节跳动格式，返回 (candidate, error_str)"""
    # 匹配：城市+字节生服BD/字节BD 或 城市+生活服务商家BD
    m = re.search(r"^(.+?)(?:字节生服BD|字节BD|生活服务商家BD)[:：]?\s*\n?姓名[：:]([^\n]+)", clean_text, re.M)
    if not m:
        # HTML格式
        if re.search(r"姓名[：:]\S+", clean_text) and ("<p>" in clean_text or "<br" in clean_text.lower()):
            nm = re.search(r"姓名[：:]\s*([^\n<]+)", clean_text)
            name = nm.group(1).strip() if nm else "未知"
            city_m = re.search(r"(.+?)字节生服BD|字节BD", clean_text)
            city = city_m.group(1).strip().replace("字节生服BD","").replace("字节BD","").strip() if city_m else "未知"
            sender_name = MEMBERS.get(sender_id, sender_id)
            return None, f"[HTML需人工] {name} | 城市:{city} | 推荐人:{sender_name} | 学历见原文"
        return None, None
    city = m.group(1).replace("字节生服BD", "").replace("字节BD", "").replace("生活服务商家BD", "").strip()
    name = m.group(2).strip()
    edu_m = re.search(r"学历[：:]\s*(\S+)", clean_text)
    edu = ""
    if edu_m:
        e = edu_m.group(1).strip()
        edu = "本科及以上" if e in ("本科", "大学本科") else e
    return {
        "project": "字节跳动", "position": f"生活服务商家BD-{city}",
        "name": name, "sender_id": sender_id,
        "sender_name": MEMBERS.get(sender_id, sender_id),
        "recommend_date": None, "cooperation_mode": "RPO",
        "education": edu or "本科及以上", "remarks": ""
    }, None

def parse_kol(text, sender_id):
    """KOL格式"""
    m = re.search(r"(.+?)KOL简历推荐模板", text)
    if not m: return None
    nm = re.search(r"姓名[：:]\s*(\S+)", text)
    if not nm: return None
    name = nm.group(1).strip()
    edu_m = re.search(r"学历[：:]\s*(\S+)", text)
    edu = ""
    if edu_m:
        e = edu_m.group(1).strip()
        edu = "本科及以上" if e in ("本科", "大学本科") else e
    tj = re.search(r"推荐语[：:]\s*(.+?)(?:\n|$)", text, re.DOTALL)
    return {
        "project": "创想科技", "position": "KOL",
        "name": name, "sender_id": sender_id,
        "sender_name": MEMBERS.get(sender_id, sender_id),
        "recommend_date": None, "cooperation_mode": "RPO",
        "education": edu or "本科及以上",
        "remarks": tj.group(1).strip()[:200] if tj else ""
    }

def parse_minimax(text, sender_id):
    """MINIMAX格式"""
    nm = re.search(r"姓名[：:]\s*(\S+)", text)
    if not nm: return None
    name = nm.group(1).strip()
    # 格式：岗位-城市 + \n + 数字、姓名
    pos_m = re.search(r"^([^\n]+?)\s*\n?\s*\d[、.]\s*姓名", text)
    if not pos_m: return None
    raw_prefix = pos_m.group(1).strip()
    pos_m2 = re.search(r"(.+?)-([^\s-]+)$", raw_prefix)
    if not pos_m2: return None
    raw_pos, city = pos_m2.group(1).strip(), pos_m2.group(2).strip()
    position = MINIMAX_POSITIONS.get(raw_pos)
    if not position: return None
    edu_m = re.search(r"学历[：:]\s*(\S+)", text)
    edu = ""
    if edu_m:
        e = edu_m.group(1).strip()
        edu = "本科及以上" if e in ("本科", "大学本科") else e
    return {
        "project": "MINIMAX", "position": position,
        "name": name, "sender_id": sender_id,
        "sender_name": MEMBERS.get(sender_id, sender_id),
        "recommend_date": None, "cooperation_mode": "外包",
        "education": edu or "本科及以上", "remarks": ""
    }

# ---- 表格操作 ----

def get_last_row(token):
    """找A列最后一个有数据的行号"""
    import urllib.request
    last_row = 1
    for start in range(2, 3000, 100):
        url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_ID}!A{start}:F{start+99}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        try:
            with urllib.request.urlopen(req) as r:
                data = json.loads(r.read())
            vals = data.get("data", {}).get("valueRange", {}).get("values", [])
            non_empty = [(start+i, r[0]) for i, r in enumerate(vals) if r and r[0] is not None]
            if non_empty:
                last_row = non_empty[-1][0]
        except:
            break
    return last_row

def write_row(token, row_num, c):
    import urllib.request
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values"
    payload = {"valueRange": {"range": f"{SHEET_ID}!A{row_num}:R{row_num}",
                               "values": [[
        c["recommend_date"] or today_serial(), c["sender_name"], "李睿冰",
        c["project"], c["cooperation_mode"], c["name"], "",
        c["education"], c["position"],
        "", "", "", "", "", "", "", "", ""
    ]]}}
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="PUT")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

# ---- 主逻辑 ----

def process_group(token, chat_id, lfile):
    last_time = None
    if os.path.exists(lfile):
        with open(lfile) as f:
            for line in f:
                if line.startswith("last_time="):
                    last_time = line.split("=", 1)[1].strip()

    all_items = []
    page_token = None
    while True:
        url = (f"https://open.feishu.cn/open-apis/im/v1/messages"
               f"?container_id_type=chat&container_id={chat_id}"
               f"&sort_type=ByCreateTimeDesc&page_size=50")
        if page_token: url += f"&page_token={page_token}"
        import urllib.request
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req) as r:
            data = json.loads(r.read())
        items = data.get("data", {}).get("items", [])
        has_more = data.get("data", {}).get("has_more", False)
        page_token = data.get("data", {}).get("page_token", "")

        page_min_time = None
        for item in items:
            t = item.get("create_time", "")
            if page_min_time is None: page_min_time = t
            if last_time and last_time != "0" and t <= last_time:
                # 找到旧消息，继续翻下一页（不要break，因为同页还有更新的消息）
                continue
            if item.get("deleted"): continue
            sid = item.get("sender", {}).get("id", "")
            if not sid: continue
            all_items.append(item)

        # 停止条件：没有更多页 OR （有last_time且当前页最老消息<=last_time）
        if not has_more:
            break
        if last_time and last_time != "0" and page_min_time and page_min_time <= last_time:
            break

    all_items.reverse()  # 旧→新
    newest = all_items[-1].get("create_time", "") if all_items else None

    # 建立sender→PDF时间的映射（找最近的PDF消息时间，毫秒）
    pdf_by_sender = {}
    for item in all_items:
        if item.get("msg_type") == "file":
            sid = item.get("sender", {}).get("id", "")
            t = item.get("create_time", "")
            # 只记录今天的消息
            if msg_to_date(t) == date.today():
                if sid not in pdf_by_sender or t > pdf_by_sender[sid]:
                    pdf_by_sender[sid] = t

    # 宽松PDF判定：文本消息前后30秒内有同发送人的PDF即算有效
    PDF_WINDOW_MS = 30000

    candidates, errors = [], []
    seen = set()

    for item in all_items:
        sid = item.get("sender", {}).get("id", "")
        mtype = item.get("msg_type", "")
        raw = item.get("body", {}).get("content", "")
        txt = extract_text(raw)
        create_time = item.get("create_time", "")
        msg_date = msg_to_date(create_time)

        # 只处理今天的
        if msg_date != date.today(): continue

        # 宽松PDF判定：前后30秒内有同发送人的PDF即算有效
        has_pdf = False
        if sid in pdf_by_sender:
            pdf_t = int(pdf_by_sender[sid])
            cur_t = int(create_time)
            if abs(pdf_t - cur_t) <= PDF_WINDOW_MS:
                has_pdf = True

        if chat_id == "oc_550fe92c1598eccdd9de308157eda095":
            clean = re.sub(r"<[^>]+>", "", txt)
            c, err = parse_douyin(clean, sid)
            if err: errors.append(err)
            elif c:
                if not has_pdf: continue  # 必须有PDF才算有效
                c["recommend_date"] = date_serial(msg_date)
                key = (c["name"], c["project"], c["position"])
                if key in seen: continue
                seen.add(key)
                candidates.append(c)

        elif chat_id == "oc_978d6a0c1b28c3eb9d5496031a33e479":
            # KOL格式
            c = parse_kol(txt, sid)
            if c and has_pdf:
                c["recommend_date"] = date_serial(msg_date)
                key = (c["name"], c["project"], c["position"])
                if key not in seen:
                    seen.add(key)
                    candidates.append(c)
                continue

            # MINIMAX格式
            c2 = parse_minimax(txt, sid)
            if c2 and has_pdf:
                c2["recommend_date"] = date_serial(msg_date)
                key = (c2["name"], c2["project"], c2["position"])
                if key not in seen:
                    seen.add(key)
                    candidates.append(c2)
                continue

    return candidates, errors, newest

def main():
    log("=== 候选人登记任务(v5) ===")
    token = get_token()
    all_cands, all_errors = [], []
    dn, zn = None, None

    cands, errs, dn = process_group(token, "oc_550fe92c1598eccdd9de308157eda095", LAST_FILES["oc_550fe92c1598eccdd9de308157eda095"])
    all_cands.extend(cands); all_errors.extend(errs)
    for c in cands: log(f"  ✅ [字节跳动] {c['name']} | {c['position']}")
    for e in errs: log(f"  ⚠️  {e}")

    cands, errs, zn = process_group(token, "oc_978d6a0c1b28c3eb9d5496031a33e479", LAST_FILES["oc_978d6a0c1b28c3eb9d5496031a33e479"])
    all_cands.extend(cands); all_errors.extend(errs)
    for c in cands: log(f"  ✅ [{c['project']}] {c['name']} | {c['position']}")

    if not all_cands and not all_errors:
        log("📭 今天无新候选人")
        if dn: open(LAST_FILES["oc_550fe92c1598eccdd9de308157eda095"],"w").write(f"last_time={dn}")
        if zn: open(LAST_FILES["oc_978d6a0c1b28c3eb9d5496031a33e479"],"w").write(f"last_time={zn}")
        return

    if all_errors:
        log("⚠️ 【需人工处理】")
        for e in all_errors: log(f"  {e}")

    if all_cands:
        all_cands.sort(key=lambda x: x["recommend_date"])
        last_row = get_last_row(token)
        next_row = max(last_row, 1) + 1
        for c in all_cands:
            r = write_row(token, next_row, c)
            log(f"  {'✅' if r.get('code')==0 else '❌'} 第{next_row}行: {c['name']} | {c['project']} | {c['position']}")
            next_row += 1

    if dn: open(LAST_FILES["oc_550fe92c1598eccdd9de308157eda095"],"w").write(f"last_time={dn}")
    if zn: open(LAST_FILES["oc_978d6a0c1b28c3eb9d5496031a33e479"],"w").write(f"last_time={zn}")
    log(f"✅ 完成，共{len(all_cands)}条写入，{len(all_errors)}条格式问题")

if __name__ == "__main__":
    main()
