#!/usr/bin/env python3
"""
飞书群候选人自动登记脚本 v3
- 监控两个群：S-抖音BD内部项目群 & 招聘对接群-PM李睿冰
- 写入新表格（复制表）
- 按推荐日期排序
"""
import json
import re
import os
from datetime import date, datetime

# ====== 配置 ======
SPREADSHEET_TOKEN = "ZxDKsepz5hzm8PtcNcUcrKUwnfe"  # 新表格
SHEET_ID = "00872f"
LAST_MSG_FILES = {
    "oc_550fe92c1598eccdd9de308157eda095": "/root/.openclaw/workspace-newbot/scripts/.last_msg_id_douyin",
    "oc_978d6a0c1b28c3eb9d5496031a33e479": "/root/.openclaw/workspace-newbot/scripts/.last_msg_id_zhaopin",
}
LOG_FILE = "/root/.openclaw/workspace-newbot/scripts/.register_log_v3"

# 群成员工号→姓名映射（两个群共用）
GROUP_MEMBERS = {
    "ou_fff9103206dfc5695fbcee4be212769e": "张本超",
    "ou_7e3c9b258c00ced92ad49afd39f04711": "李睿冰",
    "ou_4e9f8a6b14be53802581bcec16375022": "赵航",
    "ou_4803cd7260b528c0a3b34a134c544c52": "蒙雪君",
    "ou_7efb58679bb3bfcb60f7745082b158f5": "李锐",
    "ou_a53f0c139c017aab4fd4717bae5bc76b": "张本育",
    "ou_1262b7d53486b73dd91f51ee7b751da1": "罗晓婉",
    "ou_981ba595436335d2e8d79b8466d950e0": "刘川旗",
    "ou_66a368e50ca3621b454a442a8a05e8ce": "李远",
}

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def get_token():
    import urllib.request
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        data=json.dumps({"app_id": "cli_a979e8bc7b789bda", "app_secret": "yKUOlPu08bgeeSO8mVVqLd3BvbaJXuYO"}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())["tenant_access_token"]

def date_to_excel_serial(d):
    base = date(1899, 12, 30)
    return (d - base).days

def today_serial():
    return date_to_excel_serial(date.today())

# ========== 解析器1：S-抖音BD内部项目群（字节生服BD格式）==========
def parse_douyin_message(raw_content, sender_id):
    """解析 城市+字节生服BD/字节BD 格式"""
    try:
        text = json.loads(raw_content).get("text", raw_content)
    except:
        text = raw_content

    pattern = r"(.+?字节生服BD|字节BD)[:：]\s*姓名[：:]([^\n]+)"
    match = re.search(pattern, text)
    if not match:
        return None

    city = match.group(1).replace("字节生服BD", "").replace("字节BD", "").strip()
    name = match.group(2).strip()

    result = {
        "city": city,
        "position": f"生活服务商家BD-{city}",
        "name": name,
        "sender_id": sender_id,
        "sender_name": GROUP_MEMBERS.get(sender_id, sender_id),
        "recommend_date": today_serial(),
        "cooperation_mode": "外包",
        "education": "",
        "remarks": ""
    }

    # 提取字段
    for field, pat in [
        ("年龄", r"年龄[：:]\s*(\S+)"),
        ("电话", r"电话[：:]\s*(\S+)"),
        ("邮箱", r"邮箱[：:]\s*(\S+)"),
        ("学历", r"学历[：:]\s*(\S+)"),
    ]:
        m = re.search(pat, text)
        if m:
            val = m.group(1).strip()
            if field == "学历":
                result["education"] = "本科及以上" if val == "本科" else val
            else:
                result[field] = val

    adv_match = re.search(r"个人优势[（][^）]+[）][：:]\s*\n?(.+?)(?:@_user|已推|已传|$)", text, re.DOTALL)
    if adv_match:
        result["remarks"] = adv_match.group(1).strip()[:200]

    if not result["education"]:
        result["education"] = "本科及以上"

    return result

# ========== 解析器2：招聘对接群（KOL简历推荐模板格式）==========
def parse_zhaopin_message(raw_content, sender_id):
    """解析 KOL简历推荐模板 格式"""
    try:
        text = json.loads(raw_content).get("text", raw_content)
    except:
        text = raw_content

    # KOL模板格式：成都KOL简历推荐模板：\n姓名：xxx\n学历：xxx\n...
    kol_pattern = r"(.+?)KOL简历推荐模板"
    match = re.search(kol_pattern, text)
    if not match:
        return None

    city = match.group(1).strip()
    name = re.search(r"姓名[：:]\s*(\S+)", text)
    education = re.search(r"学历[：:]\s*(\S+)", text)

    if not name:
        return None

    result = {
        "city": city,
        "position": "KOL",
        "name": name.group(1).strip(),
        "sender_id": sender_id,
        "sender_name": GROUP_MEMBERS.get(sender_id, sender_id),
        "recommend_date": today_serial(),
        "cooperation_mode": "外包",
        "project": "创想科技",
        "education": "",
        "remarks": ""
    }

    if education:
        edu = education.group(1).strip()
        result["education"] = "本科及以上" if edu == "本科" else edu

    # 提取推荐语
    tj_match = re.search(r"推荐语[：:]\s*(.+?)(?:\n|$)", text, re.DOTALL)
    if tj_match:
        result["remarks"] = tj_match.group(1).strip()[:200]

    if not result["education"]:
        result["education"] = "本科及以上"

    return result

def get_messages(token, chat_id, page_size=50):
    import urllib.request
    url = f"https://open.feishu.cn/open-apis/im/v1/messages?container_id_type=chat&container_id={chat_id}&sort_type=ByCreateTimeDesc&page_size={page_size}"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read()).get("data", {}).get("items", [])

def get_last_data_row(token):
    """找到表格最后有数据的行"""
    import urllib.request
    # 二分查找
    low, high = 2, 3000
    while low < high:
        mid = (low + high + 1) // 2
        url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_ID}!A{mid}:A{mid}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read())
            val = data.get("data", {}).get("valueRange", {}).get("values", [[None]])[0][0]
            if val is not None:
                low = mid
            else:
                high = mid - 1
        except:
            high = mid - 1
    return low

def write_row(token, row_num, values):
    import urllib.request
    cell_range = f"{SHEET_ID}!A{row_num}:R{row_num}"
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values"
    payload = {"valueRange": {"range": cell_range, "values": [values]}}
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="PUT"
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

def find_insert_row(token, recommend_date_serial):
    """找到指定日期应该插入的位置（按日期升序，返回该日期最后一行的下一行）"""
    import urllib.request
    last_row = get_last_data_row(token)
    if last_row <= 1:
        return 2

    # 从最后一行往前找，找到第一个>=指定日期的位置
    for row in range(last_row, 1, -1):
        url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_ID}!A{row}:A{row}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        try:
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read())
            val = data.get("data", {}).get("valueRange", {}).get("values", [[None]])[0][0]
            if val is not None and val <= recommend_date_serial:
                return row + 1
        except:
            pass
    return 2

def build_row(c):
    """构建写入表格的一行"""
    return [
        c["recommend_date"],      # A: 推荐日期
        c["sender_name"],        # B: 具体推荐人
        "李睿冰",                # C: 招聘运营
        c.get("project", "字节跳动"),  # D: 项目名称
        c["cooperation_mode"],   # E: 合作模式
        c["name"],               # F: 姓名
        "",                      # G: 性别
        c["education"],          # H: 学历
        c["position"],           # I: 岗位
        "",                      # J-R: 后续字段留空
    ]

def process_group(token, chat_id, last_msg_file, parser_func):
    """处理单个群的消息"""
    messages = get_messages(token, chat_id)

    # 读取上次处理的消息时间
    last_msg_time = None
    if os.path.exists(last_msg_file):
        with open(last_msg_file) as f:
            for line in f:
                if line.startswith("last_msg_time="):
                    last_msg_time = line.split("=", 1)[1].strip()

    # 筛选新消息
    new_messages = []
    newest_time = None
    for msg in messages:
        msg_time = msg.get("create_time", "")
        if newest_time is None:
            newest_time = msg_time
        if last_msg_time and msg_time <= last_msg_time:
            break
        if msg.get("deleted"):
            continue
        new_messages.append(msg)

    new_messages = list(reversed(new_messages))

    candidates = []
    for msg in new_messages:
        if msg.get("msg_type") not in ("text", "post"):
            continue
        raw_content = msg.get("body", {}).get("content", "")
        sender_id = msg.get("sender", {}).get("id", "")
        if not sender_id or not raw_content.strip():
            continue

        candidate = parser_func(raw_content, sender_id)
        if candidate:
            candidates.append((candidate, msg))

    return candidates, newest_time

def main():
    log("=== 开始执行候选人登记任务(v3) ===")
    token = get_token()

    all_candidates = []

    # 处理S-抖音BD内部项目群
    douyin_candidates, douyin_newest = process_group(
        token,
        "oc_550fe92c1598eccdd9de308157eda095",
        LAST_MSG_FILES["oc_550fe92c1598eccdd9de308157eda095"],
        parse_douyin_message
    )
    for c, msg in douyin_candidates:
        log(f"  [抖音BD群] 解析: {c['name']} | {c['position']}")
    all_candidates.extend(douyin_candidates)

    # 处理招聘对接群
    zhaopin_candidates, zhaopin_newest = process_group(
        token,
        "oc_978d6a0c1b28c3eb9d5496031a33e479",
        LAST_MSG_FILES["oc_978d6a0c1b28c3eb9d5496031a33e479"],
        parse_zhaopin_message
    )
    for c, msg in zhaopin_candidates:
        log(f"  [招聘对接群] 解析: {c['name']} | {c['position']}")
    all_candidates.extend(zhaopin_candidates)

    if not all_candidates:
        log("📭 没有发现新的候选人信息")
        return

    # 按推荐日期排序
    all_candidates.sort(key=lambda x: x[0]["recommend_date"])

    # 写入表格（按日期顺序找到插入位置）
    for c, msg in all_candidates:
        insert_row = find_insert_row(token, c["recommend_date"])
        row = build_row(c)
        result = write_row(token, insert_row, row)
        if result.get("code") == 0:
            log(f"  ✅ 写入第{insert_row}行: {c['name']} | {c['position']} (日期={c['recommend_date']})")
        else:
            log(f"  ❌ 写入失败: {result.get('msg', result)}")

    # 更新两个群的处理时间戳
    for chat_id, fname in LAST_MSG_FILES.items():
        newest = douyin_newest if "douyin" in fname else zhaopin_newest
        with open(fname, "w") as f:
            f.write(f"last_msg_time={newest}\n")

    log(f"✅ 完成，共写入 {len(all_candidates)} 条")

if __name__ == "__main__":
    main()
