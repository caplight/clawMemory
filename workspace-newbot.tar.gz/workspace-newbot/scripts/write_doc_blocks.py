#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
将markdown内容转换为飞书文档blocks并写入（简化版）
"""
import requests
import json
import time

APP_ID = "cli_a979e8bc7b789bda"
APP_SECRET = "yKUOlPu08bgeeSO8mVVqLd3BvbaJXuYO"
DOC_TOKEN = "B3kFdegdmobANOxtOrXcopXVnDd"

def get_token():
    resp = requests.post(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}
    )
    return resp.json()["tenant_access_token"]

def make_text_run(text, bold=False, italic=False):
    return {
        "text_run": {
            "content": text,
            "text_element_style": {
                "bold": bold,
                "inline_code": False,
                "italic": italic,
                "strikethrough": False,
                "underline": False
            }
        }
    }

def make_text_block(text, bold=False, italic=False):
    return {
        "block_type": 2,
        "text": {
            "elements": [make_text_run(text, bold, italic)],
            "style": {"align": 1}
        }
    }

def make_heading_block(text, level=1):
    block_type = level + 2
    key = f"heading{level}"
    return {
        "block_type": block_type,
        key: {
            "elements": [make_text_run(text)],
            "style": {"align": 1}
        }
    }

def make_bullet_block(text):
    return {
        "block_type": 12,
        "bullet": {
            "elements": [make_text_run(text)],
            "style": {"align": 1, "folded": False}
        }
    }

def insert_blocks(token, parent_block_id, blocks, index=0):
    url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{DOC_TOKEN}/blocks/{parent_block_id}/children"
    payload = {"children": blocks, "index": index}
    resp = requests.post(url,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        json=payload
    )
    result = resp.json()
    if resp.status_code != 200 or result.get("code") != 0:
        print(f"插入失败: {resp.status_code} - {result}")
        return False
    return True

def parse_md_to_blocks(md_text):
    """将markdown文本转换为Feishu blocks（简化版）"""
    lines = md_text.split("\n")
    blocks = []
    i = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # 跳过空行
        if not stripped:
            i += 1
            continue

        # 分隔线 -> 用特殊文本代替
        if stripped == "---":
            blocks.append(make_text_block("─────────────────────", italic=True))
            i += 1
            continue

        # 标题
        if stripped.startswith("#### "):
            blocks.append(make_heading_block(stripped[5:], 3))
        elif stripped.startswith("### "):
            blocks.append(make_heading_block(stripped[4:], 2))
        elif stripped.startswith("## "):
            blocks.append(make_heading_block(stripped[3:], 1))
        # 引用块（> 开头）-> 用斜体文本代替
        elif stripped.startswith("> "):
            text = stripped[2:]
            blocks.append(make_text_block(text, italic=True))
        # 代码块（``` 开头）
        elif stripped.startswith("```"):
            # 收集代码内容直到下一个 ```
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            code_text = "\n".join(code_lines)
            blocks.append(make_text_block(f"〔代码区块〕\n{code_text}", italic=True))
        # 无序列表
        elif stripped.startswith("- ") or stripped.startswith("* ") or stripped.startswith("• "):
            text = stripped[2:]
            # 处理 **bold** 文字
            if text.startswith("**") and text.endswith("**") and text.count("**") == 2:
                text = "▎ " + text[2:-2]
                blocks.append(make_text_block(text, bold=True))
            else:
                blocks.append(make_bullet_block("▎ " + text))
        # 普通文本
        else:
            # 处理 **bold** 文字
            if stripped.startswith("**") and stripped.endswith("**") and stripped.count("**") == 2:
                blocks.append(make_text_block(stripped[2:-2], bold=True))
            elif stripped.startswith("**") and "**" in stripped[2:]:
                # 部分加粗
                parts = []
                remaining = stripped
                while "**" in remaining:
                    start = remaining.find("**")
                    end = remaining.find("**", start+2)
                    if end == -1:
                        parts.append(make_text_run(remaining))
                        break
                    if start > 0:
                        parts.append(make_text_run(remaining[:start]))
                    parts.append(make_text_run(remaining[start+2:end], bold=True))
                    remaining = remaining[end+2:]
                if remaining:
                    parts.append(make_text_run(remaining))
                blocks.append({
                    "block_type": 2,
                    "text": {"elements": parts, "style": {"align": 1}}
                })
            else:
                blocks.append(make_text_block(stripped))

        i += 1

    return blocks

def write_document():
    token = get_token()

    # 读取markdown
    with open("/tmp/interview_reminder_v2.md", "r", encoding="utf-8") as f:
        md_content = f.read()

    # 解析为blocks
    blocks = parse_md_to_blocks(md_content)
    print(f"解析出 {len(blocks)} 个blocks")

    # 分批插入（每次最多30个避免超时）
    batch_size = 30

    for i in range(0, len(blocks), batch_size):
        batch = blocks[i:i+batch_size]
        success = insert_blocks(token, DOC_TOKEN, batch, index=i)
        if not success:
            print(f"插入失败在第 {i} 个block")
            return False
        print(f"已插入 {min(i+batch_size, len(blocks))}/{len(blocks)} 个blocks")
        time.sleep(0.5)

    print("✅ 文档写入完成！")
    return True

if __name__ == "__main__":
    write_document()
