#!/bin/bash
# 读取飞书群消息并登记到招聘运营数据台账表格
# 使用说明：每天12点、17点自动执行

TOKEN=$(curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d '{"app_id": "cli_a9343ba5a3a2dbd6", "app_secret": "ckjjFzhjZGqR7fXkyIm8ZdIAAoSBjUyN"}' | python3 -c "import sys,json; print(json.load(sys.stdin).get('tenant_access_token',''))")

# 群ID
CHAT_ID="oc_550fe92c1598eccdd9de308157eda095"

# 获取最新消息（最后50条）
MESSAGES=$(curl -s -X GET "https://open.feishu.cn/open-apis/im/v1/messages?container_id_type=chat&container_id=${CHAT_ID}&sort_type=ByCreateTimeDesc&page_size=50" \
  -H "Authorization: Bearer ${TOKEN}")

echo "$MESSAGES"
