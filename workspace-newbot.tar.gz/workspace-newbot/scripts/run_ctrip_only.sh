#!/bin/bash
# 携程机票监控 - 仅携程模式（禁用飞猪/Skyscanner/Google）
cd /root/.openclaw/workspace-newbot/scripts
FLIGGY=0 SKYSCANNER=0 GOOGLE=0 python3 ctrip_flights_hook.py
