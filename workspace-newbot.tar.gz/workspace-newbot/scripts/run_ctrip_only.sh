#!/bin/bash
# 携程机票监控 - 仅携程模式（禁用飞猪/Skyscanner/Google）
# 去程：6月23日 上海→成都 | 返程：6月30日 成都→上海（7天往返）
# 推送：与 PhD cron job 同步（飞书群 8833b911-2c46-456c-bf32-89beba681352）
# 日志：/root/.openclaw/workspace-newbot/scripts/.ctrip_flights_hook.log
cd /root/.openclaw/workspace-newbot/scripts
env FLIGGY=0 SKYSCANNER=0 GOOGLE=0 /usr/bin/python3 ctrip_flights_hook.py