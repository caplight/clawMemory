#!/usr/bin/env python3
"""
中国银行 人民币换欧元 汇率监控
阈值：EUR现汇卖出价 < 793 时推送提醒
数据源：中国银行外汇牌价
"""
import urllib.request
import json
import time
import os
from datetime import datetime

# ============================================================
# 配置
# ============================================================
THRESHOLD = 793.0          # 触发推送的汇率阈值（现汇卖出价）
WEBHOOK_URL = "https://open.feishu.cn/open-apis/bot/v2/hook/7b7ce7f0-e595-43c8-aae0-feb0411e4408"
STATE_FILE = "/root/.openclaw/workspace-newbot/scripts/.boc_eur_state.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
}

def fetch_boc_eur():
    """抓取中国银行欧元汇率"""
    url = "https://www.bankofchina.com/sourcedb/whpj/enindex_1619.html"
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=15) as resp:
        html = resp.read().decode('utf-8')
    
    # HTML结构：<tr data-currency='欧元'> ... <td>EUR</td><td>795.7</td><td>795.7</td><td>801.52</td><td>801.52</td><td>799.41</td><td>时间</td>
    import re
    # 找欧元那一行
    pattern = r"data-currency=['\"]欧元['\"][^>]*>.*?<td[^>]*>EUR</td>(.*?)</tr>"
    match = re.search(pattern, html, re.DOTALL)
    if not match:
        return {}
    
    row_content = match.group(1)
    numbers = re.findall(r'<td[^>]*>([\d.]+)</td>', row_content)
    time_match = re.search(r'(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})', row_content)
    
    if len(numbers) >= 5:
        return {
            'buying_rate': float(numbers[0]),   # 折算买入价
            'cash_buying': float(numbers[1]),    # 现金买入
            'selling_rate': float(numbers[2]),   # 现汇卖出价 ← 关注这个
            'cash_selling': float(numbers[3]),   # 现金卖出
            'middle_rate': float(numbers[4]),    # 中间价
            'pub_time': time_match.group(1) if time_match else 'N/A',
        }
    return {}


def load_state():
    """加载推送状态（避免重复推送）"""
    state_file = STATE_FILE
    if os.path.exists(state_file):
        try:
            with open(state_file) as f:
                return json.load(f)
        except:
            pass
    return {"already_pushed": False}


def save_state(state):
    with open(STATE_FILE, 'w') as f:
        json.dump(state, f)


def send_alert(eur_data, diff):
    """推送飞书消息"""
    msg = {
        "msg_type": "interactive",
        "card": {
            "config": {"wide_screen_mode": True},
            "header": {
                "title": {"tag": "plain_text", "content": "💶 欧元汇率提醒"},
                "template": "red"
            },
            "elements": [
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": (
                            f"**触发时间：** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                            f"🪙 **当前EUR现汇卖出价：{eur_data['selling_rate']}**\n\n"
                            f"📊 **触发阈值：{THRESHOLD}**\n\n"
                            f"📉 **当前已低于阈值！**\n\n"
                            f"跌破 **{diff:.2f}** 个点\n\n"
                            f"🕐 数据发布时间：{eur_data.get('pub_time', 'N/A')}\n\n"
                            f"💡 妈妈猫可以考虑换汇啦～"
                        )
                    }
                },
                {"tag": "hr"},
                {
                    "tag": "note",
                    "elements": [{"tag": "plain_text", "content": "中国银行外汇牌价 · 煤煤猫汇率监控"}]
                }
            ]
        }
    }
    
    data = json.dumps(msg).encode('utf-8')
    req = urllib.request.Request(
        WEBHOOK_URL, data=data,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        result = json.loads(resp.read().decode('utf-8'))
    return result


def main():
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] 开始检查中国银行EUR汇率...")
    
    try:
        eur_data = fetch_boc_eur()
    except Exception as e:
        print(f"抓取汇率失败: {e}")
        return
    
    if not eur_data:
        print("未找到EUR数据")
        return
    
    selling = eur_data['selling_rate']
    middle = eur_data.get('middle_rate', 0)
    pub_time = eur_data.get('pub_time', 'N/A')
    
    print(f"  EUR现汇卖出价: {selling}")
    print(f"  EUR中间价: {middle}")
    print(f"  发布时间: {pub_time}")
    
    state = load_state()
    
    if selling < THRESHOLD:
        diff = THRESHOLD - selling
        print(f"  ⚠️ 低于阈值 {THRESHOLD}！差异: {diff:.2f}")
        
        if not state["already_pushed"]:
            print("  推送飞书提醒...")
            result = send_alert(eur_data, diff)
            if result.get('code') == 0 or result.get('StatusCode') == 0:
                print("  ✅ 推送成功!")
                state["already_pushed"] = True
                state["pushed_rate"] = selling
                state["pushed_time"] = datetime.now().isoformat()
                save_state(state)
            else:
                print(f"  ❌ 推送失败: {result}")
        else:
            print(f"  已推送过（{state.get('pushed_time','N/A')}），跳过")
    else:
        print(f"  ✅ 汇率正常（高于阈值 {THRESHOLD}）")
        # 汇率回升后重置状态，下次再跌还能推
        if state["already_pushed"]:
            print("  汇率已回升，重置推送状态")
            state["already_pushed"] = False
            save_state(state)


if __name__ == "__main__":
    main()
