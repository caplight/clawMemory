#!/usr/bin/env python3
"""
携程特价机票监控脚本
=============================

【功能】
监控上海→成都往返机票，去程6月23日，返程6月30日（7天往返）
从携程网页提取航班价格，组合成最低价往返 Top 5

【主要修改记录 v7.0 — 2026-05-16】
1. 数据源：仅携程（FLIGGY/SKYSCANNER/GOOGLE 全部禁用）
2. 航线：上海→成都往返（仅此一条，不查国际/其他目的地）
3. 日期：去程 2026-06-23，返程 2026-06-30（7天行程）
4. 价格阈值：无限制（移除原 budget 限制）
5. 推送目标：飞书群 Webhook（与 PhD cron job 同步）
   Webhook URL: https://open.feishu.cn/open-apis/bot/v2/hook/8833b911-2c46-456c-bf32-89beba681352
6. 数据获取方式：从携程网页 DOM 提取（Playwright 浏览器）
   - 分两次抓取：去程页面 + 返程页面
   - 组合生成往返 Top 5
   - 注意：携程 API (fuzzySearch) 目前返回 resultType=0，改用 DOM 提取
7. Cron job：每天 21:00 运行（由 run_ctrip_only.sh 启动）

【Flag Control】
- FLIGGY=0        飞猪搜索（默认禁用）
- SKYSCANNER=0    Skyscanner（默认禁用）
- GOOGLE=0        Google Flights（默认禁用）

【运行方式】
  bash run_ctrip_only.sh
  或直接：
  FLIGGY=0 SKYSCANNER=0 GOOGLE=0 python3 ctrip_flights_hook.py

【日志】
  /root/.openclaw/workspace-newbot/scripts/.ctrip_flights_hook.log

【依赖】
  - playwright（pip install playwright; playwright install chromium）
  - scrapling（pip install scrapling）

【版本历史】
  v1-v5: 多数据源版（携程API + 飞猪 + Skyscanner + Google）
  v6:   暂停海外搜索，仅保留携程，API 开始返回空
  v7.0: 2026-05-16 重写，DOM 提取 + 往返组合 + 同步 PhD cron webhook
"""

import json
from playwright.sync_api import sync_playwright
from urllib.request import Request, urlopen
from datetime import datetime

# ============================================================
# 配置
# ============================================================
PINCHTAB_SERVER = "http://localhost:9868"
PINCHTAB_TOKEN = "16f5906eb44c584e3d7a7ff1a6569281abc1b2b5e0411f03"

# 飞书 Webhook（与 PhD cron job 同步）
WEBHOOK_URL = "https://open.feishu.cn/open-apis/bot/v2/hook/8833b911-2c46-456c-bf32-89beba681352"

# 数据源开关（环境变量控制，默认仅携程）
import os
FLIGGY_ENABLED = os.environ.get("FLIGGY", "0") == "1"
SKYSCANNER_ENABLED = os.environ.get("SKYSCANNER", "0") == "1"
GOOGLE_ENABLED = os.environ.get("GOOGLE", "0") == "1"

# ============================================================
# 航班数据 DOM 提取
# ============================================================
import re

def extract_flights(page) -> list:
    """
    从携程航班列表页 DOM 提取航班数据。
    携程页面结构：航空公司名 → 航班号 → 时间 → 机场 → 价格
    价格格式：¥793起 或 ¥820（单位：元）
    """
    text = page.inner_text('body') or ''
    lines = [l.strip() for l in text.split('\n') if l.strip() and len(l.strip()) > 1]

    flights = []
    i = 0
    while i < len(lines) - 3:
        line = lines[i]
        price_yuan = None
        times = []
        airports = []
        flight_no = None

        j = i
        while j < min(i + 22, len(lines)):
            l = lines[j]

            # 价格
            pm = re.search(r'¥(\d+)(?:起)?', l)
            if pm:
                price_yuan = int(pm.group(1))

            # 停止条件：遇到价格边界且已有数据
            if price_yuan and l.startswith('¥') and j > i + 1 and '航空' not in line:
                break

            # 时间（HH:MM 格式）
            tm = re.match(r'^(\d{2}:\d{2})(.*)$', l)
            if tm:
                times.append(tm.group(1))

            # 航班号（如 HO1039, CA4536）
            fnm = re.match(r'^(HO|CA|MU|CZ|3U|KN|9C|MF|CI|BR|QR|LH|EK|SQ|TG|JL|NH|KE|OZ|DL|AA|UA|BA|FR|AY|SK|TK|KL|VS)\s*(\d{3,4})', l)
            if fnm:
                flight_no = f"{fnm.group(1)}{fnm.group(2)}"

            # 机场（如 浦东国际机场T2）
            am = re.match(r'^(浦东|虹桥|首都|大兴|白云|宝安|天府|江北|萧山|黄花|新郑|双流|美兰|凤凰|周水|周口|咸阳|龙嘉|长水|二七|禄口|观音|高崎|流亭|正定|滨海)\w*(T\d)?', l)
            if am:
                airports.append(l)

            # 停止条件
            if price_yuan and l in ['携程旅行网', '登录', '注册', '我的订单'] and j > i + 5:
                break

            j += 1

        if price_yuan and price_yuan > 0 and times:
            valid_times = [t for t in times if re.match(r'\d{2}:\d{2}', t)]
            flights.append({
                'price_yuan': price_yuan,
                'times': valid_times,
                'airports': airports[-2:] if len(airports) >= 2 else airports,
                'flight_no': flight_no,
            })
            i = j - 1
        else:
            i += 1

    return flights


def extract_oneway_price(url: str, context):
    """打开一个 page 抓取单程航班数据"""
    page = context.new_page()
    page.goto(url, timeout=30000, wait_until='networkidle')
    page.wait_for_timeout(6000)
    flights = extract_flights(page)
    page.close()
    return flights


# ============================================================
# 飞书卡片构建
# ============================================================
def build_feishu_card(go_flights: list, back_flights: list, combined: list, now: str) -> dict:
    """构建飞书卡片消息"""

    blocks = []

    # Header
    blocks.append({
        "tag": "markdown",
        "content": (
            f"## 🐱 **上海→成都 往返机票**\n"
            f"📋 **航线**：上海 → 成都 → 上海\n"
            f"📅 **去程**：6月23日（周二） | **返程**：6月30日（周二）\n"
            f"🔗 **数据源**：🇨🇳 携程（Playwright DOM 提取）\n"
            f"⏰ **查询时间**：{now}"
        )
    })

    blocks.append({"tag": "hr"})
    blocks.append({"tag": "markdown", "content": "### ✈️ **Top 5 低价往返组合**"})

    rank = 1
    for c in combined[:5]:
        go = c['go']
        back = c['back']
        go_times = go.get('times', [])
        back_times = back.get('times', [])
        blocks.append({
            "tag": "markdown",
            "content": (
                f"**#{rank}**  💰 **¥{c['total']}**（去¥{go['price_yuan']} + 返¥{back['price_yuan']}）\n"
                f"　去程 {go_times[0] if go_times else '?'}→{go_times[-1] if go_times else '?'} "
                f"【{go.get('flight_no', '?') or '直飞'}】¥{go['price_yuan']}\n"
                f"　返程 {back_times[0] if back_times else '?'}→{back_times[-1] if back_times else '?'} "
                f"【{back.get('flight_no', '?') or '直飞'}】¥{back['price_yuan']}"
            )
        })
        rank += 1

    blocks.append({"tag": "hr"})
    blocks.append({"tag": "markdown", "content": "### 📋 **去程详情（6月23日 上海→成都）**"})
    for f in go_flights:
        times = f.get('times', [])
        lbl = f.get('flight_no') or '?'
        blocks.append({
            "tag": "markdown",
            "content": f"**{lbl}**　{times[0] if times else '?'}→{times[-1] if len(times) > 1 else '?'}　💰 ¥{f['price_yuan']}"
        })

    blocks.append({"tag": "hr"})
    blocks.append({"tag": "markdown", "content": "### 📋 **返程详情（6月30日 成都→上海）**"})
    for f in back_flights:
        times = f.get('times', [])
        lbl = f.get('flight_no') or '?'
        blocks.append({
            "tag": "markdown",
            "content": f"**{lbl}**　{times[0] if times else '?'}→{times[-1] if len(times) > 1 else '?'}　💰 ¥{f['price_yuan']}"
        })

    blocks.append({"tag": "hr"})
    blocks.append({"tag": "markdown", "content": "⚠️ _价格随时变动，请以实际支付时为准_"})

    return {
        "msg_type": "interactive",
        "card": {
            "header": {
                "title": {"tag": "plain_text", "content": "🐱 上海→成都 往返机票"},
                "template": "purple"
            },
            "elements": blocks
        }
    }


def send_feishu(message: dict) -> dict:
    """发送飞书消息"""
    data = json.dumps(message).encode("utf-8")
    req = Request(WEBHOOK_URL, data=data,
                  headers={"Content-Type": "application/json"},
                  method="POST")
    try:
        with urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}


# ============================================================
# 主流程
# ============================================================
def main():
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n[{'='*50}]")
    print(f"[{ts}] 🔍 携程机票监控开始")
    print(f"  数据源：{'携程' if True else ''} "
          f"飞猪 {'(已启用)' if FLIGGY_ENABLED else '(已禁用)'} | "
          f"Skyscanner {'(已启用)' if SKYSCANNER_ENABLED else '(已禁用)'} | "
          f"Google {'(已启用)' if GOOGLE_ENABLED else '(已禁用)'}")
    print(f"  航线：上海→成都（往返）")
    print(f"  去程：2026-06-23 | 返程：2026-06-30")

    errors = []

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled']
            )
            context = browser.new_context(
                viewport={'width': 1280, 'height': 800},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
                extra_http_headers={'Accept-Language': 'zh-CN,zh;q=0.9'}
            )

            # 去程：SHA -> CTU
            print(f"  [携程] 抓取去程 SHA→CTU 6月23日...")
            go_flights = extract_oneway_price(
                'https://flights.ctrip.com/online/list/oneway-sha-ctu?depdate=2026-06-23&cabin=Y_S_C_F',
                context
            )
            print(f"  [携程] 去程找到 {len(go_flights)} 条航班")
            for f in go_flights:
                print(f"    {f.get('flight_no', '?')} {f.get('times', [])} ¥{f['price_yuan']}")

            # 返程：CTU -> SHA
            print(f"  [携程] 抓取返程 CTU→SHA 6月30日...")
            back_flights = extract_oneway_price(
                'https://flights.ctrip.com/online/list/oneway-ctu-sha?depdate=2026-06-30&cabin=Y_S_C_F',
                context
            )
            print(f"  [携程] 返程找到 {len(back_flights)} 条航班")
            for f in back_flights:
                print(f"    {f.get('flight_no', '?')} {f.get('times', [])} ¥{f['price_yuan']}")

            browser.close()

        # 组合往返 Top 5
        combined = []
        for go in go_flights:
            for back in back_flights:
                combined.append({
                    'go': go, 'back': back,
                    'total': go['price_yuan'] + back['price_yuan']
                })
        combined.sort(key=lambda x: x['total'])
        print(f"  组合后共 {len(combined)} 种往返组合")

        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        if go_flights and back_flights:
            card = build_feishu_card(go_flights, back_flights, combined, now)
            result = send_feishu(card)
            if "error" in result:
                print(f"\n❌ 飞书推送失败: {result['error']}")
            else:
                print(f"\n✅ 飞书推送成功！")
                print(f"   Top 5 往返最低 ¥{combined[0]['total']} 元")
        else:
            print(f"\n🤷 没有找到足够的航班数据，跳过推送")
            if not go_flights:
                errors.append("去程航班数据为空")
            if not back_flights:
                errors.append("返程航班数据为空")

    except Exception as e:
        print(f"\n❌ 脚本异常: {e}")
        errors.append(str(e))

    print(f"[{'='*50}]\n")
    return errors


if __name__ == "__main__":
    main()