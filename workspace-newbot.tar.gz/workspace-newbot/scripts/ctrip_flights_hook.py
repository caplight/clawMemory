#!/usr/bin/env python3
"""
携程特价机票监控脚本 v6 (多数据源版)
使用 pinchtab + scrapling 浏览器自动化

功能：监控上海出发至国内/新马泰日韩的特价机票
条件：4.30或5.1出发，5-6天往返
价格阈值：国内≤1500，国际≤2500（单位：人民币）
推送目标：飞书群 Webhook

多数据源：携程 | 飞猪 | Skyscanner | Google Flights
"""
import subprocess
import json
import time
import re
import os
from datetime import datetime, date, timedelta
from typing import Optional, List, Dict

# ============================================================
# 配置
# ============================================================
PINCHTAB_SERVER = "http://localhost:9868"
PINCHTAB_TOKEN = "16f5906eb44c584e3d7a7ff1a6569281abc1b2b5e0411f03"
PROFILE_PATH = "/root/.pinchtab/profiles/default"

# 飞书 Webhook（妈妈猫的群）
WEBHOOK_URL = "https://open.feishu.cn/open-apis/bot/v2/hook/7b7ce7f0-e595-43c8-aae0-feb0411e4408"

BUDGET_DOMESTIC = 1500
BUDGET_INTL = 2500

# 数据源开关（环境变量控制，默认全开）
FLIGGY_ENABLED = os.environ.get("FLIGGY", "1") == "1"
SKYSCANNER_ENABLED = os.environ.get("SKYSCANNER", "1") == "1"
GOOGLE_ENABLED = os.environ.get("GOOGLE", "1") == "1"

# 搜索配置
SEARCH_CONFIGS = [
    {"name": "全中国", "code": "DOMESTIC_ALL", "ct": 3, "budget": BUDGET_DOMESTIC, "tag": "🇨🇳 国内", "is_intl": False},
    {"name": "马来西亚", "code": "MY", "ct": 2, "budget": BUDGET_INTL, "tag": "🇲🇾 马来西亚", "is_intl": True},
    {"name": "日本", "code": "JP", "ct": 2, "budget": BUDGET_INTL, "tag": "🇯🇵 日本", "is_intl": True},
    {"name": "韩国", "code": "KR", "ct": 2, "budget": BUDGET_INTL, "tag": "🇰🇷 韩国", "is_intl": True},
    {"name": "泰国", "code": "TH", "ct": 2, "budget": BUDGET_INTL, "tag": "🇹🇭 泰国", "is_intl": True},
    {"name": "新加坡", "code": "SG", "ct": 2, "budget": BUDGET_INTL, "tag": "🇸🇬 新加坡", "is_intl": True},
]

# 热门国内城市
POPULAR_DOMESTIC = {'北京', '广州', '深圳', '成都', '重庆', '杭州', '西安', '昆明', '厦门', '三亚',
                    '南京', '武汉', '长沙', '青岛', '大连', '天津', '哈尔滨', '沈阳', '郑州', '海口'}

# 城市代码映射
CITY_CODE_MAP = {
    "北京": {"code": "PEK", "name_en": "Beijing"},
    "广州": {"code": "CAN", "name_en": "Guangzhou"},
    "深圳": {"code": "SZX", "name_en": "Shenzhen"},
    "成都": {"code": "CTU", "name_en": "Chengdu"},
    "重庆": {"code": "CKG", "name_en": "Chongqing"},
    "杭州": {"code": "HGH", "name_en": "Hangzhou"},
    "西安": {"code": "XIY", "name_en": "Xian"},
    "昆明": {"code": "KMG", "name_en": "Kunming"},
    "厦门": {"code": "XMN", "name_en": "Xiamen"},
    "三亚": {"code": "SYX", "name_en": "Sanya"},
    "南京": {"code": "NKG", "name_en": "Nanjing"},
    "武汉": {"code": "WUH", "name_en": "Wuhan"},
    "长沙": {"code": "CSX", "name_en": "Changsha"},
    "青岛": {"code": "TAO", "name_en": "Qingdao"},
    "大连": {"code": "DLC", "name_en": "Dalian"},
    "天津": {"code": "TSN", "name_en": "Tianjin"},
    "哈尔滨": {"code": "HRB", "name_en": "Harbin"},
    "沈阳": {"code": "SHE", "name_en": "Shenyang"},
    "郑州": {"code": "CGO", "name_en": "Zhengzhou"},
    "海口": {"code": "HAK", "name_en": "Haikou"},
    "上海": {"code": "SHA", "name_en": "Shanghai"},
    "大阪": {"code": "OSA", "name_en": "Osaka"},
    "东京": {"code": "TYO", "name_en": "Tokyo"},
    "京都": {"code": "KYO", "name_en": "Kyoto"},
    "名古屋": {"code": "NGO", "name_en": "Nagoya"},
    "福冈": {"code": "FUK", "name_en": "Fukuoka"},
    "首尔": {"code": "SEL", "name_en": "Seoul"},
    "济州": {"code": "CJU", "name_en": "Jeju"},
    "曼谷": {"code": "BKK", "name_en": "Bangkok"},
    "普吉": {"code": "HKT", "name_en": "Phuket"},
    "清迈": {"code": "CNX", "name_en": "Chiang Mai"},
    "吉隆坡": {"code": "KUL", "name_en": "Kuala Lumpur"},
    "槟城": {"code": "PEN", "name_en": "Penang"},
    "新加坡": {"code": "SIN", "name_en": "Singapore"},
    "沙巴": {"code": "BKI", "name_en": "Sabah"},
    "巴厘岛": {"code": "DPS", "name_en": "Denpasar"},
}

# ============================================================
# Cookie 和请求头
# ============================================================
TRACE_ID = "09031013317381289023-1774512434871-8823282"
FXPCQLNIREDT = "09031013317381289023"
CID = "09031013317381289023"

COOKIE = """UBT_VID=1774245318103.157153rxHsWr; MKT_CKID=1774245319603.5jz52.fiah; GUID=09031013317381289023; _RGUID=6b185408-b6dc-437f-8490-bcb2be47b49c; MKT_Pagesource=PC; nfes_isSupportWebP=1; cticket=3B8DAA6E8DCB332DD8A150335C1108FEBF7074DFBE8CF3F914F8EFF862C786F6; login_type=0; login_uid=; DUID=u=4691947AF784A131918FB737040D9591&v=0; IsNonUser=F; AHeadUserInfo=VipGrade=10&VipGradeName=%BB%C6%BD%F0%B9%F3%B1%F6&UserName=&NoReadMessageCount=0; _udl=708D70C2B179E2F91CC5ED1C2CCE362D; Hm_lvt_a8d6737197d542432f4ff4abc6e06384=1774245317,1774511702; Hm_lpvt_a8d6737197d542432f4ff4abc6e06384=1774511702; HMACCOUNT=448E78987BE47C49; Session=smartlinkcode=U130727&smartlinklanguage=zh&SmartLinkKeyWord=&SmartLinkQuary=&SmartLinkHost=; Union=AllianceID=4902&SID=130727&OUID=&createtime=1774511708&Expires=1775116507563; _jzqco=%7C%7C%7C%7C%7C1.275156105.1774245319601.1774511708293.1774511736433.1774511708293.1774511736433.0.0.0.3.3; _bfa=1.1774245318103.157153rxHsWr.1.1774511722294.1774512434551.2.4.10650052821"""

HEADERS_BASE = {
    "Accept": "*/*",
    "Accept-Language": "en,en-US;q=0.9,zh-CN;q=0.8,zh;q=0.7",
    "Content-Type": "application/json",
    "Cookie": COOKIE,
    "Origin": "https://flights.ctrip.com",
    "Referer": "https://flights.ctrip.com/",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
}

# ============================================================
# 去重记录（各平台独立去重）
# ============================================================
SEEN_CACHE_FILE = "/tmp/ctrip_flights_seen.json"
FLIGGY_SEEN_FILE = "/tmp/fliggy_flights_seen.json"
SKYSCANNER_SEEN_FILE = "/tmp/skyscanner_flights_seen.json"
GOOGLE_SEEN_FILE = "/tmp/google_flights_seen.json"

PLATFORM_SEEN_FILES = {
    "ctrip": SEEN_CACHE_FILE,
    "fliggy": FLIGGY_SEEN_FILE,
    "skyscanner": SKYSCANNER_SEEN_FILE,
    "google": GOOGLE_SEEN_FILE,
}

def load_seen_cache(platform: str = "ctrip") -> set:
    filepath = PLATFORM_SEEN_FILES.get(platform, SEEN_CACHE_FILE)
    try:
        with open(filepath, "r") as f:
            return set(json.load(f))
    except (FileNotFoundError, json.JSONDecodeError):
        return set()

def save_seen_cache(cache: set, platform: str = "ctrip"):
    filepath = PLATFORM_SEEN_FILES.get(platform, SEEN_CACHE_FILE)
    with open(filepath, "w") as f:
        json.dump(list(cache), f)

def make_seen_key(flight_no: str, price: int, go_date: str) -> str:
    return f"{flight_no}|{price}|{go_date}"

# ============================================================
# 辅助函数
# ============================================================
def format_dur(minutes: int) -> str:
    if not minutes:
        return "?"
    h = minutes // 60
    m = minutes % 60
    return f"{h}h{m}m" if h else f"{m}m"

def safe_int(v, default=0):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default

def dep_city_name() -> str:
    return "上海"

def dep_city_code() -> str:
    return "SHA"

AIRLINE_MAP = {
    "MU": "东方航空", "CZ": "南方航空", "CA": "中国国航", "HU": "海南航空",
    "9C": "春秋航空", "KN": "中国联航", "JR": "四川航空", "MF": "厦门航空",
    "SC": "山东航空", "ZH": "深圳航空", "FM": "上海航空", "EU": "成都航空",
    "BK": "奥凯航空", "PN": "西部航空", "G5": "华夏航空", "JD": "首都航空",
    "3U": "西藏航空", "GS": "天津航空", "NS": "河北航空", "GJ": "长龙航空",
    "DL": "达美航空", "AA": "美国航空", "UA": "美联航", "BA": "英国航空",
    "LH": "汉莎航空", "AF": "法航", "EK": "阿联酋航空", "SQ": "新加坡航空",
    "TG": "泰航", "JL": "日航", "NH": "全日空", "KE": "大韩航空", "OZ": "韩亚航空",
    "CX": "国泰航空", "CI": "中华航空", "BR": "长荣航空", "MH": "马航",
    "AK": "亚航", "FD": "狮航", "XJ": "泰鸟航",
}

def get_airline_name(code: str) -> str:
    return AIRLINE_MAP.get(code.upper(), code)

# ============================================================
# PinchTab 工具函数
# ============================================================
try:
    import urllib.request
    from urllib.request import Request, urlopen
    URLLIB_AVAILABLE = True
except ImportError:
    URLLIB_AVAILABLE = False

def pinchtab_request(method: str, path: str, data: dict = None, params: str = "") -> dict:
    if not URLLIB_AVAILABLE:
        return {"error": "urllib not available"}
    url = f"{PINCHTAB_SERVER}{path}{params}"
    req_data = json.dumps(data).encode() if data else None
    req = Request(url, data=req_data,
                  headers={"Authorization": f"Bearer {PINCHTAB_TOKEN}",
                           "Content-Type": "application/json"},
                  method=method)
    try:
        with urlopen(req, timeout=20) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}

def pinchtab_nav(url: str, tab_id: str = None) -> dict:
    data = {"url": url}
    params = f"?tab={tab_id}" if tab_id else ""
    return pinchtab_request("POST", "/navigate", data, params)

def pinchtab_snap_raw(tab_id: str) -> str:
    params = f"?tab={tab_id}&format=text&maxTokens=8000"
    req = Request(f"{PINCHTAB_SERVER}/snapshot{params}",
                  headers={"Authorization": f"Bearer {PINCHTAB_TOKEN}"},
                  method="GET")
    try:
        with urlopen(req, timeout=20) as resp:
            return resp.read().decode("utf-8")
    except Exception as e:
        return f"Error: {e}"

def pinchtab_get_tabs() -> list:
    req = Request(f"{PINCHTAB_SERVER}/tabs",
                  headers={"Authorization": f"Bearer {PINCHTAB_TOKEN}"},
                  method="GET")
    try:
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
            return data.get("tabs", [])
    except Exception:
        return []

def pinchtab_ensure_tab() -> Optional[str]:
    tabs = pinchtab_get_tabs()
    for tab in tabs:
        if tab.get("url") and tab["url"] != "about:blank":
            return tab["id"]
    return tabs[0]["id"] if tabs else None

def pinchtab_interact_with_page(tab_id: str) -> Dict:
    result = {"status": "ok", "data": []}
    snap = pinchtab_snap_raw(tab_id)
    if "Error" in snap:
        return {"status": "error", "error": snap}
    lines = snap.split('\n')
    current_route = ""
    for line in lines:
        line = line.strip()
        m = re.match(r'^(.{2,6})飞(.+)$', line)
        if m:
            current_route = f"{m.group(1)}->{m.group(2)}"
            continue
        pm = re.search(r'¥\s*(\d+)', line)
        if pm and current_route:
            price_val = int(pm.group(1))
            if price_val > 0:
                result["data"].append({"route": current_route, "price": price_val, "raw": line})
                current_route = ""
    return result

# ============================================================
# Scrapling / HTTP 工具函数
# ============================================================
def fetch_with_scrapling(url: str, extra_headers: dict = None,
                          timeout: int = 15, max_retries: int = 1) -> Optional[str]:
    """使用 scrapling StealthyFetcher 获取页面 HTML（带超时和重试）"""
    import sys

    def _do_fetch():
        from scrapling.fetchers import StealthyFetcher
        if extra_headers:
            page = StealthyFetcher.fetch(url, headless=True, extra_headers=extra_headers,
                                         timeout=timeout, max_retries=max_retries)
        else:
            page = StealthyFetcher.fetch(url, headless=True,
                                         timeout=timeout, max_retries=max_retries)
        return page.html

    try:
        # Unix: 使用 SIGALRM 超时
        if sys.platform != 'win32':
            import signal

            def _timeout_handler(signum, frame):
                raise TimeoutError("fetch timed out")

            old_handler = signal.signal(signal.SIGALRM, _timeout_handler)
            signal.alarm(timeout + 2)
            try:
                return _do_fetch()
            finally:
                signal.alarm(0)
                signal.signal(signal.SIGALRM, old_handler)
        else:
            # Windows: 直接调用
            return _do_fetch()
    except TimeoutError:
        print(f"    scrapling timeout ({timeout}s)")
        return None
    except Exception as e:
        print(f"    scrapling error: {e}")
        return None

def fetch_with_requests(url: str, headers: dict = None, timeout: int = 15) -> Optional[str]:
    """使用 requests 降级获取页面 HTML"""
    try:
        import requests
        merged_headers = {
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
            "Accept-Language": "en,en-US;q=0.9,zh-CN;q=0.8,zh;q=0.7",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }
        if headers:
            merged_headers.update(headers)
        resp = requests.get(url, headers=merged_headers, timeout=timeout)
        return resp.text
    except Exception as e:
        print(f"    requests error: {e}")
        return None

def extract_from_ctrip_page(html: str) -> List[Dict]:
    try:
        from scrapling.parser import Selector
        page = Selector(html)
    except Exception:
        return []
    results = []
    links = page.css("a[href*='/flight/']")
    for link in links:
        href = link.attrib.get("href", "")
        text = re.sub(r'\s+', '', (link.text or ""))
        m = re.match(r'^(.{2,6})飞(.+)$', text)
        if not m:
            continue
        dep_city, arr_city = m.group(1), m.group(2)
        price_val = 0
        parent = link.parent
        if parent:
            p_text = re.sub(r'\s+', '', (parent.text or ""))
            pm = re.search(r'¥\s*(\d+)', p_text)
            if pm:
                price_val = int(pm.group(1))
        route_m = re.search(r'/flight/([a-z]{3})-([a-z]{3})-', href)
        dep_code = route_m.group(1).upper() if route_m else ""
        arr_code = route_m.group(2).upper() if route_m else ""
        day_m = re.search(r'day-(\d+)', href)
        day_offset = int(day_m.group(1)) if day_m else 1
        dep_date = (date.today() + timedelta(days=day_offset)).strftime("%Y-%m-%d")
        full_href = href if href.startswith("http") else f"https://m.ctrip.com{href}"
        results.append({
            "dep_city": dep_city, "arr_city": arr_city,
            "dep_code": dep_code, "arr_code": arr_code,
            "price": price_val, "date": dep_date, "href": full_href,
        })
    return results

# ============================================================
# 统一航班数据格式
# 字段：flight_no, airline, dep_time, arr_time, price,
#       dep_date, ret_date, is_direct, city, country, is_intl, platform
# ============================================================
def std_flight(
    flight_no: str = "?",
    airline: str = "?",
    dep_time: str = "?",
    arr_time: str = "?",
    price: int = 0,
    dep_date: str = "",
    ret_date: str = "",
    is_direct: bool = False,
    city: str = "?",
    country: str = "?",
    is_intl: bool = False,
    platform: str = "ctrip",
) -> Dict:
    return {
        "flight_no": flight_no,
        "airline": airline,
        "dep_time": dep_time,
        "arr_time": arr_time,
        "price": price,
        "dep_date": dep_date,
        "ret_date": ret_date,
        "is_direct": is_direct,
        "city": city,
        "country": country,
        "is_intl": is_intl,
        "platform": platform,
        "go_flight": flight_no,
        "back_flight": "?",
        "go_dep": dep_time,
        "go_arr": arr_time,
        "back_dep": "?",
        "back_arr": "?",
        "back_duration": 0,
        "go_duration": 0,
    }

# ============================================================
# Ctrip API 搜索
# ============================================================
def ctrip_api_search(config: dict, dep_begin: str = "2026-4-30", dep_end: str = "2026-5-1") -> dict:
    url = (f"https://m.ctrip.com/restapi/soa2/19728/fuzzySearch"
           f"?_fxpcqlniredt={FXPCQLNIREDT}&x-traceID={TRACE_ID}")
    payload = {
        "tt": 2, "source": "online_map", "st": 18,
        "segments": [{
            "dcs": [{"ct": 1, "code": "SHA", "name": "上海"}],
            "acs": [{"name": config["name"], "code": config["code"], "ct": config["ct"]}],
            "dow": [], "sr": {"min": 5, "max": 6},
            "drl": [{"begin": dep_begin, "end": dep_end}], "ddate": None
        }],
        "filters": None,
        "head": {"cid": CID, "ctok": "", "cver": "1.0", "lang": "01",
                 "sid": "8888", "syscode": "999", "auth": "", "xsid": "", "extension": []}
    }
    req = Request(url, data=json.dumps(payload).encode("utf-8"),
                  headers=HEADERS_BASE, method="POST")
    try:
        with urlopen(req, timeout=20) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}

def parse_api_routes(data: dict, config: dict) -> List[Dict]:
    results = []
    routes = data.get("routes", [])
    budget = config["budget"]
    for r in routes:
        arrive_city = r.get("arriveCity", {})
        city = arrive_city.get("name", "?")
        code = arrive_city.get("code", "?")
        is_r_intl = arrive_city.get("isIntl", False)
        if config["is_intl"] and not is_r_intl:
            continue
        if not config["is_intl"] and is_r_intl:
            continue
        flights = r.get("flights", [])
        pl = r.get("pl", [])
        # 去程和回程航班分开收集
        go_flights = [f for f in flights if f.get("segment") == 1]
        back_flights = [f for f in flights if f.get("segment") == 2]
        if not go_flights or not back_flights:
            continue
        # 遍历 pl（多个日期/价格组合），取符合预算的最低价
        for p in pl:
            total_price = p.get("price", 0) or 0
            if not total_price or total_price > budget:
                continue
            dep_date = p.get("departDate", "")
            ret_date = p.get("returnDate", "")
            # 用日期匹配对应航班（取当日第一个）
            go_flight = next((f for f in go_flights if f.get("dtime", "").startswith(dep_date)), go_flights[0])
            back_flight = next((f for f in back_flights if f.get("dtime", "").startswith(ret_date)), back_flights[0])
            def extract_time(dt_str):
                if " " in dt_str:
                    return dt_str.split(" ")[1][:5]
                return "?"
            results.append({
                    "city": city, "country": config["name"], "code": code,
                    "go_date": p.get("departDate", ""), "back_date": p.get("returnDate", ""),
                    "go_flight": go_flight.get("flightNo", "?"),
                    "back_flight": back_flight.get("flightNo", "?"),
                    "go_dep": extract_time(go_flight.get("dtime", "")),
                    "go_arr": extract_time(go_flight.get("atime", "")),
                    "back_dep": extract_time(back_flight.get("dtime", "")),
                    "back_arr": extract_time(back_flight.get("atime", "")),
                    "price": int(total_price),
                    "airline": go_flight.get("airline", {}).get("shortName", "?"),
                    "go_duration": go_flight.get("duration", 0),
                    "back_duration": back_flight.get("duration", 0),
                    "is_intl": is_r_intl, "platform": "ctrip",
                })
    results.sort(key=lambda x: x["price"])
    return results

# ============================================================
# 飞猪 Fliggy 搜索
# ============================================================
FLIGGY_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.fliggy.com/",
    "Accept-Encoding": "gzip, deflate, br",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
}

FLIGGY_CITY_CODES = {
    "大阪": "OSA", "东京": "TYO", "名古屋": "NGO", "福冈": "FUK", "京都": "KYO",
    "首尔": "SEL", "济州": "CJU",
    "曼谷": "BKK", "普吉": "HKT", "清迈": "CNX",
    "吉隆坡": "KUL", "槟城": "PEN",
    "新加坡": "SIN",
}

def search_fliggy_city(config: dict, dest_name: str, dest_code: str, dep_date: str,
                       is_domestic: bool = False) -> List[Dict]:
    """搜索飞猪单城市特价往返"""
    results = []
    budget = config["budget"]

    # 飞猪搜索 URL（PC 版）
    url = (
        f"https://www.fliggy.com/flight/search/search.html"
        f"?depCity=SHA&arrCity={dest_code}"
        f"&depDate={dep_date.replace('-', '')}&tripType=return"
        f"&cabin=Y&adult=1&child=0"
    )

    print(f"    [飞猪] {dest_name}... ", end="", flush=True)

    # 5秒超时，1次重试（快速失败）
    html = fetch_with_scrapling(url, FLIGGY_HEADERS, timeout=5000, max_retries=1)
    if not html:
        # 如果是国内城市，超时则直接跳过，不要卡住
        # 飞猪国内航班数据不稳定，优先依赖携程
        if is_domestic:
            print("跳过（国内城市超时）")
            return []
        html = fetch_with_requests(url, FLIGGY_HEADERS, timeout=5)
    if not html:
        print("网络失败")
        return results

    try:
        from scrapling.parser import Selector
        page = Selector(html)
    except Exception:
        print("解析失败")
        return results

    text_content = re.sub(r'\s+', ' ', page.text or "")

    # 提取价格
    price_patterns = [r'¥\s*(\d{3,5})', r'(\d{3,5})\s*元', r'price["\s:]+(\d{3,5})']
    found_prices = []
    for pattern in price_patterns:
        for m in re.findall(pattern, text_content):
            val = int(m)
            if 200 < val < 10000:
                found_prices.append(val)

    # 提取航班号
    flights_found = re.findall(r'([A-Z]{2})\s*(\d{3,4})', text_content)

    for price in found_prices[:3]:  # 最多取前3个
        if price <= budget and price >= 200:
            ret_date = (datetime.strptime(dep_date, "%Y-%m-%d") + timedelta(days=5)).strftime("%Y-%m-%d")
            flight_no_str = ""
            airline_str = "?"
            if flights_found:
                fn = flights_found[0]
                flight_no_str = f"{fn[0]}{fn[1]}"
                airline_str = get_airline_name(fn[0])
            results.append(std_flight(
                flight_no=flight_no_str or "?",
                airline=airline_str,
                dep_time="?", arr_time="?",
                price=price,
                dep_date=dep_date,
                ret_date=ret_date,
                is_direct=True,
                city=dest_name,
                country=config["name"],
                is_intl=config["is_intl"],
                platform="fliggy",
            ))
            break  # 每个城市只取最低有效价

    print(f"{len(results)}条" if results else "无")
    return results

def check_network(host: str = "fliggy.com", timeout_sec: int = 3) -> bool:
    """快速检测网络是否通（ping）"""
    try:
        result = subprocess.run(
            ["ping", "-c", "1", "-W", str(timeout_sec), host],
            capture_output=True, timeout=timeout_sec + 2
        )
        return result.returncode == 0
    except Exception:
        return False

def search_fliggy(config: dict, dep_dates: list = None) -> List[Dict]:
    """搜索飞猪全配置"""
    if not FLIGGY_ENABLED:
        return []
    results = []
    if dep_dates is None:
        dep_dates = ["2026-04-30", "2026-05-01"]

    # 快速网络检测：ping fliggy.com，不通则直接跳过
    if not check_network("fliggy.com"):
        print(f"  [飞猪] 网络不通（fliggy.com ping 失败），跳过")
        return []

    target_cities = FLIGGY_CITY_CODES

    # 如果是国内全中国，搜索热门国内城市
    domestic_cities = ["北京", "广州", "深圳", "成都", "重庆", "杭州", "西安", "昆明", "厦门", "三亚"]
    is_domestic = config["name"] == "全中国"
    if is_domestic:
        target_cities = {c: CITY_CODE_MAP.get(c, {}).get("code", c[:3].upper()) for c in domestic_cities}

    for dep_date in dep_dates:
        for city_cn, city_code in target_cities.items():
            r = search_fliggy_city(config, city_cn, city_code, dep_date, is_domestic=is_domestic)
            results.extend(r)
            time.sleep(0.8)

    return results

# ============================================================
# Skyscanner 搜索
# ============================================================
SKYSCANNER_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
    "Referer": "https://www.skyscanner.com/",
}

# Skyscanner 使用城市名 slug（国际版 skyscanner.com）
SKYSCANNER_CITY_SLUGS = {
    "大阪": "osaka-itm", "东京": "tokyo", "名古屋": "nagoya", "福冈": "fukuoka",
    "首尔": "seoul-cgkr", "济州": "jeju-cju",
    "曼谷": "bangkok-suvarnabhumi", "普吉": "phuket-hkt", "清迈": "chiang-mai-cnx",
    "吉隆坡": "kuala-lumpur-kul", "槟城": "penang-pen",
    "新加坡": "singapore-sin",
}

def search_skyscanner_city(config: dict, dest_name: str, dest_slug: str, dep_date: str) -> List[Dict]:
    """搜索 Skyscanner 单城市（国际版）"""
    results = []
    budget = config["budget"]

    dep_str = dep_date.replace("-", "")
    ret_date = (datetime.strptime(dep_date, "%Y-%m-%d") + timedelta(days=5)).strftime("%Y%m%d")

    url = (
        f"https://www.skyscanner.com/transport/flights/shanghai/{dest_slug}/"
        f"{dep_str}/{ret_date}/?adultsv2=1&cabinclass=economy&children=0"
        f"&inboundaltsenabled=false&outboundaltsenabled=false"
        f"&preferdirects=false&ref=home&rtn=1"
    )

    print(f"    [Skyscanner] {dest_name}... ", end="", flush=True)

    # 15秒超时，1次重试
    html = fetch_with_scrapling(url, SKYSCANNER_HEADERS, timeout=15000, max_retries=1)
    if not html:
        html = fetch_with_requests(url, SKYSCANNER_HEADERS, timeout=15)

    if not html:
        print("网络失败")
        return results

    try:
        from scrapling.parser import Selector
        page = Selector(html)
    except Exception:
        print("解析失败")
        return results

    text_content = re.sub(r'\s+', ' ', page.text or "")

    # 提取价格
    price_patterns = [r'¥\s*(\d{3,5})', r'RMB\s*(\d{3,5})', r'CNY\s*(\d{3,5})']
    found_prices = []
    for pattern in price_patterns:
        for m in re.findall(pattern, text_content):
            val = int(m)
            if 200 < val < 10000:
                found_prices.append(val)

    # 提取航班号
    flights_found = re.findall(r'([A-Z]{2})\s*(\d{3,4})', text_content)

    for price in found_prices[:3]:
        if price <= budget and price >= 200:
            ret_date_str = (datetime.strptime(dep_date, "%Y-%m-%d") + timedelta(days=5)).strftime("%Y-%m-%d")
            flight_no_str = ""
            airline_str = "?"
            if flights_found:
                fn = flights_found[0]
                flight_no_str = f"{fn[0]}{fn[1]}"
                airline_str = get_airline_name(fn[0])
            results.append(std_flight(
                flight_no=flight_no_str or "?",
                airline=airline_str,
                dep_time="?", arr_time="?",
                price=price,
                dep_date=dep_date,
                ret_date=ret_date_str,
                is_direct=False,
                city=dest_name,
                country=config["name"],
                is_intl=config["is_intl"],
                platform="skyscanner",
            ))
            break

    print(f"{len(results)}条" if results else "无")
    return results

def search_skyscanner(config: dict, dep_dates: list = None) -> List[Dict]:
    """搜索 Skyscanner 全配置"""
    if not SKYSCANNER_ENABLED:
        return []
    results = []
    if dep_dates is None:
        dep_dates = ["2026-04-30", "2026-05-01"]

    target_cities = SKYSCANNER_CITY_SLUGS

    for dep_date in dep_dates:
        for city_cn, city_slug in target_cities.items():
            r = search_skyscanner_city(config, city_cn, city_slug, dep_date)
            results.extend(r)
            time.sleep(1)

    return results

# ============================================================
# Google Flights 搜索
# ============================================================
GOOGLE_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.google.com/",
}


def search_google_city(config: dict, dest_name: str, dest_city_en: str, dep_date: str) -> List[Dict]:
    """搜索 Google Flights 单城市（VPN 下可访问）"""
    results = []
    budget = config["budget"]

    dep_code = "SHA"
    dest_code = CITY_CODE_MAP.get(dest_name, {}).get("code", "TYO")

    dep_str = dep_date.replace("-", "")
    ret_date = (datetime.strptime(dep_date, "%Y-%m-%d") + timedelta(days=5)).strftime("%Y%m%d")

    # Google Flights 搜索 URL - 使用更自然的格式
    # https://www.google.com/travel/flights?q=Shanghai+to+Tokyo+2026-04-30
    q = f"flights Shanghai to {dest_city_en} {dep_date} return {ret_date}"
    import urllib.parse
    encoded_q = urllib.parse.quote_plus(q)
    url = f"https://www.google.com/travel/flights?q={encoded_q}&hl=en&gl=us&curr=CNY"

    print(f"    [Google] {dest_name}... ", end="", flush=True)

    # 15秒超时，1次重试
    html = fetch_with_scrapling(url, GOOGLE_HEADERS, timeout=15000, max_retries=1)
    if not html:
        html = fetch_with_requests(url, GOOGLE_HEADERS, timeout=15)

    try:
        from scrapling.parser import Selector
        page = Selector(html)
    except Exception:
        print("解析失败")
        return results

    text_content = re.sub(r'\s+', ' ', page.text or "")

    # 提取价格
    price_patterns = [r'¥\s*(\d{3,5})', r'CNY\s*(\d{3,5})', r'\$(\d{3,5})']
    found_prices = []
    for pattern in price_patterns:
        for m in re.findall(pattern, text_content):
            val = int(m)
            if 200 < val < 10000:
                found_prices.append(val)

    # 也尝试匹配 "X,XXX" 格式（美元价格）
    usd_prices = re.findall(r'\$(\d{1,3}(?:,\d{3})*)', text_content)
    for m in usd_prices:
        val = int(m.replace(",", "")) * 7  # 粗略换算人民币
        if 200 < val < 10000:
            found_prices.append(val)

    # 提取航班号
    flights_found = re.findall(r'([A-Z]{2})\s*(\d{3,4})', text_content)

    for price in found_prices[:3]:
        if price <= budget and price >= 200:
            ret_date_str = (datetime.strptime(dep_date, "%Y-%m-%d") + timedelta(days=5)).strftime("%Y-%m-%d")
            flight_no_str = ""
            airline_str = "?"
            if flights_found:
                fn = flights_found[0]
                flight_no_str = f"{fn[0]}{fn[1]}"
                airline_str = get_airline_name(fn[0])
            results.append(std_flight(
                flight_no=flight_no_str or "?",
                airline=airline_str,
                dep_time="?", arr_time="?",
                price=price,
                dep_date=dep_date,
                ret_date=ret_date_str,
                is_direct=False,
                city=dest_name,
                country=config["name"],
                is_intl=config["is_intl"],
                platform="google",
            ))
            break

    print(f"{len(results)}条" if results else "无")
    return results

def search_google(config: dict, dep_dates: list = None) -> List[Dict]:
    """搜索 Google Flights 全配置"""
    if not GOOGLE_ENABLED:
        return []
    results = []
    if dep_dates is None:
        dep_dates = ["2026-04-30", "2026-05-01"]

    # Google 支持的城市英文名（VPN 下可访问）
    google_city_names = {
        "日本": [("大阪", "Osaka"), ("东京", "Tokyo"), ("名古屋", "Nagoya"), ("福冈", "Fukuoka")],
        "韩国": [("首尔", "Seoul"), ("济州", "Jeju Island")],
        "泰国": [("曼谷", "Bangkok"), ("普吉", "Phuket"), ("清迈", "Chiang Mai")],
        "新加坡": [("新加坡", "Singapore")],
        "马来西亚": [("吉隆坡", "Kuala Lumpur"), ("槟城", "Penang")],
    }

    target = google_city_names.get(config["name"], [])

    for dep_date in dep_dates:
        for city_cn, city_en in target:
            r = search_google_city(config, city_cn, city_en, dep_date)
            results.extend(r)
            time.sleep(1.2)

    return results

# ============================================================
# PinchTab 自动化搜索（辅助方案）
# ============================================================
def search_via_pinchtab() -> List[Dict]:
    """使用 pinchtab 浏览器提取当前页面中的特价机票数据"""
    results = []
    tab_id = pinchtab_ensure_tab()
    if not tab_id:
        print("  [PinchTab] 没有可用的浏览器标签页")
        return results
    print(f"  [PinchTab] 从标签页 {tab_id[:8]}... 提取数据")
    snap = pinchtab_snap_raw(tab_id)
    lines = snap.split('\n')
    current_route = ""
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        m = re.match(r'^e\d+:\s*(?:link|text|StaticText)\s+"(.+)"$', line)
        if m:
            text = m.group(1)
            route_m = re.match(r'^(.{2,6})飞(.+)$', text)
            if route_m:
                current_route = f"{route_m.group(1)}->{route_m.group(2)}"
                for j in range(i+1, min(i+10, len(lines))):
                    next_line = lines[j].strip()
                    pm = re.search(r'¥\s*(\d+)', next_line)
                    if pm:
                        price_val = int(pm.group(1))
                        if price_val > 0:
                            results.append({
                                "city": route_m.group(2),
                                "route_raw": current_route,
                                "price": price_val,
                                "date": "",
                            })
                        break
        i += 1
    print(f"  [PinchTab] 从页面提取到 {len(results)} 条价格数据")
    return results

def search_via_scrapling_fallback(config: dict) -> List[Dict]:
    """Scrapling 备用方案：直接抓取 Ctrip 页面提取特价数据"""
    results = []
    print(f"\n  [Scrapling] 备用抓取 {config['tag']}...", end=" ", flush=True)
    try:
        from scrapling.fetchers import StealthyFetcher
        page = StealthyFetcher.fetch("https://m.ctrip.com/webapp/flight/", headless=True,
                                       timeout=15000, max_retries=1)
        fares = extract_from_ctrip_page(page.html_content)
        for fare in fares:
            if fare["price"] <= 0 or fare["price"] > config["budget"]:
                continue
            intl_codes = {"TYO", "OSA", "NRT", "KIX", "NGO", "SEL", "ICN",
                          "BKK", "HKT", "CNX", "KUL", "PEN", "SIN"}
            is_intl = fare["arr_code"] in intl_codes
            if config["is_intl"] != is_intl and config["name"] != "全中国":
                continue
            results.append({
                "city": fare["arr_city"], "country": config["name"],
                "code": fare["arr_code"], "go_date": fare["date"],
                "back_date": "", "go_flight": "?", "back_flight": "?",
                "go_dep": "?", "go_arr": "?", "back_dep": "?", "back_arr": "?",
                "price": fare["price"], "airline": "?",
                "go_duration": 0, "back_duration": 0,
                "is_intl": is_intl, "platform": "ctrip",
            })
        print(f"找到 {len(results)} 条")
    except Exception as e:
        print(f"scrapling 失败: {e}")
    return results

# ============================================================
# 主搜索函数
# ============================================================
def search_all(config: dict, errors: list = None) -> List[Dict]:
    """搜索单个配置的目的地（多平台聚合）"""
    results = []
    if errors is None:
        errors = []

    # === 携程 API ===
    print(f"  [API] 搜索 {config['tag']}...", end=" ", flush=True)
    data = ctrip_api_search(config, "2026-4-30", "2026-5-1")
    if "error" in data:
        print(f"失败: {data['error']}", end=" ")
        results.extend(search_via_scrapling_fallback(config))
    else:
        parsed = parse_api_routes(data, config)
        if parsed:
            results.extend(parsed)
            print(f"找到 {len(parsed)} 条（4.30-5.1）")
        else:
            data2 = ctrip_api_search(config, "2026-5-1", "2026-5-1")
            if "error" not in data2:
                parsed2 = parse_api_routes(data2, config)
                if parsed2:
                    results.extend(parsed2)
                    print(f"找到 {len(parsed2)} 条（5.1）")
                else:
                    print("无特价结果", end=" ")
                    sc_results = search_via_scrapling_fallback(config)
                    if sc_results:
                        results.extend(sc_results)
                        print(f" + scrapling {len(sc_results)} 条")
                    else:
                        print()
            else:
                print(f"5.1查询失败: {data2.get('error')}")

    # === 飞猪 ===
    if FLIGGY_ENABLED:
        print(f"  [飞猪] 搜索 {config['tag']}...")
        try:
            fliggy_results = search_fliggy(config)
            results.extend(fliggy_results)
        except Exception as e:
            err = f"飞猪: {e}"
            errors.append(err)
            print(f"  ⚠️ 飞猪异常: {e}")

    # === Skyscanner ===
    if SKYSCANNER_ENABLED and config["is_intl"]:
        print(f"  [Skyscanner] 搜索 {config['tag']}...")
        try:
            skyscanner_results = search_skyscanner(config)
            results.extend(skyscanner_results)
        except Exception as e:
            err = f"Skyscanner: {e}"
            errors.append(err)
            print(f"  ⚠️ Skyscanner异常: {e}")

    # === Google Flights ===
    if GOOGLE_ENABLED and config["is_intl"]:
        print(f"  [Google] 搜索 {config['tag']}...")
        try:
            google_results = search_google(config)
            results.extend(google_results)
        except Exception as e:
            err = f"Google: {e}"
            errors.append(err)
            print(f"  ⚠️ Google异常: {e}")

    return results

# ============================================================
# 飞书消息推送
# ============================================================
def send_feishu(message: dict) -> dict:
    """发送飞书消息"""
    data = json.dumps(message).encode("utf-8")
    req = Request(WEBHOOK_URL, data=data,
                  headers={"Content-Type": "application/json"},
                  method="POST")
    try:
        with urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}

PLATFORM_TAG = {
    "ctrip": "🇨🇳携程",
    "fliggy": "🐷飞猪",
    "skyscanner": "🌐Skyscanner",
    "google": "🔍Google",
}

PLATFORM_TAG_LINE = " | ".join([
    "🇨🇳携程", "🐷飞猪", "🌐Skyscanner", "🔍Google"
])

def build_feishu_card(
    ctrip_domestic: list,
    ctrip_intl: list,
    fliggy_results: list,
    skyscanner_results: list,
    google_results: list,
    errors: list,
) -> dict:
    """构建飞书卡片消息（多平台分开展示）"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # 按平台分组
    def group_by_platform(results):
        g = {}
        for r in results:
            p = r.get("platform", "ctrip")
            if p not in g:
                g[p] = []
            g[p].append(r)
        return g

    ctrip_d = ctrip_domestic
    ctrip_i = ctrip_intl
    fliggy_g = group_by_platform(fliggy_results)
    skyscanner_g = group_by_platform(skyscanner_results)
    google_g = group_by_platform(google_results)

    total = (len(ctrip_d) + len(ctrip_i) + len(fliggy_results) +
             len(skyscanner_results) + len(google_results))

    header_content = f"🐱 特价机票监控 | {now}"
    template = "purple" if total > 0 else "grey"

    blocks = []

    blocks.append({
        "tag": "markdown",
        "content": (
            f"## 🐱 **特价机票多平台监控**\n"
            f"📋 **查询条件**：上海出发 | 4.30或5.1出发 | 5-6天往返\n"
            f"📅 **监控时间**：{now}\n"
            f"🔗 **数据源**：{PLATFORM_TAG_LINE}"
        )
    })

    if errors:
        blocks.append({
            "tag": "markdown",
            "content": f"⚠️ **查询失败**：{', '.join(set(errors))}"
        })

    if total == 0 and not errors:
        blocks.append({
            "tag": "markdown",
            "content": "😔 **暂未找到符合条件的特价机票**"
        })
        remark = "价格变动频繁，请以实际支付时为准 🔄"
    else:
        blocks.append({
            "tag": "markdown",
            "content": f"🎉 **共找到 {total} 条特价往返线路！**"
        })

        # ---- 携程 ----
        if ctrip_d or ctrip_i:
            blocks.append({"tag": "hr"})
            blocks.append({"tag": "markdown", "content": f"### {PLATFORM_TAG['ctrip']} **携程**"})

            popular = [r for r in ctrip_d if r.get("city", "") in POPULAR_DOMESTIC]
            others = [r for r in ctrip_d if r.get("city", "") not in POPULAR_DOMESTIC]

            if popular:
                blocks.append({"tag": "markdown", "content": "**国内航班（预算 ≤ ¥1500）**"})
                for r in popular[:8]:
                    dur = format_dur(r.get("back_duration", 0))
                    blocks.append({
                        "tag": "markdown",
                        "content": (
                            f"• **{r.get('city', '?')}**  ¥{r.get('price', '?')}  "
                            f"| {r.get('go_date', '?')}({r.get('go_flight', '?')}) "
                            f"{r.get('go_dep', '?')}→{r.get('go_arr', '?')} | "
                            f"{r.get('back_date', '?')}({r.get('back_flight', '?')}) "
                            f"{r.get('back_dep', '?')}→{r.get('back_arr', '?')}[{dur}] "
                            f"| {r.get('airline', '?')}"
                        )
                    })
                for r in others[:3]:
                    blocks.append({
                        "tag": "markdown",
                        "content": (
                            f"• {r.get('city', '?')}  ¥{r.get('price', '?')}  "
                            f"| {r.get('go_date', '?')}→{r.get('back_date', '?')} "
                            f"| {r.get('airline', '?')}"
                        )
                    })

            if ctrip_i:
                blocks.append({"tag": "markdown", "content": "**国际航班（预算 ≤ ¥2500）**"})
                by_country = {}
                for r in ctrip_i:
                    key = r.get("country", "")
                    by_country.setdefault(key, []).append(r)
                country_emoji = {
                    "马来西亚": "🇲🇾", "日本": "🇯🇵", "韩国": "🇰🇷",
                    "泰国": "🇹🇭", "新加坡": "🇸🇬"
                }
                for country, emoji in country_emoji.items():
                    if country in by_country:
                        for r in by_country[country][:2]:
                            dur = format_dur(r.get("back_duration", 0))
                            blocks.append({
                                "tag": "markdown",
                                "content": (
                                    f"{emoji} **{r.get('city', '?')}**  ¥{r.get('price', '?')}  "
                                    f"| {r.get('go_date', '?')}({r.get('go_flight', '?')}) "
                                    f"{r.get('go_dep', '?')}→{r.get('go_arr', '?')} | "
                                    f"{r.get('back_date', '?')}({r.get('back_flight', '?')}) "
                                    f"{r.get('back_dep', '?')}→{r.get('back_arr', '?')}[{dur}] "
                                    f"| {r.get('airline', '?')}"
                                )
                            })
            else:
                blocks.append({"tag": "markdown", "content": "暂无符合条件的国际航班（预算内）🔍"})

        # ---- 飞猪 ----
        if fliggy_g:
            blocks.append({"tag": "hr"})
            blocks.append({"tag": "markdown", "content": f"### {PLATFORM_TAG['fliggy']} **飞猪**"})
            fliggy_intl = fliggy_g.get("fliggy", [])
            fliggy_by_country = {}
            for r in fliggy_intl:
                fliggy_by_country.setdefault(r.get("country", ""), []).append(r)
            country_emoji = {
                "马来西亚": "🇲🇾", "日本": "🇯🇵", "韩国": "🇰🇷",
                "泰国": "🇹🇭", "新加坡": "🇸🇬", "全中国": "🇨🇳"
            }
            for country, emoji in country_emoji.items():
                if country in fliggy_by_country:
                    for r in fliggy_by_country[country][:3]:
                        blocks.append({
                            "tag": "markdown",
                            "content": (
                                f"{emoji} **{r.get('city', '?')}**  ¥{r.get('price', '?')}  "
                                f"| {r.get('dep_date', '?')}→{r.get('ret_date', '?')} "
                                f"| {r.get('airline', '?')}"
                            )
                        })

        # ---- Skyscanner ----
        if skyscanner_g:
            blocks.append({"tag": "hr"})
            blocks.append({"tag": "markdown", "content": f"### {PLATFORM_TAG['skyscanner']} **Skyscanner**"})
            skyscanner_intl = skyscanner_g.get("skyscanner", [])
            sk_by_country = {}
            for r in skyscanner_intl:
                sk_by_country.setdefault(r.get("country", ""), []).append(r)
            for country, emoji in country_emoji.items():
                if country in sk_by_country:
                    for r in sk_by_country[country][:3]:
                        blocks.append({
                            "tag": "markdown",
                            "content": (
                                f"{emoji} **{r.get('city', '?')}**  ¥{r.get('price', '?')}  "
                                f"| {r.get('dep_date', '?')}→{r.get('ret_date', '?')} "
                                f"| {r.get('airline', '?')}"
                            )
                        })

        # ---- Google ----
        if google_g:
            blocks.append({"tag": "hr"})
            blocks.append({"tag": "markdown", "content": f"### {PLATFORM_TAG['google']} **Google Flights**"})
            google_intl = google_g.get("google", [])
            g_by_country = {}
            for r in google_intl:
                g_by_country.setdefault(r.get("country", ""), []).append(r)
            for country, emoji in country_emoji.items():
                if country in g_by_country:
                    for r in g_by_country[country][:3]:
                        blocks.append({
                            "tag": "markdown",
                            "content": (
                                f"{emoji} **{r.get('city', '?')}**  ¥{r.get('price', '?')}  "
                                f"| {r.get('dep_date', '?')}→{r.get('ret_date', '?')} "
                                f"| {r.get('airline', '?')}"
                            )
                        })

        remark = "价格变动频繁，请以实际支付时为准 🔄"

    blocks.append({"tag": "hr"})
    blocks.append({"tag": "markdown", "content": f"> 💡 {remark}"})

    return {
        "msg_type": "interactive",
        "card": {
            "header": {
                "title": {"tag": "plain_text", "content": header_content},
                "template": template
            },
            "elements": blocks
        }
    }

# ============================================================
# 主流程
# ============================================================
def main():
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n[{'='*50}]")
    print(f"[{ts}] 🔍 携程特价机票监控开始")
    print(f"   出发地：上海 | 出发日期：4.30或5.1 | 行程：5-6天往返")
    print(f"   数据源：🇨🇳携程 {'(已启用)' if True else '(已禁用)'} | "
          f"🐷飞猪 {'(已启用)' if FLIGGY_ENABLED else '(已禁用)'} | "
          f"🌐Skyscanner {'(已启用)' if SKYSCANNER_ENABLED else '(已禁用)'} | "
          f"🔍Google {'(已启用)' if GOOGLE_ENABLED else '(已禁用)'}")
    print(f"[{'='*50}]")

    # 各平台独立去重缓存
    seen_ctrip = load_seen_cache("ctrip")
    seen_fliggy = load_seen_cache("fliggy")
    seen_skyscanner = load_seen_cache("skyscanner")
    seen_google = load_seen_cache("google")

    print(f"   📦 已加载去重缓存：携程 {len(seen_ctrip)} | "
          f"飞猪 {len(seen_fliggy)} | Skyscanner {len(seen_skyscanner)} | Google {len(seen_google)}")

    all_results = []
    errors = []
    new_by_platform = {"ctrip": 0, "fliggy": 0, "skyscanner": 0, "google": 0}

    for config in SEARCH_CONFIGS:
        results = search_all(config, errors)

        # 去重 + 收集
        for r in results:
            platform = r.get("platform", "ctrip")
            key = make_seen_key(r.get("go_flight", "?"), r.get("price", 0), r.get("go_date", ""))
            cache_map = {
                "ctrip": seen_ctrip, "fliggy": seen_fliggy,
                "skyscanner": seen_skyscanner, "google": seen_google
            }
            seen = cache_map.get(platform, seen_ctrip)
            if key not in seen:
                seen.add(key)
                new_by_platform[platform] = new_by_platform.get(platform, 0) + 1
                all_results.append(r)
            else:
                seen.add(key)

        time.sleep(3)
        print(f"  → {config['name']} 处理完成")

    # 保存各平台去重缓存
    save_seen_cache(seen_ctrip, "ctrip")
    save_seen_cache(seen_fliggy, "fliggy")
    save_seen_cache(seen_skyscanner, "skyscanner")
    save_seen_cache(seen_google, "google")
    print(f"   💾 已更新去重缓存")

    # 分类
    ctrip_d = [r for r in all_results if r.get("platform") == "ctrip" and not r.get("is_intl")]
    ctrip_i = [r for r in all_results if r.get("platform") == "ctrip" and r.get("is_intl")]
    fliggy_r = [r for r in all_results if r.get("platform") == "fliggy"]
    skyscanner_r = [r for r in all_results if r.get("platform") == "skyscanner"]
    google_r = [r for r in all_results if r.get("platform") == "google"]

    total_new = sum(new_by_platform.values())

    # 有新增 OR 有任何结果（国内/国际/异动）OR 有报错，都要推送
    # 不推送的情况：0结果 且 无新增 且 无报错 → 脚本正常运行但什么都没找到，且全在缓存里
    # 推送是为了告知用户：脚本在运行、检查了哪些、数据有无变化
    if total_new > 0 or all_results or errors:
        card = build_feishu_card(
            ctrip_d, ctrip_i, fliggy_r, skyscanner_r, google_r, errors
        )
        send_result = send_feishu(card)
        if "error" in send_result:
            print(f"\n❌ 飞书推送失败: {send_result['error']}")
        else:
            print(f"\n✅ 飞书推送成功！")
            print(f"   🇨🇳携程: {len(ctrip_d)+len(ctrip_i)} 条 | "
                  f"🐷飞猪: {len(fliggy_r)} 条 | "
                  f"🌐Skyscanner: {len(skyscanner_r)} 条 | "
                  f"🔍Google: {len(google_r)} 条")
            print(f"   新增结果: {total_new} 条")
    else:
        print(f"\n🤷 没有新增特价机票（去重过滤），不推送")

    return total_new

def main_once():
    """单次执行（供 cron 调用）"""
    try:
        return main()
    except Exception as e:
        print(f"\n❌ 执行出错: {e}")
        import traceback
        traceback.print_exc()
        return 0

if __name__ == "__main__":
    count = main_once()
    print(f"\n[完成] 共推送 {count} 条新特价机票")
