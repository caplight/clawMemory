#!/usr/bin/env python3
"""
飞书群候选人自动登记脚本 v2
按妈妈猫要求的格式写入表格
"""
import json
import re
import os
from datetime import date, datetime

# ====== 配置 ======
CHAT_ID = "oc_550fe92c1598eccdd9de308157eda095"
SPREADSHEET_TOKEN = "LyK3sD1QVhYmsft7E6vc8YRynwf"
SHEET_ID = "0qYoUz"
LAST_MSG_FILE = "/root/.openclaw/workspace-newbot/scripts/.last_msg_id"
LOG_FILE = "/root/.openclaw/workspace-newbot/scripts/.register_log"

# 群成员工号→姓名映射
GROUP_MEMBERS = {
    "ou_fff9103206dfc5695fbcee4be212769e": "张本超",
    "ou_7e3c9b258c00ced92ad49afd39f04711": "李睿冰",
    "ou_4e9f8a6b14be53802581bcec16375022": "赵航",
    "ou_4803cd7260b528c0a3b34a134c544c52": "蒙雪君",
    "ou_7efb58679bb3bfcb60f7745082b158f5": "李锐",
    "ou_a53f0c139c017aab4fd4717bae5bc76b": "张本育",
    "ou_1262b7d53486b73dd91f51ee7b751da1": "罗晓婉",
    "ou_981ba595436335d2e8d79b8466d950e0": "刘川旗",
}

def date_to_excel_serial(d):
    """将日期转换为Excel序列号"""
    base = date(1899, 12, 30)
    return (d - base).days

def today_serial():
    return date_to_excel_serial(date.today())

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def get_token():
    import urllib.request
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        data=json.dumps({"app_id": "cli_a979e8bc7b789bda", "app_secret": "yKUOlPu08bgeeSO8mVVqLd3BvbaJXuYO"}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())["tenant_access_token"]

def parse_candidate_message(raw_content, sender_id):
    """解析候选人信息文本"""
    try:
        parsed = json.loads(raw_content)
        text = parsed.get("text", "")
    except:
        text = raw_content
    
    # 匹配格式：城市+字节生服BD/字节BD \n姓名：xxx
    pattern = r"(.+?字节生服BD|字节BD)[:：]\s*姓名[：:]([^\n]+)"
    match = re.search(pattern, text)
    if not match:
        return None
    
    city = match.group(1).replace("字节生服BD", "").replace("字节BD", "").strip()
    name = match.group(2).strip()
    
    # 学历映射：本科→本科及以上，大专→大专，其他→其他
    education_map = {"本科": "本科及以上"}
    
    result = {
        "city": city,
        "project": "字节跳动",
        "position": f"生活服务商家BD-{city}",
        "name": name,
        "sender_id": sender_id,
        "sender_name": GROUP_MEMBERS.get(sender_id, sender_id),
        "recommend_date": today_serial(),
        "cooperation_mode": "外包",
        "education": "本科及以上",
        "resume_passed": "",
        "remarks": ""
    }
    
    fields = {
        "年龄": r"年龄[：:]\s*(\S+)",
        "电话": r"电话[：:]\s*(\S+)",
        "邮箱": r"邮箱[：:]\s*(\S+)",
        "学历": r"学历[：:]\s*(\S+)",
    }
    
    for field, pat in fields.items():
        m = re.search(pat, text)
        if m:
            val = m.group(1).strip()
            if field == "学历":
                result["education"] = education_map.get(val, val)
            else:
                result[field] = val
    
    adv_match = re.search(r"个人优势[（][^）]+[）][：:]\s*\n?(.+?)(?:@_user|已推|已传|$)", text, re.DOTALL)
    if adv_match:
        result["remarks"] = adv_match.group(1).strip()[:200]
    
    return result

def get_messages(token, page_size=50):
    import urllib.request
    url = f"https://open.feishu.cn/open-apis/im/v1/messages?container_id_type=chat&container_id={CHAT_ID}&sort_type=ByCreateTimeDesc&page_size={page_size}"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read()).get("data", {}).get("items", [])

def get_last_row(token):
    """获取表格当前数据最后一行"""
    import urllib.request
    # 快速检查：用大致范围查找有数据的最后一行
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_ID}!F2:F3000"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())
    values = data.get("data", {}).get("valueRange", {}).get("values", [])
    last_row = 1
    for i, row in enumerate(values):
        if row and row[0]:
            last_row = i + 2  # +2因为从第2行开始，第0行是表头
    return last_row

def write_row(token, row_num, values):
    """写入一行数据"""
    import urllib.request
    cell_range = f"{SHEET_ID}!A{row_num}:V{row_num}"
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values"
    payload = {
        "valueRange": {
            "range": cell_range,
            "values": [values]
        }
    }
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="PUT"
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())

def overwrite_row(token, row_num, candidate):
    """按正确格式覆写一行"""
    row = [
        candidate["recommend_date"],     # A: 推荐日期 (Excel序列号)
        candidate["sender_name"],        # B: 具体推荐人
        "李睿冰",                        # C: 招聘运营
        candidate["project"],            # D: 项目名称
        candidate["cooperation_mode"],   # E: 合作模式
        candidate["name"],               # F: 姓名
        "",                              # G: 性别（不填）
        candidate["education"],           # H: 学历
        candidate["position"],            # I: 岗位
        candidate["resume_passed"],      # J: 简历是否通过（不填）
        "",                              # K: 辅助列（勿动）
        "",                              # L: 面试日期
        "",                              # M: 是否通过
        "",                              # N: 二面日期
        "",                              # O: 二面结果
        "",                              # P: 三面日期
        "",                              # Q: 三面结果
        "",                              # R: 辅助列2
        "",                              # S: 辅助列3
        candidate.get("remarks", ""),    # T: 备注
        "",                              # U: 是否接受offer
        "",                              # V: 入职时间
    ]
    return write_row(token, row_num, row)

def main():
    log("=== 开始执行候选人登记任务(v2) ===")
    token = get_token()
    
    # 获取最新消息
    messages = get_messages(token)
    log(f"获取到 {len(messages)} 条消息")
    
    # 读取上次处理的消息ID
    last_msg_time = None
    if os.path.exists(LAST_MSG_FILE):
        with open(LAST_MSG_FILE) as f:
            for line in f:
                if line.startswith("last_msg_time="):
                    last_msg_time = line.split("=", 1)[1].strip()
    
    # 找出需要处理的新消息
    new_messages = []
    newest_time = None
    
    for msg in messages:
        msg_time = msg.get("create_time", "")
        if newest_time is None:
            newest_time = msg_time
        if last_msg_time and msg_time <= last_msg_time:
            break
        new_messages.append(msg)
    
    new_messages = list(reversed(new_messages))
    log(f"需要处理的新消息: {len(new_messages)} 条")
    
    # 解析候选人
    candidates = []
    for msg in new_messages:
        if msg.get("msg_type") != "text":
            continue
        raw_content = msg.get("body", {}).get("content", "")
        sender = msg.get("sender", {})
        sender_id = sender.get("id", "")
        
        if not sender_id or not raw_content.strip():
            continue
        
        candidate = parse_candidate_message(raw_content, sender_id)
        if candidate:
            candidates.append((candidate, msg))
            log(f"  ✅ 解析: {candidate['name']} | {candidate['position']} | 推荐人: {candidate['sender_name']}")
    
    if candidates:
        start_row = get_last_row(token) + 1  # 追加到下一行
        log(f"写入表格，从第 {start_row} 行起")
        
        for i, (c, msg) in enumerate(candidates):
            result = overwrite_row(token, start_row + i, c)
            if result.get("code") == 0:
                log(f"  ✅ 已写入第{start_row + i}行: {c['name']} | {c['position']}")
            else:
                log(f"  ❌ 写入失败: {result.get('msg', result)}")
        
        with open(LAST_MSG_FILE, "w") as f:
            f.write(f"last_msg_time={newest_time}\n")
        log(f"✅ 写入完成，共 {len(candidates)} 条")
    else:
        log("📭 没有发现新的候选人信息")

if __name__ == "__main__":
    main()
