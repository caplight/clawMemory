#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
字节BD面试物料 PPT 生成脚本 v2
加入面试Q&A真题整理
"""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

C_DARK = RGBColor(0x1A, 0x1A, 0x2E)
C_PRIMARY = RGBColor(0xFE, 0x4C, 0x3A)
C_ACCENT = RGBColor(0x25, 0xF4, 0xEE)
C_WHITE = RGBColor(0xFF, 0xFF, 0xFF)
C_LIGHT_BG = RGBColor(0xF8, 0xF9, 0xFA)
C_TEXT_DARK = RGBColor(0x26, 0x26, 0x26)
C_TEXT_GRAY = RGBColor(0x66, 0x66, 0x66)
C_CARD_BG = RGBColor(0xFF, 0xFF, 0xFF)

SLIDE_W = Inches(13.33)
SLIDE_H = Inches(7.5)

def new_prs():
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H
    return prs

def add_rect(slide, left, top, width, height, fill_color=None, line_color=None, line_width=Pt(0)):
    shape = slide.shapes.add_shape(1, left, top, width, height)
    if fill_color:
        shape.fill.solid()
        shape.fill.fore_color.rgb = fill_color
    else:
        shape.fill.background()
    if line_color:
        shape.line.color.rgb = line_color
        shape.line.width = line_width
    else:
        shape.line.fill.background()
    return shape

def add_text_box(slide, text, left, top, width, height,
                 font_size=Pt(18), bold=False, color=C_TEXT_DARK,
                 align=PP_ALIGN.LEFT, wrap=True, italic=False):
    txBox = slide.shapes.add_textbox(left, top, width, height)
    tf = txBox.text_frame
    tf.word_wrap = wrap
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    run.font.size = font_size
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = color
    return txBox

def add_slide_bg(slide, color):
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = color

def add_header_bar(slide, title, subtitle="", bg_color=C_PRIMARY):
    add_rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(1.3), bg_color)
    add_text_box(slide, title,
                 Inches(0.5), Inches(0.15), Inches(10), Inches(0.7),
                 font_size=Pt(32), bold=True, color=C_WHITE)
    if subtitle:
        add_text_box(slide, subtitle,
                     Inches(0.5), Inches(0.8), Inches(12), Inches(0.4),
                     font_size=Pt(16), color=C_ACCENT)

def add_footer(slide, page_num, total):
    add_rect(slide, Inches(0), Inches(7.1), SLIDE_W, Inches(0.4), RGBColor(0xE8, 0xE8, 0xE8))
    add_text_box(slide, f"{page_num} / {total}",
                 Inches(12), Inches(7.15), Inches(1), Inches(0.3),
                 font_size=Pt(11), color=C_TEXT_GRAY, align=PP_ALIGN.RIGHT)

def slide_cover(prs):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide, C_DARK)
    add_rect(slide, Inches(0), Inches(0), SLIDE_W, Inches(0.15), C_PRIMARY)
    add_text_box(slide, "字节BD",
                 Inches(1), Inches(2.2), Inches(11), Inches(1.5),
                 font_size=Pt(72), bold=True, color=C_WHITE, align=PP_ALIGN.CENTER)
    add_text_box(slide, "面试物料",
                 Inches(1), Inches(3.6), Inches(11), Inches(1),
                 font_size=Pt(52), bold=False, color=C_PRIMARY,
                 align=PP_ALIGN.CENTER)
    add_rect(slide, Inches(4), Inches(4.8), Inches(5.33), Pt(3), C_PRIMARY)
    add_text_box(slide, "适用岗位：抖音生活服务 · 商家BD",
                 Inches(1), Inches(5.2), Inches(11), Inches(0.6),
                 font_size=Pt(22), color=C_ACCENT, align=PP_ALIGN.CENTER)
    add_text_box(slide, "内部培训资料 | 含面试真题整理",
                 Inches(1), Inches(6.6), Inches(11), Inches(0.4),
                 font_size=Pt(14), color=C_TEXT_GRAY, align=PP_ALIGN.CENTER)

def slide_section(prs, title):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide, C_PRIMARY)
    add_rect(slide, Inches(0), Inches(0), Inches(0.4), SLIDE_H, C_DARK)
    add_text_box(slide, title,
                 Inches(1.2), Inches(2.8), Inches(10), Inches(2),
                 font_size=Pt(54), bold=True, color=C_WHITE, align=PP_ALIGN.LEFT)
    return slide

def slide_white(prs):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_slide_bg(slide, C_LIGHT_BG)
    return slide

def add_qa_card(slide, left, top, width, height, question, answer, tip=""):
    """Q&A卡片"""
    card = add_rect(slide, left, top, width, height,
                    C_CARD_BG, line_color=C_PRIMARY, line_width=Pt(1.5))
    # Q标签
    add_rect(slide, left, top, Inches(0.45), height, C_PRIMARY)
    add_text_box(slide, "Q", left, top + Inches(0.15), Inches(0.45), Inches(0.4),
                 font_size=Pt(14), bold=True, color=C_WHITE, align=PP_ALIGN.CENTER)
    # 问题
    add_text_box(slide, question,
                 left + Inches(0.6), top + Inches(0.1), width - Inches(0.8), Inches(0.55),
                 font_size=Pt(12), bold=True, color=C_TEXT_DARK)
    # 答案/思路
    add_rect(slide, left + Inches(0.15), top + Inches(0.65), width - Inches(0.3), Pt(1), C_PRIMARY)
    add_text_box(slide, answer,
                 left + Inches(0.2), top + Inches(0.75), width - Inches(0.4), Inches(0.9),
                 font_size=Pt(10.5), color=C_TEXT_GRAY)
    if tip:
        add_text_box(slide, f"💡 {tip}",
                     left + Inches(0.2), top + height - Inches(0.35), width - Inches(0.4), Inches(0.3),
                     font_size=Pt(9), italic=True, color=RGBColor(0xE6, 0x7E, 0x22))

def build():
    prs = new_prs()
    total = 10

    # 1. 封面
    slide_cover(prs)

    # 2. 分隔页
    slide_section(prs, "Part 1\n平台认知")

    # 3. 平台介绍（精简）
    slide = slide_white(prs)
    add_header_bar(slide, "平台介绍", "抖音生活服务 = 帮商家「看到 → 种草 → 下单 → 到店」")
    stats = [("81%", "平台GMV增长"), ("320万+", "门店入驻"), ("6亿+", "日活用户")]
    for i, (num, lbl) in enumerate(stats):
        lx = Inches(0.5 + i * 4.2)
        add_rect(slide, lx, Inches(1.7), Inches(3.8), Inches(1.2),
                 RGBColor(0xFF, 0xF0, 0xEC), line_color=C_PRIMARY, line_width=Pt(2))
        add_text_box(slide, num, lx, Inches(1.8), Inches(3.8), Inches(0.7),
                     font_size=Pt(36), bold=True, color=C_PRIMARY, align=PP_ALIGN.CENTER)
        add_text_box(slide, lbl, lx, Inches(2.4), Inches(3.8), Inches(0.4),
                     font_size=Pt(14), color=C_TEXT_GRAY, align=PP_ALIGN.CENTER)
    add_text_box(slide, "BD工作职责",
                 Inches(0.5), Inches(3.1), Inches(12), Inches(0.4),
                 font_size=Pt(18), bold=True, color=C_TEXT_DARK)
    duties = ["商家招募", "团购上架", "达人对接", "活动运营", "数据追踪", "客情维护"]
    for i, d in enumerate(duties):
        col = i % 3
        row = i // 3
        lx = Inches(0.5 + col * 4.2)
        ty = Inches(3.6 + row * 1.4)
        add_rect(slide, lx, ty, Inches(3.8), Inches(1.1), RGBColor(0xFF, 0xF8, 0xF5),
                 line_color=C_PRIMARY, line_width=Pt(1))
        add_text_box(slide, f"{i+1}. {d}", lx + Inches(0.2), ty + Inches(0.3), Inches(3.4), Inches(0.5),
                     font_size=Pt(16), bold=True, color=C_PRIMARY)
    add_footer(slide, 3, total)

    # 4. BD核心价值（精简）
    slide = slide_white(prs)
    add_header_bar(slide, "商家BD核心价值", "帮助本地商家在抖音开店获客，本质是「数字化经营顾问」")
    points = [
        ("连接器", "连接商家与平台资源\n帮商家找到新客流", "🌐"),
        ("运营顾问", "分析数据、优化套餐\n提升商家经营效率", "📊"),
        ("增长引擎", "新客获取、品牌曝光\n帮助商家实现业绩增长", "🚀"),
    ]
    for i, (title, desc, icon) in enumerate(points):
        lx = Inches(0.5 + i * 4.2)
        add_rect(slide, lx, Inches(1.8), Inches(3.8), Inches(4.8),
                 RGBColor(0xFF, 0xF8, 0xF5), line_color=C_PRIMARY, line_width=Pt(2))
        add_text_box(slide, icon, lx, Inches(2.0), Inches(3.8), Inches(0.8),
                     font_size=Pt(40), align=PP_ALIGN.CENTER)
        add_text_box(slide, title, lx, Inches(2.8), Inches(3.8), Inches(0.6),
                     font_size=Pt(22), bold=True, color=C_PRIMARY, align=PP_ALIGN.CENTER)
        add_text_box(slide, desc, lx + Inches(0.3), Inches(3.5), Inches(3.2), Inches(2),
                     font_size=Pt(14), color=C_TEXT_GRAY, align=PP_ALIGN.CENTER)
    add_footer(slide, 4, total)

    # 5. 分隔页
    slide_section(prs, "Part 2\n面试真题")

    # 6. 必问题（自我介绍+压力+加班）
    slide = slide_white(prs)
    add_header_bar(slide, "面试必问题", "所有候选人通用，提前准备好答案")
    qas = [
        ("自我介绍（3-5分钟）",
         "结构：我是谁 → 过往经验（销售/BD相关）→ 为什么想做BD\n不要念简历，要突出与BD岗位相关的经历和能力",
         "用「背景+动作+结果」结构举1-2个具体案例"),
        ("工作压力怎么解决？",
         "考察抗压能力。回答思路：先承认压力存在 → 具体案例 → 解决方法\n例：BD被拒绝是常态，我会复盘调整策略继续推进",
         "避免说「我没什么压力」或「辞职逃避」"),
        ("能接受加班吗？",
         "❗这道题必须积极回答！\n参考：BD是业绩导向岗位，忙起来加班是正常的，我理解也很接受。\n我更关心的是把事情做好，而不是工作时间。",
         "不要表现出抵触，哪怕内心不完全接受，面试时也要说接受"),
    ]
    for i, (q, a, tip) in enumerate(qas):
        ty = Inches(1.7 + i * 1.75)
        add_rect(slide, Inches(0.4), ty, Inches(12.5), Inches(1.55),
                 C_CARD_BG, line_color=RGBColor(0xE8, 0xE8, 0xE8), line_width=Pt(1))
        add_text_box(slide, q, Inches(0.6), ty + Inches(0.1), Inches(5), Inches(0.4),
                     font_size=Pt(13), bold=True, color=C_PRIMARY)
        add_text_box(slide, a, Inches(0.6), ty + Inches(0.5), Inches(12), Inches(0.7),
                     font_size=Pt(11), color=C_TEXT_GRAY)
        add_text_box(slide, f"💡 {tip}", Inches(0.6), ty + Inches(1.2), Inches(12), Inches(0.3),
                     font_size=Pt(10), italic=True, color=RGBColor(0xE6, 0x7E, 0x22))
    add_footer(slide, 6, total)

    # 7. BD专项问题
    slide = slide_white(prs)
    add_header_bar(slide, "BD专项问题", "考察对岗位的认知和热情")
    qas2 = [
        ("你对抖音本地生活了解多少？",
         "❗面试前必做功课！\n回答思路：我知道抖音在推本地生活、商家可以开团购、达人可以帮商家拍视频。\n我提前体验过抖音团购，也了解它和美团的差异。",
         "没做过功课会被直接淘汰"),
        ("BD日常做什么工作？有哪些挑战？",
         "核心：招募商家 + 运营辅导\n挑战：商家不配合、拒绝陌拜、启动慢\n应对：先做标杆案例、用数据说话、建立信任",
         "要有具体的应对思路，不是只说「我会努力」"),
        ("过往哪些经验可以复用到BD岗位？",
         "核心：销售经验、客情维护、数据分析、项目跟进\n例：我以前做销售，积累了大量陌拜和谈判经验，知道怎么跟商家打交道",
         "尽量找与BD能力要求匹配的过往经历"),
    ]
    for i, (q, a, tip) in enumerate(qas2):
        ty = Inches(1.7 + i * 1.75)
        add_rect(slide, Inches(0.4), ty, Inches(12.5), Inches(1.55),
                 C_CARD_BG, line_color=RGBColor(0xE8, 0xE8, 0xE8), line_width=Pt(1))
        add_text_box(slide, q, Inches(0.6), ty + Inches(0.1), Inches(6), Inches(0.4),
                     font_size=Pt(13), bold=True, color=C_PRIMARY)
        add_text_box(slide, a, Inches(0.6), ty + Inches(0.5), Inches(12), Inches(0.7),
                     font_size=Pt(11), color=C_TEXT_GRAY)
        add_text_box(slide, f"💡 {tip}", Inches(0.6), ty + Inches(1.2), Inches(12), Inches(0.3),
                     font_size=Pt(10), italic=True, color=RGBColor(0xE6, 0x7E, 0x22))
    add_footer(slide, 7, total)

    # 8. 行业问题
    slide = slide_white(prs)
    add_header_bar(slide, "行业理解问题", "考察对竞品和业务的理解深度")
    qas3 = [
        ("抖音和美团的区别？各自优势？",
         "美团：强搜索、强目的性消费、存量市场、客群稳定\n抖音：强推荐、强种草、增量市场、内容激发需求\n抖音更适合新店冷启动和品牌曝光，美团适合刚需消费",
         "要有自己的见解，不要只说「都是本地生活」"),
        ("如何让新开的店入驻抖音？",
         "陌拜话术参考：\n「老板，您新店开业最重要的是让更多人知道。抖音现在流量很大，我们有达人可以免费帮您拍视频，不用您自己拍，挂您店里的团购链接，帮您引流到店。」",
         "核心：打消顾虑 + 展示资源 + 降低门槛"),
        ("商家加入后如何帮他做运营策划？",
         "四步：1）了解商家痛点（缺客流？淡季？）；2）设计团购套餐；3）对接达人拍视频种草；4）追踪数据优化",
         "展示你的运营思路，不是只说「帮他们上线」"),
    ]
    for i, (q, a, tip) in enumerate(qas3):
        ty = Inches(1.7 + i * 1.75)
        add_rect(slide, Inches(0.4), ty, Inches(12.5), Inches(1.55),
                 C_CARD_BG, line_color=RGBColor(0xE8, 0xE8, 0xE8), line_width=Pt(1))
        add_text_box(slide, q, Inches(0.6), ty + Inches(0.1), Inches(5.5), Inches(0.4),
                     font_size=Pt(13), bold=True, color=C_PRIMARY)
        add_text_box(slide, a, Inches(0.6), ty + Inches(0.5), Inches(12), Inches(0.7),
                     font_size=Pt(11), color=C_TEXT_GRAY)
        add_text_box(slide, f"💡 {tip}", Inches(0.6), ty + Inches(1.2), Inches(12), Inches(0.3),
                     font_size=Pt(10), italic=True, color=RGBColor(0xE6, 0x7E, 0x22))
    add_footer(slide, 8, total)

    # 9. 业绩&成就问题
    slide = slide_white(prs)
    add_header_bar(slide, "业绩亮点问题", "展示过往成绩和潜力")
    qas4 = [
        ("你工作最有成就感的一件事是什么？",
         "❗用STAR法则回答\nSituation（情境）→ Task（任务）→ Action（行动）→ Result（结果）\n最好是与销售/BD相关的具体数字案例",
         "没有具体数字的成就不够有力"),
        ("之前有没有拿过TOP/销冠？",
         "如果有：直接说数据，展示过往业绩能力\n如果没有：强调其他维度的成就，如新客户开发、团队协作等",
         "TOP经历是加分项，但不是必须"),
        ("如何在90天内突破100万GMV？",
         "思路：拆解目标 → 找关键路径\n100万÷90天≈1.1万/天\n需要多少个商家、每个商家多少交易额、每天需要拜访多少家\n展示你的策略思维，而不是只说「努力做」",
         "考察BD策略思维，要有具体可执行的思路"),
    ]
    for i, (q, a, tip) in enumerate(qas4):
        ty = Inches(1.7 + i * 1.75)
        add_rect(slide, Inches(0.4), ty, Inches(12.5), Inches(1.55),
                 C_CARD_BG, line_color=RGBColor(0xE8, 0xE8, 0xE8), line_width=Pt(1))
        add_text_box(slide, q, Inches(0.6), ty + Inches(0.1), Inches(5.5), Inches(0.4),
                     font_size=Pt(13), bold=True, color=C_PRIMARY)
        add_text_box(slide, a, Inches(0.6), ty + Inches(0.5), Inches(12), Inches(0.7),
                     font_size=Pt(11), color=C_TEXT_GRAY)
        add_text_box(slide, f"💡 {tip}", Inches(0.6), ty + Inches(1.2), Inches(12), Inches(0.3),
                     font_size=Pt(10), italic=True, color=RGBColor(0xE6, 0x7E, 0x22))
    add_footer(slide, 9, total)

    # 10. 面试准备checklist
    slide = slide_white(prs)
    add_header_bar(slide, "面试准备Checklist", "出发前全部打勾 ✓")
    checks = [
        ("📱", "下载抖音App，体验团购功能，了解商家端后台"),
        ("🔍", "搜索「抖音生活服务」，了解商家入驻和团购运作方式"),
        ("💼", "准备2-3个BD/销售案例，用STAR结构（最好有数字）"),
        ("💡", "想清楚：为什么对本地生活/抖音BD感兴趣（要有真实理由）"),
        ("🤝", "准备1个「打动你」的理由：为什么选择抖音而不是美团"),
        ("✅", "提前测试面试网络、准备安静环境"),
    ]
    for i, (icon, text) in enumerate(checks):
        ty = Inches(1.7 + i * 0.85)
        add_rect(slide, Inches(0.5), ty, Inches(12.3), Inches(0.7),
                 RGBColor(0xFF, 0xF8, 0xF5), line_color=C_PRIMARY, line_width=Pt(1))
        add_text_box(slide, icon, Inches(0.7), ty + Inches(0.1), Inches(0.8), Inches(0.5),
                     font_size=Pt(22))
        add_text_box(slide, text, Inches(1.6), ty + Inches(0.15), Inches(11), Inches(0.5),
                     font_size=Pt(14), color=C_TEXT_DARK)
    add_footer(slide, 10, total)

    output = "/root/.openclaw/workspace-newbot/字节BD面试物料v2.pptx"
    prs.save(output)
    print(f"✅ PPT已生成：{output}")
    return output

if __name__ == "__main__":
    build()
