#!/usr/bin/env python3
"""
携程特价机票监控脚本 v3
妈妈猫提供的最新Cookie，自动搜索五一特价机票
"""
import urllib.request
import json
import time
from datetime import datetime, timedelta

# ============================================================
# Cookie和请求头 - 每次请求需要妈妈猫提供最新版本
# ============================================================
COOKIE = """GUID=09031023217414352709; UBT_VID=1774269750400.12383UeiwFSI; nfes_isSupportWebP=1; _RGUID=2acfebd4-cd5b-438f-add8-5234c7893a06; cticket=3B8DAA6E8DCB332DD8A150335C1108FEC423E88242BBC31C755D9B3D52B73B26; login_type=0; login_uid=; DUID=u=4691947AF784A131918FB737040D9591&v=0; IsNonUser=F; AHeadUserInfo=VipGrade=10&VipGradeName=%BB%C6%BD%F0%B9%F3%B1%F6; _udl=708D70C2B179E2F91CC5ED1C2CCE362D; Hm_lvt_a8d6737197d542432f4ff4abc6e06384=1774269809; Hm_lpvt_a8d6737197d542432f4ff4abc6e06384=1774269809; HMACCOUNT=DE9FEA115703637B; MKT_CKID=1774269809770.10chm.4lz8; _jzqco=%7C%7C%7C%7C1774269809883%7C1.601569738.1774269809772.1774270064850.1774271016353.1774270064850.1774271016353.0.0.0.4.4; _bfa=1.1774269750400.12383UeiwFSI.1.1774271015235.1774271440793.1.10.10650052821"""

TRACE_ID = "09031023217414352709-1774271441120-578472"
FXPCQLNIREDT = "09031023217414352709"
CID = "09031023217414352709"

HEADERS = {
    "Accept": "*/*",
    "Accept-Language": "en,en-US;q=0.9,zh-CN;q=0.8,zh;q=0.7",
    "Content-Type": "application/json",
    "Cookie": COOKIE,
    "CookieOrigin": "https://flights.ctrip.com",
    "Origin": "https://flights.ctrip.com",
    "Priority": "u=1, i",
    "Referer": "https://flights.ctrip.com/",
    "Sec-Ch-Ua": '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Linux"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36",
    "X-Ctx-Ubt-PageId": "10650052821",
    "X-Ctx-Ubt-Pvid": "10",
    "X-Ctx-Ubt-Sid": "1",
    "X-Ctx-Ubt-Vid": "1774269750400.12383UeiwFSI",
    "_fxpcqlniredt": FXPCQLNIREDT,
    "x-traceID": TRACE_ID,
}

def search_flights(dep_code, dep_name, arr_code, arr_name, begin_date, end_date):
    """搜索特价机票"""
    payload = {
        "tt": 1,
        "source": "online_map",
        "st": 18,  # 特价
        "segments": [{
            "dcs": [{"ct": 1, "code": dep_code, "name": dep_name}],
            "acs": [{"ct": 3, "code": arr_code, "name": arr_name}],
            "dow": [],
            "sr": None,
            "drl": [{"begin": begin_date, "end": end_date}],
            "ddate": None
        }],
        "filters": None,
        "head": {
            "cid": CID, "ctok": "", "cver": "1.0", "lang": "01",
            "sid": "8888", "syscode": "999", "auth": "", "xsid": "", "extension": []
        }
    }
    
    url = f"https://m.ctrip.com/restapi/soa2/19728/fuzzySearch?_fxpcqlniredt={FXPCQLNIREDT}&x-traceID={TRACE_ID}"
    
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers=HEADERS,
        method="POST"
    )
    
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"error": str(e)}

def parse_results(data, budget, dep_code="SHA"):
    """解析结果，返回符合条件的航班"""
    results = []
    routes = data.get("routes", [])
    
    for r in routes:
        arrive_city = r.get("arriveCity", {})
        city_name = arrive_city.get("name", "?")
        city_code = arrive_city.get("code", "?")
        is_intl = arrive_city.get("isIntl", False)
        
        flights = r.get("flights", [])
        price_list = r.get("pl", [])
        
        # 匹配航班和价格
        for i, flight in enumerate(flights):
            if i >= len(price_list):
                break
            p = price_list[i]
            price = p.get("price", 0)
            depart_date = p.get("departDate", "")
            
            if price and price <= budget and price > 0:
                flight_info = {
                    "date": depart_date,
                    "price": int(price),
                    "flight_no": flight.get("flightNo", "?"),
                    "airline": flight.get("airline", {}).get("shortName", "?"),
                    "dep_time": flight.get("dtime", "").split(" ")[1] if " " in flight.get("dtime","") else "?",
                    "arr_time": flight.get("atime", "").split(" ")[1] if " " in flight.get("atime","") else "?",
                    "duration": flight.get("duration", 0),
                    "from": dep_code,
                    "to_code": city_code,
                    "to_name": city_name,
                    "intl": is_intl,
                }
                results.append(flight_info)
    
    return results

def format_duration(minutes):
    """格式化飞行时间"""
    h = minutes // 60
    m = minutes % 60
    return f"{h}h{m}m" if h else f"{m}m"

def print_results(all_results, budget, dep_date, ret_date):
    """打印结果"""
    print(f"\n{'='*60}")
    print(f"🛫 上海出发 → 五一假期（{dep_date} 至 {ret_date}）")
    print(f"   预算范围：¥{budget}以内 | 按价格升序")
    print(f"{'='*60}")
    
    if not all_results:
        print("😔 暂未找到符合条件的特价机票")
        return
    
    # 按价格排序
    all_results.sort(key=lambda x: x["price"])
    
    # 分类显示
    print(f"\n🎉 共找到 {len(all_results)} 个特价方案！\n")
    
    # 国内
    domestic = [r for r in all_results if not r["intl"]]
    if domestic:
        print("📍 国内航班：")
        print("-" * 55)
        print(f"{'日期':<12} {'目的地':<8} {'航班':<8} {'时间':<12} {'价':<6} {'航司'}")
        print("-" * 55)
        for r in domestic[:20]:  # 最多显示20条
            print(f"{r['date']:<12} {r['to_name']:<8} {r['flight_no']:<8} {r['dep_time']+'→'+r['arr_time']:<12} ¥{r['price']:<5} {r['airline']}")
    
    # 国际
    international = [r for r in all_results if r["intl"]]
    if international:
        print(f"\n🌏 国际/地区航班：")
        print("-" * 55)
        print(f"{'日期':<12} {'目的地':<10} {'航班':<8} {'时间':<12} {'价':<6} {'航司'}")
        print("-" * 55)
        for r in international[:10]:
            print(f"{r['date']:<12} {r['to_name']:<10} {r['flight_no']:<8} {r['dep_time']+'→'+r['arr_time']:<12} ¥{r['price']:<5} {r['airline']}")

def main():
    DEP_DATE = "2026-04-30"  # 去程
    RET_DATE = "2026-05-05"   # 返程
    
    print(f"\n🔍 正在搜索 上海→全中国 特价机票...")
    print(f"   日期范围：{DEP_DATE} 至 {RET_DATE}")
    
    # 搜全中国所有目的地
    data = search_flights("SHA", "上海", "DOMESTIC_ALL", "全中国", DEP_DATE, RET_DATE)
    
    if "error" in data:
        print(f"❌ 搜索失败：{data['error']}")
        return
    
    routes = data.get("routes", [])
    print(f"✅ 找到 {len(routes)} 条航线，正在筛选特价方案...")
    
    # 国内预算1500
    domestic = parse_results(data, 1500, "SHA")
    
    # 国际预算2500
    intl = parse_results(data, 2500, "SHA")
    intl = [r for r in intl if r["intl"]]
    
    all_results = domestic + intl
    
    print_results(all_results, 1500, DEP_DATE, RET_DATE)
    
    # 显示预算内的热门城市统计
    print(f"\n📊 低价城市TOP10（¥600以内）：")
    budget_friendly = [r for r in all_results if r["price"] <= 600]
    by_city = {}
    for r in budget_friendly:
        key = r["to_name"]
        if key not in by_city or r["price"] < by_city[key]["price"]:
            by_city[key] = r
    sorted_cities = sorted(by_city.values(), key=lambda x: x["price"])[:10]
    for r in sorted_cities:
        print(f"   {r['to_name']:<8} ¥{r['price']:>5} ({r['date']})")

if __name__ == "__main__":
    main()
