#!/usr/bin/env python3
"""
飞书群候选人自动登记脚本 v4
- S-抖音BD内部项目群 → 字节跳动 / 生活服务商家BD-城市 / RPO
  （格式："城市+字节BD：\n姓名：xxx"，HTML格式单独报告）
- 招聘对接群-PM李睿冰 → MINIMAX (岗位映射) 或 创想科技 / KOL / RPO
  （KOL格式："城市KOL简历推荐模板"，MINIMAX格式："海外广告视频投放-成都"）
- 写入新表格（ZxDKsepz5hzm8PtcNcUcrKUwnfe），按推荐日期升序
- HTML格式候选人（格式失误）单独报告，不写入表格
"""
import json, re, os
from datetime import date, datetime

SPREADSHEET_TOKEN = "ZxDKsepz5hzm8PtcNcUcrKUwnfe"
SHEET_ID = "00872f"
LOG_FILE = "/root/.openclaw/workspace-newbot/scripts/.register_log_v4"
LAST_FILES = {
    "oc_550fe92c1598eccdd9de308157eda095": "/root/.openclaw/workspace-newbot/scripts/.last_msg_douyin",
    "oc_978d6a0c1b28c3eb9d5496031a33e479": "/root/.openclaw/workspace-newbot/scripts/.last_msg_zhaopin",
}

MEMBERS = {
    "ou_fff9103206dfc5695fbcee4be212769e": "张本超",
    "ou_7e3c9b258c00ced92ad49afd39f04711": "李睿冰",
    "ou_4e9f8a6b14be53802581bcec16375022": "赵航",
    "ou_4803cd7260b528c0a3b34a134c544c52": "蒙雪君",
    "ou_7efb58679bb3bfcb60f7745082b158f5": "李锐",
    "ou_a53f0c139c017aab4fd4717bae5bc76b": "张本育",
    "ou_1262b7d53486b73dd91f51ee7b751da1": "罗晓婉",
    "ou_981ba595436335d2e8d79e8466d950e0": "刘川旗",
    "ou_66a368e50ca3621b454a442a8a05e8ce": "李远",
}

MINIMAX_POSITIONS = {
    "AI对话-安全攻防": "AI对话-安全攻防",
    "AI创意视频制作": "AI创意视频制作",
    "AI视频模版设计师": "AI视频模版设计师",
    "测试工程师": "测试工程师",
    "创意策划-信息流方向": "创意策划-信息流方向",
    "广告投放视频设计师": "广告投放视频设计师",
    "国内安全-BPO交付运营": "国内安全-BPO交付运营",
    "国内安全-审核运营": "国内安全-审核运营",
    "海外广告投放视频设计师": "海外广告投放视频设计师",
    "开发者内容创作": "开发者内容创作",
    "前端工程师": "前端工程师",
    "视频创意内容设计师": "视频创意内容设计师",
    "视频内容AI数据标注师": "视频内容AI数据标注师",
    "用户体验-客服": "用户体验-客服",
    "海外广告视频投放": "海外广告投放视频设计师",  # 向崇星格式
}

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")

def get_token():
    import urllib.request
    req = urllib.request.Request(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        data=json.dumps({"app_id": "cli_a979e8bc7b789bda", "app_secret": "yKUOlPu08bgeeSO8mVVqLd3BvbaJXuYO"}).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())["tenant_access_token"]

def today_serial():
    return (date(1899, 12, 30) - date.today()).days * -1

def extract_text(raw):
    try:
        p = json.loads(raw)
        if isinstance(p, dict):
            if "text" in p: return p["text"]
            if "content" in p:
                parts = []
                for section in p.get("content", []):
                    for e in section:
                        if isinstance(e, dict) and e.get("tag") == "text":
                            parts.append(e.get("text", ""))
                return "".join(parts)
    except:
        pass
    return str(raw)

# ---- 解析器 ----

def parse_douyin(text, sender_id):
    """字节跳动格式，返回 (candidate, error_str)"""
    clean = re.sub(r"<[^>]+>", "", text)  # 去掉HTML标签
    # 标准格式：城市+字节BD：\n姓名：xxx
    m = re.search(r"^(.+?字节生服BD|字节BD)[:：]\s*\n?姓名[：:]([^\n]+)", clean, re.M)
    if not m:
        # 检查是否是HTML格式的候选人（包含姓名标签但不是标准城市+字节BD格式）
        if re.search(r"姓名[：:]\S+", clean) and ("<p>" in text or "<br" in text.lower()):
            # 尝试提取姓名和学历
            nm = re.search(r"姓名[：:]\s*([^\n<]+)", clean)
            edu_m = re.search(r"学历[：:]\s*(\S+)", clean)
            edu = ""
            if edu_m:
                e = edu_m.group(1).strip()
                edu = "本科及以上" if e in ("本科", "大学本科") else e
            name = nm.group(1).strip() if nm else "未知"
            city_match = re.search(r"(.+?)字节生服BD|字节BD", clean)
            city = city_match.group(1).strip().replace("字节生服BD","").replace("字节BD","").strip() if city_match else "未知"
            sender_name = MEMBERS.get(sender_id, sender_id)
            return None, f"[HTML格式需人工] {name} | 城市:{city} | 推荐人:{sender_name} | 学历:{edu} | 原文:{text[:100]}"
        return None, None
    city = m.group(1).replace("字节生服BD", "").replace("字节BD", "").strip()
    name = m.group(2).strip()
    edu_m = re.search(r"学历[：:]\s*(\S+)", clean)
    edu = ""
    if edu_m:
        e = edu_m.group(1).strip()
        edu = "本科及以上" if e in ("本科", "大学本科") else e
    c = {
        "project": "字节跳动", "position": f"生活服务商家BD-{city}",
        "name": name, "sender_id": sender_id,
        "sender_name": MEMBERS.get(sender_id, sender_id),
        "recommend_date": today_serial(), "cooperation_mode": "RPO",
        "education": edu or "本科及以上", "remarks": ""
    }
    return c, None

def parse_kol(text, sender_id):
    """KOL格式，返回 candidate 或 None"""
    m = re.search(r"(.+?)KOL简历推荐模板", text)
    if not m: return None
    city = m.group(1).strip()
    nm = re.search(r"姓名[：:]\s*(\S+)", text)
    if not nm: return None
    name = nm.group(1).strip()
    edu_m = re.search(r"学历[：:]\s*(\S+)", text)
    edu = ""
    if edu_m:
        e = edu_m.group(1).strip()
        edu = "本科及以上" if e in ("本科", "大学本科") else e
    tj = re.search(r"推荐语[：:]\s*(.+?)(?:\n|$)", text, re.DOTALL)
    return {
        "project": "创想科技", "position": "KOL",
        "name": name, "sender_id": sender_id,
        "sender_name": MEMBERS.get(sender_id, sender_id),
        "recommend_date": today_serial(), "cooperation_mode": "RPO",
        "education": edu or "本科及以上",
        "remarks": tj.group(1).strip()[:200] if tj else ""
    }

def parse_minimax(text, sender_id):
    """MINIMAX格式，返回 candidate 或 None"""
    nm = re.search(r"姓名[：:]\s*(\S+)", text)
    if not nm: return None
    name = nm.group(1).strip()
    # 匹配"岗位-城市  数字、姓名"格式
    pos_m = re.search(r"^([^\n]+?)\s*\n?\s*\d[、.]\s*姓名", text)
    if not pos_m: return None
    raw_prefix = pos_m.group(1).strip()
    pos_m2 = re.search(r"(.+?)-([^\s-]+)$", raw_prefix)
    if not pos_m2: return None
    raw_pos, city = pos_m2.group(1).strip(), pos_m2.group(2).strip()
    position = MINIMAX_POSITIONS.get(raw_pos)
    if not position: return None
    edu_m = re.search(r"学历[：:]\s*(\S+)", text)
    edu = ""
    if edu_m:
        e = edu_m.group(1).strip()
        edu = "本科及以上" if e in ("本科", "大学本科") else e
    return {
        "project": "MINIMAX", "position": position,
        "name": name, "sender_id": sender_id,
        "sender_name": MEMBERS.get(sender_id, sender_id),
        "recommend_date": today_serial(), "cooperation_mode": "外包",
        "education": edu or "本科及以上", "remarks": ""
    }

# ---- 表格操作 ----

def get_last_row(token):
    """快速查最后有数据的行"""
    import urllib.request
    for start in range(2, 3000, 100):
        url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values/{SHEET_ID}!A{start}:F{start+99}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        try:
            with urllib.request.urlopen(req) as r:
                data = json.loads(r.read())
            vals = data.get("data", {}).get("valueRange", {}).get("values", [])
            non_empty = [(start+i, r[0]) for i, r in enumerate(vals) if r and r[0] is not None]
            if not non_empty:
                return start if start > 2 else 2
        except:
            return start
    return 2

def write_row(token, row_num, c):
    import urllib.request
    url = f"https://open.feishu.cn/open-apis/sheets/v2/spreadsheets/{SPREADSHEET_TOKEN}/values"
    payload = {"valueRange": {"range": f"{SHEET_ID}!A{row_num}:R{row_num}",
                               "values": [[
        c["recommend_date"], c["sender_name"], "李睿冰",
        c["project"], c["cooperation_mode"], c["name"], "",
        c["education"], c["position"],
        "", "", "", "", "", "", "", "", ""
    ]]}}
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="PUT")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())

# ---- 主逻辑 ----

def process_group(token, chat_id, lfile):
    import urllib.request
    msgs = []
    page_token = None
    last_time = open(lfile).read().split("=", 1)[1].strip() if os.path.exists(lfile) else None

    for _ in range(20):
        url = (f"https://open.feishu.cn/open-apis/im/v1/messages"
               f"?container_id_type=chat&container_id={chat_id}"
               f"&sort_type=ByCreateTimeDesc&page_size=50")
        if page_token: url += f"&page_token={page_token}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req) as r:
            data = json.loads(r.read())
        items = data.get("data", {}).get("items", [])
        has_more = data.get("data", {}).get("has_more", False)
        page_token = data.get("data", {}).get("page_token", "")
        for item in items:
            t = item.get("create_time", "")
            if last_time is not None and last_time != "0" and t <= last_time: break
            if item.get("deleted") or item.get("msg_type") not in ("text", "post"): continue
            if not item.get("sender", {}).get("id"): continue
            msgs.append(item)
        if not has_more or (last_time is not None and last_time != "0" and msgs): break

    msgs.reverse()  # 旧→新
    newest = msgs[-1].get("create_time", "") if msgs else None
    candidates, errors = [], []

    for msg in msgs:
        sid = msg.get("sender", {}).get("id")
        txt = extract_text(msg.get("body", {}).get("content", ""))
        if not txt: continue

        c, err = None, None
        if chat_id == "oc_550fe92c1598eccdd9de308157eda095":
            c, err = parse_douyin(txt, sid)
        elif chat_id == "oc_978d6a0c1b28c3eb9d5496031a33e479":
            c = parse_kol(txt, sid)
            if not c: c = parse_minimax(txt, sid)

        if err: errors.append(err)
        elif c: candidates.append(c)

    return candidates, errors, newest

def main():
    log("=== 候选人登记任务(v4) ===")
    token = get_token()
    all_cands, all_errors = [], []
    douyin_newest, zhaopin_newest = None, None

    cands, errs, douyin_newest = process_group(token, "oc_550fe92c1598eccdd9de308157eda095", LAST_FILES["oc_550fe92c1598eccdd9de308157eda095"])
    all_cands.extend(cands); all_errors.extend(errs)
    for c in cands: log(f"  ✅ [字节跳动] {c['name']} | {c['position']}")
    for e in errs: log(f"  ⚠️  {e}")

    cands, errs, zhaopin_newest = process_group(token, "oc_978d6a0c1b28c3eb9d5496031a33e479", LAST_FILES["oc_978d6a0c1b28c3eb9d5496031a33e479"])
    all_cands.extend(cands); all_errors.extend(errs)
    for c in cands: log(f"  ✅ [{c['project']}] {c['name']} | {c['position']}")

    if not all_cands and not all_errors:
        log("📭 无新候选人")
        return

    if all_errors:
        log("⚠️ 【需人工处理 - 格式失误候选人】")
        for e in all_errors: log(f"  {e}")

    if all_cands:
        all_cands.sort(key=lambda x: x["recommend_date"])
        last_row = get_last_row(token)
        next_row = max(last_row, 1) + 1
        for c in all_cands:
            r = write_row(token, next_row, c)
            status = "✅" if r.get("code") == 0 else "❌"
            log(f"  {status} 第{next_row}行: {c['name']} | {c['project']} | {c['position']}")
            next_row += 1

    if douyin_newest:
        with open(LAST_FILES["oc_550fe92c1598eccdd9de308157eda095"], "w") as f:
            f.write(f"last_time={douyin_newest}")
    if zhaopin_newest:
        with open(LAST_FILES["oc_978d6a0c1b28c3eb9d5496031a33e479"], "w") as f:
            f.write(f"last_time={zhaopin_newest}")

    log(f"✅ 完成，共{len(all_cands)}条写入，{len(all_errors)}条格式问题需人工处理")

if __name__ == "__main__":
    main()
