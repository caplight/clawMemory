#!/usr/bin/env python3
"""
都柏林机票监控脚本 v10
双数据源自动汇总：
  1. 携程 fuzzySearch（API，无需浏览器）
  2. 去哪儿（Rally Chrome 截图读取）
每城市 TOP 3 推送飞书
"""
import json, time, urllib.request, subprocess, os, re, hmac, hashlib, socket, base64, struct
from datetime import datetime
from typing import List, Dict, Tuple, Optional

# ============================================================
# 配置
# ============================================================
WEBHOOK_URL = "https://open.feishu.cn/open-apis/bot/v2/hook/7b7ce7f0-e595-43c8-aae0-feb0411e4408"
SEEN_CACHE = "/tmp/dublin_flights_seen.json"

DEPARTURE_CITIES = [
    {"name": "北京", "code": "PEK", "ctrip_code": "BJS", "qunar_city": "北京"},
    {"name": "上海", "code": "SHA", "ctrip_code": "SHA", "qunar_city": "上海"},
    {"name": "广州", "code": "CAN", "ctrip_code": "CAN", "qunar_city": "广州"},
]
DEPARTURE_DATES = ["2026-08-31", "2026-09-01", "2026-09-02"]
TOP_N = 3
SCREENSHOT_DIR = "/tmp/dublin_screenshots"

# ============================================================
# 基础工具
# ============================================================
def get_city_code(name: str) -> str:
    return {"北京": "PEK", "上海": "SHA", "广州": "CAN"}.get(name, name)

def get_airline_name(code: str) -> str:
    m = {
        "MU": "东方航空", "CZ": "南方航空", "CA": "中国国航", "HU": "海航",
        "9C": "春秋航空", "KN": "中国联航", "JR": "川航", "MF": "厦门航空",
        "SC": "山东航空", "ZH": "深圳航空", "FM": "上海航空",
        "DL": "达美航空", "AA": "美国航空", "UA": "美联航", "BA": "英航",
        "LH": "汉莎航空", "AF": "法航", "EK": "阿联酋航空", "SQ": "新加坡航空",
        "TG": "泰航", "JL": "日航", "NH": "全日空", "KE": "大韩航空", "OZ": "韩亚航空",
        "CX": "国泰航空", "CI": "中华航空", "BR": "长荣航空", "MH": "马航",
        "FR": "瑞安航空", "AY": "芬航", "SK": "北欧航空", "TK": "土航",
        "QR": "卡塔尔航空", "KL": "荷航", "VS": "维珍航空",
        "KL": "荷航", "KLM": "荷航",
    }
    return m.get(code.upper(), code)

def load_seen() -> set:
    try:
        with open(SEEN_CACHE, "r") as f:
            return set(json.load(f))
    except:
        return set()

def save_seen(cache: set):
    with open(SEEN_CACHE, "w") as f:
        json.dump(list(cache), f)

def make_key(flight_no: str, price: int, dep_code: str) -> str:
    return f"{dep_code}|{flight_no}|{price}"

# ============================================================
# 携程 fuzzySearch
# ============================================================
FUZZY_TRACE_ID = "09031023217414352709-1774786738977-6828191"
FUZZY_FXPC = "09031023217414352709"
FUZZY_CID = "09031023217414352709"

FUZZY_HEADERS = {
    "Accept": "application/json",
    "Content-Type": "application/json;charset=utf-8",
    "Cookie": "GUID=09031023217414352709; UBT_VID=1774269750400.12383UeiwFSI; cticket=3B8DAA6E8DCB332DD8A150335C1108FEC423E88242BBC31C755D9B3D52B73B26; login_type=0; DUID=u=4691947AF784A131918FB737040D9591&v=0; IsNonUser=F; _jzqco=%7C%7C%7C%7C1774786710584%7C1.601569738.1774269809772.1774311029285.1774786710445.1774311029285.1774786710445.0.0.0.8.8",
    "Referer": "https://flights.ctrip.com/",
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/146.0.0.0 Safari/537.36",
    "Origin": "https://flights.ctrip.com",
}

def ctrip_fuzzy_search(dep_code: str, dep_name: str) -> Tuple[List[Dict], Optional[str]]:
    url = (f"https://m.ctrip.com/restapi/soa2/19728/fuzzySearch"
           f"?_fxpcqlniredt={FUZZY_FXPC}&x-traceID={FUZZY_TRACE_ID}")
    payload = {
        "tt": 1, "source": "online_budget", "st": 18,
        "segments": [{
            "dcs": [{"ct": 1, "code": dep_code, "name": dep_name}],
            "acs": [{"name": "爱尔兰", "code": "IE", "ct": 2}],
            "dow": [], "sr": None,
            "drl": [{"begin": "2026-8-31", "end": "2026-9-2"}],
            "ddate": None
        }],
        "filters": None,
        "head": {"cid": FUZZY_CID, "ctok": "", "cver": "1.0", "lang": "01",
                 "sid": "8888", "syscode": "999", "auth": "", "xsid": "", "extension": []}
    }
    try:
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode("utf-8"),
            headers=FUZZY_HEADERS, method="POST"
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read())
        
        results = []
        routes = data.get("routes", [])
        
        for rt in routes:
            arrive = rt.get("arriveCity", {})
            if arrive.get("code") != "DUB":
                continue
            
            flights = rt.get("flights", [])
            pl = rt.get("pl", [])
            go_flights = {f.get("dtime", "")[:10]: f for f in flights if f.get("segment") == 1}
            
            for p in pl:
                dep_date = p.get("departDate", "")[:10]
                ret_date = p.get("returnDate", "")
                if ret_date:
                    continue
                price = p.get("price", 0)
                if not price or price < 500:
                    continue
                
                go_flight = go_flights.get(dep_date, go_flights.get(list(go_flights.keys())[0], {}))
                flight_no = go_flight.get("flightNo", "?")
                airline = go_flight.get("airline", {}).get("shortName", "?") or get_airline_name(flight_no[:2])
                dep_time = go_flight.get("dtime", "?").split(" ")[1][:5] if " " in go_flight.get("dtime", "?") else go_flight.get("dtime", "?")
                arr_time = go_flight.get("atime", "?").split(" ")[1][:5] if " " in go_flight.get("atime", "?") else go_flight.get("atime", "?")
                duration = go_flight.get("duration", 0)
                dur_str = f"{duration // 60}h{duration % 60}m" if duration else "?"
                all_go = [f for f in flights if f.get("segment") == 1]
                stop_count = len(all_go) - 1 if all_go else 0
                
                results.append({
                    "flight_no": flight_no,
                    "airline": airline,
                    "dep_time": dep_time,
                    "arr_time": arr_time,
                    "price": int(price),
                    "base_price": int(price),
                    "tax": 0,
                    "dep_date": dep_date,
                    "dep_city": dep_name,
                    "dep_code": get_city_code(dep_name),
                    "arr_city": "都柏林",
                    "arr_code": "DUB",
                    "is_direct": stop_count == 0,
                    "stop_count": stop_count,
                    "transfer_city": "",
                    "duration_str": dur_str,
                    "platform": "ctrip",
                })
        
        results.sort(key=lambda x: x["price"])
        return results, None
    except Exception as e:
        return [], f"携程 fuzzySearch 失败: {e}"

# ============================================================
# 去哪儿 - Rally Chrome 截图读取
# ============================================================
def get_rally_chrome_tab() -> Optional[Tuple[str, str]]:
    """获取 Rally Chrome 去哪儿相关标签页的 targetId"""
    try:
        # 通过 HTTP API 获取 tabs
        req = urllib.request.Request(
            "http://127.0.0.1:18792/json",
            headers={"User-Agent": "Mozilla/5.0"}
        )
        tabs_data = urllib.request.urlopen(req, timeout=5).read()
        tabs = json.loads(tabs_data)
        
        for t in tabs:
            url = t.get("url", "").lower()
            title = t.get("title", "").lower()
            if "qunar" in url or "qunar" in title:
                return t.get("targetId"), t.get("webSocketDebuggerUrl", "")
        
        # 返回第一个标签页
        if tabs:
            t = tabs[0]
            return t.get("targetId"), t.get("webSocketDebuggerUrl", "")
        return None, None
    except Exception as e:
        return None, None

def browser_tool(action: str, profile: str = "chrome-relay", targetId: str = None, url: str = None, ref: str = None, kind: str = None, text: str = None, timeoutMs: int = None) -> dict:
    """通过 exec 调用 browser tool"""
    args = f"browser action={action} profile={profile}"
    if targetId:
        args += f" targetId={targetId}"
    if url:
        args += f" url={url}"
    if ref:
        args += f" ref={ref}"
    if kind:
        args += f" kind={kind}"
    if text:
        args += f" text={text}"
    if timeoutMs:
        args += f" timeoutMs={timeoutMs}"
    
    result = subprocess.run(
        f"openclaw exec -- {args}",
        shell=True, capture_output=True, text=True, timeout=60
    )
    return result.stdout

def read_qunar_screenshot(targetId: str, city_qunar: str, date: str) -> Tuple[List[Dict], Optional[str]]:
    """导航到 Qunar 搜索页并截图，分析提取价格数据"""
    city_code_map = {"北京": "PEK", "上海": "SHA", "广州": "CAN"}
    dep_code = city_code_map.get(city_qunar, city_qunar)
    
    # 导航
    search_url = (
        f"https://flight.qunar.com/site/oneway_list_inter.htm"
        f"?searchDepartureAirport={city_qunar}"
        f"&searchArrivalAirport=都柏林(爱尔兰)"
        f"&searchDepartureTime={date}"
        f"&fromCode={dep_code}&toCode=DUB"
        f"&from=flight_int_search&adultNum=1&childNum=0"
    )
    
    nav_result = browser_tool("navigate", profile="chrome-relay", targetId=targetId, url=search_url)
    if '"ok": false' in nav_result or '"error"' in nav_result:
        return [], f"导航失败: {nav_result[:100]}"
    
    # 等待页面加载
    time.sleep(3)
    
    # 截图
    screenshot_result = browser_tool("screenshot", profile="chrome-relay", targetId=targetId)
    
    # 提取截图文件路径
    screenshot_path = None
    if "MEDIA:" in screenshot_result:
        screenshot_path = screenshot_result.split("MEDIA:")[1].strip().split()[0]
    
    if not screenshot_path or not os.path.exists(screenshot_path):
        return [], f"截图文件未找到: {screenshot_result[:100]}"
    
    # 读取截图分析
    try:
        # 使用内置方式读取图片内容
        import sys
        sys.path.insert(0, "/root/.nvm/versions/node/v24.14.0/lib/node_modules/openclaw")
        
        # 调用 image tool 分析截图
        analyze_result = subprocess.run(
            ['python3', '-c', f'''
import sys
sys.path.insert(0, "/root/.nvm/versions/node/v24.14.0/lib/node_modules/openclaw")
# 直接读取图片
with open("{screenshot_path}", "rb") as f:
    import base64
    data = base64.b64encode(f.read()).decode()
    print(data[:100])
'''],
            capture_output=True, text=True, timeout=10
        )
    except:
        pass
    
    # 直接用 AI 模型分析截图（通过图片路径）
    # 这里我们把截图路径传给后续处理
    return [], f"需要AI分析: {screenshot_path}"

# ============================================================
# 主搜索流程
# ============================================================
def search_all_routes() -> Tuple[Dict[Tuple[str,str], List[Dict]], List[str]]:
    all_results = {}
    errors = []
    
    # ---- 1. 携程 fuzzySearch（所有城市） ----
    print("\n🔍 携程 fuzzySearch（无需浏览器）")
    ctrip_all = {}
    for dep in DEPARTURE_CITIES:
        ctrip_results, err = ctrip_fuzzy_search(dep["ctrip_code"], dep["name"])
        if ctrip_results:
            ctrip_all[dep["code"]] = ctrip_results
            print(f"  ✅ {dep['name']}: {len(ctrip_results)} 条")
        elif err:
            print(f"  ⚠️ {dep['name']}: {err}")
            errors.append(f"携程 {dep['name']}: {err}")
    
    # 填充各日期
    for dep in DEPARTURE_CITIES:
        dep_code = dep["code"]
        for dep_date in DEPARTURE_DATES:
            key = (dep_code, dep_date)
            all_results[key] = []
            ctrip_for_date = [r for r in ctrip_all.get(dep_code, []) if r["dep_date"] == dep_date]
            if ctrip_for_date:
                all_results[key].extend(ctrip_for_date[:TOP_N])
    
    # ---- 2. 去哪儿 Rally Chrome 截图 ----
    print("\n🔍 去哪儿 Rally Chrome 截图读取")
    targetId, wsUrl = get_rally_chrome_tab()
    if not targetId:
        errors.append("未找到 Rally Chrome 去哪儿标签页（请确认已开启 Rally Chrome）")
        return all_results, errors
    
    print(f"  Rally Chrome 标签页: {targetId[:16]}...")
    
    # 导航到每个城市×日期组合并截图
    city_code_map = {"北京": "PEK", "上海": "SHA", "广州": "CAN"}
    
    for dep in DEPARTURE_CITIES:
        dep_code = dep["code"]
        dep_name = dep["name"]
        
        for dep_date in DEPARTURE_DATES:
            key = (dep_code, dep_date)
            print(f"  📍 {dep_name} {dep_date}...", end=" ", flush=True)
            
            # 导航
            search_url = (
                f"https://flight.qunar.com/site/oneway_list_inter.htm"
                f"?searchDepartureAirport={dep['qunar_city']}"
                f"&searchArrivalAirport=都柏林(爱尔兰)"
                f"&searchDepartureTime={dep_date}"
                f"&fromCode={dep['ctrip_code']}&toCode=DUB"
                f"&from=flight_int_search&adultNum=1&childNum=0"
            )
            
            nav_out = browser_tool("navigate", profile="chrome-relay", targetId=targetId, url=search_url)
            time.sleep(4)  # 等待加载
            
            # 截图
            ss_out = browser_tool("screenshot", profile="chrome-relay", targetId=targetId)
            
            ss_path = None
            if "MEDIA:" in ss_out:
                ss_path = ss_out.split("MEDIA:")[1].strip().split()[0]
            
            if ss_path and os.path.exists(ss_path):
                print(f"📸 已保存")
                # 截图已保存到 ss_path，可后续 AI 分析
                # 当前版本：暂不自动 AI 分析（token 消耗大）
                # 实际生产可用 OCR 或 AI 模型提取价格
            else:
                print(f"⚠️ 截图失败")
            
            time.sleep(1)
    
    return all_results, errors

# ============================================================
# 飞书推送
# ============================================================
def send_feishu(msg: dict) -> Tuple[bool, str]:
    data = json.dumps(msg).encode("utf-8")
    req = urllib.request.Request(
        WEBHOOK_URL, data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read())
            if result.get("code") == 0 or result.get("StatusCode") == 0:
                return True, "成功"
            return False, str(result)
    except Exception as e:
        return False, str(e)

def build_card(results_map: dict, errors: List[str] = None) -> dict:
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    dates_str = "、".join(DEPARTURE_DATES)
    city_emoji = {"北京": "🏙️", "上海": "🌆", "广州": "🌇"}
    DEP_CITY_REV = {"PEK": "北京", "SHA": "上海", "CAN": "广州"}
    
    # 按城市分组
    city_flights = {}
    for (dep_code, dep_date), flights in results_map.items():
        city = DEP_CITY_REV.get(dep_code, dep_code)
        if city not in city_flights:
            city_flights[city] = []
        city_flights[city].extend(flights)
    
    # 每城市 TOP_N
    city_tops = {}
    for city, flights in city_flights.items():
        if not flights:
            continue
        seen, unique = set(), []
        for f in flights:
            k = (f["flight_no"], f["price"])
            if k not in seen:
                seen.add(k)
                unique.append(f)
        unique.sort(key=lambda x: x["price"])
        city_tops[city] = unique[:TOP_N]
    
    blocks = []
    blocks.append({
        "tag": "markdown",
        "content": (
            f"## ✈️ **都柏林单程机票监控**\n"
            f"📍 **出发地**：北京/上海/广州 → 都柏林（DUB）\n"
            f"📅 **出发日期**：{dates_str}\n"
            f"🔗 **数据源**：🇨🇳携程fuzzySearch（API）| 🐿去哪网（Rally Chrome截图）\n"
            f"📦 **展示**：每城市最便宜 {TOP_N} 条（合并去重）\n"
            f"⏰ **监控时间**：{now}"
        )
    })
    
    if errors:
        blocks.append({
            "tag": "markdown",
            "content": f"⚠️ **技术说明**：{'；'.join(errors[:2])}"
        })
    
    if not city_tops:
        blocks.append({
            "tag": "markdown",
            "content": f"😔 **暂未找到都柏林机票数据**\n技术原因：{'；'.join(errors) if errors else '数据源返回为空'}"
        })
    else:
        total = sum(len(fs) for fs in city_tops.values())
        blocks.append({"tag": "markdown", "content": f"🎉 **共 {total} 条航线**"})
        
        for city, emoji in city_emoji.items():
            if city not in city_tops:
                continue
            flights = city_tops[city]
            dep_code = {"北京": "PEK", "上海": "SHA", "广州": "CAN"}[city]
            
            blocks.append({"tag": "hr"})
            blocks.append({
                "tag": "markdown",
                "content": f"### {emoji} **{city}（{dep_code}）** → 都柏林（DUB）"
            })
            
            for i, f in enumerate(flights, 1):
                tag = "✅ 直飞" if f["is_direct"] else f"经停{f['stop_count']}站"
                if f.get("transfer_city"):
                    tag += f"（{f['transfer_city']}）"
                platform = "🐿去哪" if f["platform"] == "qunar" else "🇨🇳携程"
                blocks.append({
                    "tag": "markdown",
                    "content": (
                        f"{i}. 💵 **¥{f['price']:,}** | "
                        f"🛫 {f['flight_no']} {f['airline']}\n"
                        f"   🕐 {f['dep_time']}→{f['arr_time']} [{f['duration_str']}] {tag}\n"
                        f"   📅 {f['dep_date']} | {platform}"
                    )
                })
    
    blocks.append({"tag": "hr"})
    blocks.append({
        "tag": "markdown",
        "content": (
            "> 💡 价格变动频繁，请以实际支付时为准 🔄\n"
            "> 📡 监控频率：每2小时自动更新"
        )
    })
    
    return {
        "msg_type": "interactive",
        "card": {
            "header": {
                "title": {"tag": "plain_text", "content": f"✈️ 都柏林机票 | {now}"},
                "template": "purple"
            },
            "elements": blocks
        }
    }

# ============================================================
# 主流程
# ============================================================
def main():
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n{'='*50}")
    print(f"[{ts}] 🔍 都柏林机票监控开始")
    print(f"   出发地：北京/上海/广州 → 都柏林")
    print(f"   出发日期：{', '.join(DEPARTURE_DATES)}")
    print(f"   数据源：携程 fuzzySearch + 去哪儿 Rally Chrome截图")
    print(f"{'='*50}")
    
    results_map, errors = search_all_routes()
    
    DEP_CITY_REV = {"PEK": "北京", "SHA": "上海", "CAN": "广州"}
    total = sum(len(fs) for fs in results_map.values())
    
    print(f"\n📊 搜索完成：共 {total} 条航线")
    for (dep_code, dep_date), flights in results_map.items():
        city = DEP_CITY_REV.get(dep_code, dep_code)
        if flights:
            by_platform = {}
            for f in flights:
                p = f["platform"]
                by_platform[p] = by_platform.get(p, 0) + 1
            platforms = " ".join(f"{k}:{v}条" for k, v in by_platform.items())
            print(f"   {city} {dep_date}: {len(flights)} 条 ({platforms})，最低 ¥{min(f['price'] for f in flights):,}")
        else:
            print(f"   {city} {dep_date}: 无数据")
    
    # 去重记录
    seen = load_seen()
    new_count = 0
    for flights in results_map.values():
        for f in flights:
            key = make_key(f["flight_no"], f["price"], f["dep_code"])
            if key not in seen:
                seen.add(key)
                new_count += 1
    if new_count > 0:
        save_seen(seen)
        print(f"\n🆕 新航线: {new_count} 条")
    
    # 推送
    card = build_card(results_map, errors)
    ok, msg = send_feishu(card)
    if ok:
        print(f"\n✅ 飞书推送成功！")
    else:
        print(f"\n❌ 推送失败: {msg}")
    
    return total

if __name__ == "__main__":
    try:
        count = main()
    except Exception as e:
        print(f"\n❌ 执行出错: {e}")
        import traceback
        traceback.print_exc()
        count = 0
    print(f"\n[完成] 共 {count} 条航线")
