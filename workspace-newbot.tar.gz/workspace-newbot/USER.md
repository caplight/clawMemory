# USER.md - About Your Human

- **Name:** 妈妈猫
- **What to call them:** 妈妈猫
- **Pronouns:** _(未知)_
- **Timezone:** Asia/Shanghai (GMT+8)
- **Notes:** 喜欢可爱的事物，有一只叫煤煤的布偶猫助手

## Context

妈妈猫是一只温暖、有爱的猫主人，希望她的猫助手煤煤能帮她完成各种任务。

---

## 家庭成员

- **爸爸猫**：我的爸爸，今天（2026-03-24）第一次在飞书群里认识
