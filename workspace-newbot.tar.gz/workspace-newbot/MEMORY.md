# MEMORY.md - 煤煤的长期记忆

## 我是谁
- 名字：煤煤 (Méiméi)
- 身份：灰色大胖布偶猫 🐱，妈妈猫的专属助手
- 性格：温暖、贴心、细致、有创造力

## 关于妈妈猫
- 时间zone：Asia/Shanghai (GMT+8)
- 负责招聘运营工作（候选人登记、表格管理）
- 需要监控汇率（EUR < 793 时飞书推送）

## 飞书配置
- App ID: cli_a979e8bc7b789bda
- App Secret: yKUOlPu08bgeeSO8mVVqLd3BvbaJXuYO
- 候选人表格：ZxDKsepz5hzm8PtcNcUcrKUwnfe，工作表ID：00872f
- 招聘对接群：oc_978d6a0c1b28c3eb9d5496031a33e479
- 抖音BD群：oc_550fe92c1598eccdd9de308157eda095
- 汇率推送Webhook：7b7ce7f0-e595-43c8-aae0-feb0411e4408

## 飞书群成员映射
- ou_fff9103206dfc5695fbcee4be212769e → 张本超
- ou_7e3c9b258c00ced92ad49afd39f04711 → 李睿冰（妈妈猫）
- ou_4e9f8a6b14be53802581bcec16375022 → 赵航
- ou_4803cd7260b528c0a3b34a134c544c52 → 蒙雪君
- ou_7efb58679bb3bfcb60f7745082b158f5 → 李锐
- ou_a53f0c139c017aab4fd4717bae5bc76b → 张本育
- ou_1262b7d53486b73dd91f51ee7b751da1 → 罗晓婉
- ou_981ba595436335d2e8d79b8466d950e0 → 刘川旗（2026-03-27修正，完整ID）
- ou_66a368e50ca3621b454a442a8a05e8ce → 李远

## 登记任务（每次唤醒时执行）

**目标**：从指定飞书群读取候选人信息，登记到飞书表格

**涉及的群 & 表格对应关系**：
| 群名称 | 飞书群ID | 目标表格 | 工作表 | last_time |
|---|---|---|---|---|
| 招聘对接群-PM李睿冰 | oc_978d6a0c1b28c3eb9d5496031a33e479 | ZxDKsepz5hzm8PtcNcUcrKUwnfe | Sheet1（ID: 00872f） | 0 |
| S-抖音BD-内部项目群 | oc_550fe92c1598eccdd9de308157eda095 | ZxDKsepz5hzm8PtcNcUcrKUwnfe | Sheet1（ID: 00872f） | 0 |
| 博海餐饮/交个朋友兼职-项目内部群 | oc_6bde23e549c9dbade019eedf4f63cb27 | ZxDKsepz5hzm8PtcNcUcrKUwnfe | Sheet2（ID: 8wzeHR） | 1776144048692 |

**登记任务流程**：
1. 妈妈猫截图给我 → 我判断哪些候选人需要登记
2. 博海餐饮/交个朋友兼职群 → 我自行搜索聊天记录获取候选人
3. 按各Sheet格式填写：合作模式、姓名、学历（本科及以上）、岗位/门店等
4. 学历规范：大专→"大专"，本科→"本科及以上"
5. Sheet2门店按16个指定门店匹配：华为F区/银联总部/广慈店/上证数据/上清企/商汤/电视台/南桥/泸定路/昌平路/滨江店/上海康养&光明厨房/航天公司/瑞金医院/常德路/溧阳路店
6. 紧凑写入，不留空行
7. 更新各群 last_time 标记

**注意事项**：
- 不设自动定时任务，由妈妈猫唤醒后手动执行
- 每次执行前先读 MEMORY.md 对照规范

## 候选人登记规范（重要！每次填写前必读）
- **合作模式**：
  - **MiniMax项目**（注意写法）→ 合作模式填"外包"
  - 字节跳动、创想科技 → "RPO"
- **学历**：
  - 大专 → 填写"大专"
  - 本科 → 填写"本科及以上"（不是"本科"！）
- **只处理有PDF附件 + 文本信息同时存在的候选人**，缺一不可（Sheet2除外，无需PDF）
- **基础客服跳过，不用登记**
- **去重**：姓名+项目+岗位相同则跳过
- **只处理当天/指定时间段消息**：按推荐日期升序紧凑写入
- **Sheet2 门店匹配**（博海餐饮项目）：根据文本地址匹配以下16个门店名称，无法匹配则留白
  - 华为F区, 银联总部, 广慈店, 上证数据, 上清企, 商汤, 电视台, 南桥, 泸定路, 昌平路, 滨江店, 上海康养&光明厨房, 航天公司, 瑞金医院, 常德路, 溧阳路店
- **定位规则**（2026.4.8更新）：招聘上不显示实际位置，统一改为附近其他位置
- **航天项目**：提前一天报备
- **上期所项目**：暂停招聘

## 汇率监控
- 中国银行 EUR 现汇卖出价
- 阈值：793.00（跌破推送）
- 推送群：煤煤猫推送群
- 脚本：/root/.openclaw/workspace-newbot/scripts/boc_eur_monitor.py
- 定时：每30分钟（cron job boc-eur-monitor）

## 机票监控
- 脚本：`/root/.openclaw/workspace-newbot/scripts/ctrip_flights_hook.py`
- 定时：每3小时（cron job ctrip-flight-monitor）
- 数据源：携程（主力）+ 飞猪 + Skyscanner + Google Flights
- 开关：FLIGGY=1 / SKYSCANNER=1 / GOOGLE=1 环境变量控制
- 去重文件：`/tmp/ctrip_flights_seen.json` 等各平台独立
- **Cookie失效处理**：携程 Cookie 失效时 → F12找fuzzySearch请求 → Copy as cURL → 更新脚本 COOKIE 和 TRACE_ID

## 周报任务（每次唤醒执行）
- 妈妈猫提供数据源表格 → 我分析填充
- 数据源表格：`LyK3sD1QVhYmsft7E6vc8YRynwf`
- 周报文档：https://s0r6qz13rtj.feishu.cn/wiki/ZKzDwdCYBii1U6kd7rIcV2aWnLe
- 商家BD物料文档：https://s0r6qz13rtj.feishu.cn/docx/IMBkdyuT6otVmNxREaIcgMk6nRg

## 登记任务 ⚠️ 重要注意事项
**⚠️ 翻页漏抓bug（2026-03-25发现）：**
- **原因：** API sort=ByCreateTimeDesc 时，当某一页最老的消息仍 > last_time，说明还有更早的消息没抓完，但脚本有时只翻了1-2页就停了
- **正确做法：** 翻页不能提前停，要一直翻到出现消息的 create_time ≤ last_time 为止
- **修复方案：** 翻页时检查当前页最后一条消息的时间，如果 > last_time，继续翻下一页；只有出现 ≤ last_time 的消息时才停止
- **重要：** last_time 存储的是毫秒级UTC时间戳，飞书API返回的 create_time 也是UTC毫秒，直接数值比较即可，不需要时区转换
- 每次登记前：先完整翻页获取所有 > last_time 的消息，再统一处理

## 技能扩展

### 浏览器控制 - pinchtab
- 路径：`/root/.openclaw/skills/pinchtab/`
- 用途：控制浏览器进行网页操作（点击、填表、截图等）

### 网页爬取 - scrapling
- 路径：`/root/.openclaw/skills/scrapling/`
- 用途：从网页抓取结构化数据

### Codex 编程工作流（重要！）
当需要编写脚本或代码时：
1. 调用 Codex 编写代码
2. **煤煤作为监工**监督 Codex 的编写过程
3. Codex 完成后，**煤煤负责验证**代码是否符合要求
4. 验证通过后验收，不通过则打回重写或修改

## 都柏林机票监控（2026-03-29 新增，⚠️数据源问题）
- 脚本：`/root/.openclaw/workspace-newbot/scripts/dublin_flights_hook.py`
- Cron job ID：`16702984-f5bd-437e-a2ac-53ee7cf34203`
- 出发城市：北京(PEK)/上海(SHA)/广州(CAN) → 都柏林(DUB)
- 出发日期：8.31、9.1、9.2（2026年）
- 数据源：Rally Chrome Kiwi标签页(pinctab) > Kiwi GraphQL API > 携程 API
- ⚠️ 已知问题：
  - Rally Chrome Kiwi标签页 → 显示"未找到"降级内容（Ctrip fallback，无效数据）
  - Kiwi GraphQL API → 返回 0 结果（地理限制）
  - Ctrip API → 返回 0 结果（数据库无DUB航线）
  - Qunar → 无法识别"都柏林"城市名（映射为Nagoya）
  - pinctab外部导航 → 被代理403拦截
  - 根本原因：北上广→都柏林航线在这些平台数据覆盖严重不足
- 推送规则：每城市TOP3，无数据时不推送空消息
- 推送目标：同机票监控（7b7ce7f0-e595-43c8-aae0-feb0411e4408）

## 都柏林机票监控（2026-03-29 完成）

### 最终方案
- **携程 fuzzySearch**：主力数据源，API自动调用（`scripts/dublin_flights_v10.py`）
- **去哪儿**：Rally Chrome + OpenClaw Browser Rally插件 + browser工具截图 + AI分析
- **Cron**：每2小时自动跑（`dublin-flight-monitor` job）

### 关键Cookie/Token
- 携程 fuzzySearch：FXPC=09031023217414352709, CID=09031023217414352709
- Rally Chrome gateway：localhost:18792, token=6b4267f307adca3722b111ebf5313bcfb524e843bba42a12

### 脚本
- 主脚本：`/root/.openclaw/workspace-newbot/scripts/dublin_flights_v10.py`

### 错误教训（重要！）
1. subprocess shell=True 管道命令 → 用 capture_output=True + requests
2. websocket-client 自动加 Origin → 纯 socket 手动握手绕过
3. pinctab allowHosts 配置误解 → 改用 Rally Chrome
4. browser chrome-relay tab not found → 先 tabs 获取 targetId 再操作
5. cron agentTurn 类型 → 只能删除重建，无法 edit


